package kr.kepco.edu.edu.controller;

import com.fasterxml.jackson.annotation.JsonView;
import kr.kepco.edu.edu.dto.EduDeptDTO;
import kr.kepco.edu.edu.dto.SelectOptionDTO;
import kr.kepco.edu.edu.dto.WeekNavDTO;
import kr.kepco.edu.edu.req.CommonFilterReq;
import kr.kepco.edu.edu.req.WeekNavReq;
import kr.kepco.edu.edu.service.CommonFilterService;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("api/edu/filters")
@RequiredArgsConstructor
public class CommonFilterController {
    private final CommonFilterService commonFilterService;

    @PostMapping(value = "/cours")
    public List<SelectOptionDTO> cours(@RequestBody(required = false) CommonFilterReq req) {
        return commonFilterService.getCoursOptions(req.getTkchgEmpNo(), req.getCoursName());
    }

    @PostMapping(value = "/cardinals")
    public List<SelectOptionDTO> cardinals(@RequestBody CommonFilterReq req) {

        return commonFilterService.getCardinalOptions(req.getCours());
    }

    @PostMapping(value = "/classes")
    public List<SelectOptionDTO> classes(@RequestBody CommonFilterReq req) {
     return commonFilterService.getClasOptions(req.getCours(), req.getCardinal());
    }

    @PostMapping(value="/navigate")
    public WeekNavDTO navigate(@JsonView(WeekNavReq.View.Navigate.class) @Validated(WeekNavReq.View.Navigate.class) @RequestBody WeekNavReq req){

        return commonFilterService.weekNavigate(req);
    }

    @PostMapping(value="/validateNavigate")
    public String validateOrFail(@JsonView(WeekNavReq.View.Navigate.class) @Validated(WeekNavReq.View.Navigate.class) @RequestBody WeekNavReq req){

        return commonFilterService.validateOrFail(req.getCrtrYy(), req.getCrtrMm(), req.getCrtrMmWeek());
    }

    @PostMapping(value = "/years")
    public List<String> years() {
       return commonFilterService.getYears();
    }

    @PostMapping(value = "/months")
    public List<String> months(@JsonView(WeekNavReq.View.Months.class)
                                                @Validated(WeekNavReq.View.Months.class) @RequestBody WeekNavReq req) {
        return commonFilterService.getMonthsByYear(req.getCrtrYy());
    }

    @PostMapping(value = "/weeks")
    public List<WeekNavDTO> weeks( @JsonView(WeekNavReq.View.Weeks.class)
                                                    @Validated(WeekNavReq.View.Weeks.class) @RequestBody WeekNavReq req) {
       return commonFilterService.getWeeksByYearMonth(req.getCrtrYy(), req.getCrtrMm());
    }

    @PostMapping(value = "/deptEduOper")
    public List<EduDeptDTO> getDeptInEduOper() {
        return commonFilterService.getDeptInEduOper();
    }
}
