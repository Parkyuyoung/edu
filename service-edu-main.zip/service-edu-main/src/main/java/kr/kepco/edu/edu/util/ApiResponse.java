package kr.kepco.edu.edu.util;

import com.fasterxml.jackson.annotation.JsonInclude;
import kr.kepco.edu.edu.validation.ErrorCode;
import lombok.*;
import org.springframework.http.HttpStatus;

@ToString
@Getter @Builder
@AllArgsConstructor @NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiResponse<T> {
    private boolean success;
    private int status;
    private String message;
    private long timestamp;
    private T data;

    private String code;
    private String detail;

    // 성공(데이터 포함) - 기본 200
    public static <T> ApiResponse<T> ok(T data) {
        return ok(HttpStatus.OK, data, null);
    }
    // 성공(메시지만) - 기본 200
    public static ApiResponse<Void> okMsg(String message) {
        return ok(HttpStatus.OK, null, message);
    }
    // 성공(상태/데이터/메시지 커스텀)
    public static <T> ApiResponse<T> ok(HttpStatus status, T data, String message) {
        return ApiResponse.<T>builder()
                .success(true)
                .status(status.value())
                .message(message)
                .timestamp(System.currentTimeMillis())
                .data(data)
                .build();
    }
    // --- 실패: 단순 메시지 ---
    public static <T> ApiResponse<T> fail(HttpStatus status, String message) {
        return ApiResponse.<T>builder()
                .success(false)
                .status(status.value())
                .message(message)
                .timestamp(System.currentTimeMillis())
                .build();
    }

    // --- 실패: ErrorCode 기반 (추천) ---
    public static <T> ApiResponse<T> fail(ErrorCode errorCode) {
        return ApiResponse.<T>builder()
                .success(false)
                .status(errorCode.getStatus().value())
                .message(errorCode.getMessage())
                .code(errorCode.getCode())
                .timestamp(System.currentTimeMillis())
                .build();
    }

    // --- 실패: ErrorCode + 상세 정보 ---
    public static <T> ApiResponse<T> fail(ErrorCode errorCode, String detail) {
        return ApiResponse.<T>builder()
                .success(false)
                .status(errorCode.getStatus().value())
                .message(errorCode.getMessage())
                .code(errorCode.getCode())
                .timestamp(System.currentTimeMillis())
                .detail(detail)
                .build();
    }
}
