package kr.kepco.edu.edu.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VeduPlanMonthDTO {
    private String	eduDate;
    private String	edamsEduMhdClName;
    private String	cours;
    private String	coursName;
    private String	cardinal;
    private String	tkchgProfName;
    private String	eduDeptName;
    private String	eduStartDate;
    private String	eduEndDate;
    private String	hostDeptName;
    private String	eduCateg1Name;
    private String	eduCateg3Name;
    private String	eduTarget;
    private int	totQuota;

}
