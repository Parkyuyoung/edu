package kr.kepco.edu.edu.controller;

import kr.kepco.edu.edu.dto.*;
import kr.kepco.edu.edu.req.MyLectureScheduleReq;
import kr.kepco.edu.edu.req.VmblEduOperListReq;
import kr.kepco.edu.edu.service.VmblEduOperService;
import kr.kepco.edu.edu.util.Page;
import kr.kepco.edu.edu.validation.RequestGroup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("api/edu/vMblEduOper")
public class VmblEduOperController {
    private static final Logger log = LoggerFactory.getLogger(VmblEduOperController.class);
    private final VmblEduOperService vmblEduOperService;

    public VmblEduOperController(VmblEduOperService vmblEduOperService) {
        this.vmblEduOperService = vmblEduOperService;
    }

    @PostMapping(value = "/list")
    public Page<VmblEduOperListDTO> getEduOperList(
            @RequestBody @Validated(RequestGroup.Search.class) VmblEduOperListReq req
    ) {

        int totalCount = vmblEduOperService.getEduOperListCnt(req);
        Page<VmblEduOperListDTO> page = new Page<>(req.getCurrentPage(), req.getPageSize(), totalCount);


        List<VmblEduOperListDTO> rows = vmblEduOperService.getEduOperList(req, page);
        page.setContent(rows);
        return page;
    }


    @PostMapping(value = "/detail")
    public VmblEduOperDtlDTO getEduOperDetail( @RequestBody @Validated(RequestGroup.Detail.class) VmblEduOperListReq req) {

        return vmblEduOperService.getEduOperDetail(
                req.getCours(), req.getCardinal(), req.getClas()
        );
    }

    @PostMapping(value = "/studentList")
    public List<VmblStudentDTO> getStudentList (@RequestBody @Validated(RequestGroup.Detail.class) VmblEduOperListReq req) {
        return vmblEduOperService.getStduentList(
                req.getCours(), req.getCardinal(), req.getClas()
        );
    }

    @PostMapping(value = "/insert")
    public int insertMblEnexpAplBulk(
            @RequestBody List<MblEnexpAplDTO> list
    ) {
        return vmblEduOperService.insertEnexpAplBatch(list);
    }

    @PostMapping(value = "/MyEdu")
    public List<MyLectureScheduleDTO> getMyEduList(
            @RequestBody @Validated(RequestGroup.Search.class) MyLectureScheduleReq req
    ) {
            return vmblEduOperService.getMyLectureSchedule(req);
    }

    @PostMapping(value="/getMyEduOper")
    public List<MyLectureScheduleDTO> getMyEduOper( @RequestBody @Validated(RequestGroup.Detail.class) VmblEduOperListReq req ){
        return vmblEduOperService.getMyEduOper(req);
    }

    @PostMapping(value="/selectCoursList")
    public List<VmblEduOperListDTO> selectCoursList( @RequestBody Map<String,Object> param){
        return vmblEduOperService.selectSearchCoursList(param);
    }
}
