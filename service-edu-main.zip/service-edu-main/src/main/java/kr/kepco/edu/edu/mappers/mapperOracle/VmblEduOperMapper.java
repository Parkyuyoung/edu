package kr.kepco.edu.edu.mappers.mapperOracle;

import kr.kepco.edu.edu.dto.*;
import kr.kepco.edu.edu.req.MyLectureScheduleReq;
import kr.kepco.edu.edu.req.VmblEduOperListReq;
import kr.kepco.edu.edu.util.Page;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface VmblEduOperMapper {
    int selectVmblEduOperListCnt(@Param("param") VmblEduOperListReq param);

    /** 목록 (페이징) */
    List<VmblEduOperListDTO> selectVmblEduOperList(@Param("param") VmblEduOperListReq param,
                                                   @Param("page") Page<VmblEduOperListDTO> page);

    /** 상세 (헤더/집계) */
    VmblEduOperDtlDTO selectVmblEduOperDetail(@Param("cours") String cours,
                                              @Param("cardinal") String cardinal,
                                              @Param("clas") String clas);

    /** 상세 - 교육생 목록 */
    List<VmblStudentDTO> selectVmblEduOperStudents(@Param("cours") String cours,
                                                   @Param("cardinal") String cardinal,
                                                   @Param("clas") String clas);

    int insertMblEnexpApl(MblEnexpAplDTO dto);

    List<MyLectureScheduleDTO> selectMyLectureSchedule(MyLectureScheduleReq req);

    List<MyLectureScheduleDTO> selectMyEduOper(VmblEduOperListReq req);

    List<VmblEduOperListDTO> selectSearchCoursList(Map<String, Object> param);
}
