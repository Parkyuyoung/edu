package kr.kepco.edu.edu.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VmblEduOperListDTO {
    private int rnum;

    private String cours;

    private String cardinal;

    private String clas;

    private String coursName;

    private String edamsEduMhdClCdName;

    private String eduStrtYmd;

    private String eduEndYmd;

    private String eduDeptCd;

    private String eduDeptName;

    private String tkchgProfName;

    private String tkchgEmpNo;

    private String tkchgProf;

    private String fldstEduYn;

    private String classroom;

    private Integer totQuota;

    private Integer studentCnt;
}
