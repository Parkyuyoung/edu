package kr.kepco.edu.edu.req;

import com.fasterxml.jackson.annotation.JsonView;
import kr.kepco.edu.edu.validation.RequestGroup;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VmblEduOperListReq  extends BaseRequest {
    @JsonView({RequestGroup.Search.class})
    private String crtrYy;

    @JsonView(RequestGroup.Search.class)
    private String crtrMm;

    @JsonView(RequestGroup.Search.class)
    private String crtrMmWeek;

    @JsonView({RequestGroup.Search.class, RequestGroup.Detail.class})
    private String cours;

    @JsonView({RequestGroup.Search.class, RequestGroup.Detail.class})
    private String cardinal;

    @JsonView({RequestGroup.Search.class, RequestGroup.Detail.class})
    private String clas;

    @JsonView({RequestGroup.Search.class, RequestGroup.Detail.class})
    private String curcl;

    @JsonView({RequestGroup.Search.class, RequestGroup.Detail.class})
    private String instName;

    @JsonView(RequestGroup.Detail.class)
    private String tkchgEmpNo;

    @JsonView(RequestGroup.Search.class)
    private String tkchgProfName;

    @JsonView(RequestGroup.Search.class)
    private String eduDeptCd;

    @JsonView(RequestGroup.Search.class)
    private String eduDeptName;

}
