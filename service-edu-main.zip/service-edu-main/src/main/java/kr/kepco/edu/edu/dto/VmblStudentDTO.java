package kr.kepco.edu.edu.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VmblStudentDTO {
    private String clsof;

    private String memberId;

    private String name;

    private String companyName;

    private String brch1Name;

    private String brch2Name;

    private String brch3Name;

    private String brch4Name;

    private String rankName;

    private String rankNameNm;

    private String stayIn;

    private String stayRoom;

    private String enexpAplYn;

    private String enexpAplCtt;

    private String cellNo;

    private String tempEnexpAplYn;


}
