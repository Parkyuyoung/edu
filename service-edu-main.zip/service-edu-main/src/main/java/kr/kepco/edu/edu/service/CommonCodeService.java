package kr.kepco.edu.edu.service;

import kr.kepco.edu.edu.dto.CommonCodeDTO;
import kr.kepco.edu.edu.mappers.mapperOracle.CommonCodeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class CommonCodeService {

    @Autowired
    CommonCodeMapper commonCodeMapper;
    public List<CommonCodeDTO> selectCommonCode(Map<String, Object> req) { return commonCodeMapper.selectCommonCode(req); }

}
