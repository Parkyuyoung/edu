package kr.kepco.edu.edu.config.db;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;

@Configuration
@MapperScan(basePackages = {"kr.kepco.edu.edu.mappers.mapperOracle"} ,sqlSessionTemplateRef = "oracleSessionTemplate")
public class OracleDataSourceConfig {

    @Bean(name="oracleDataSource")
    @ConfigurationProperties(prefix="spring.datasource.oracle")
    public DataSource dbDataSource() {return DataSourceBuilder.create().build();}

    @Bean(name="oracleSessionFactory")
    public SqlSessionFactory xwSqlSessionFactory(@Qualifier("oracleDataSource") DataSource dataSource) throws Exception {
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();

        bean.setDataSource(dataSource);

        bean.setConfigLocation(new DefaultResourceLoader().getResource("classpath:mybatis-config.xml"));

        bean.setMapperLocations(new PathMatchingResourcePatternResolver().getResources("classpath:mappers/mapperOracle/**/*.xml"));

        return bean.getObject();
    }

    @Bean(name = "oracleTransactionManager")
    public DataSourceTransactionManager xwTransactionManager(@Qualifier("oracleDataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }

    @Bean(name = "oracleSessionTemplate")
    public SqlSessionTemplate xwSqlSessionTemplate(@Qualifier("oracleSessionFactory") SqlSessionFactory sqlSessionFactory) throws Exception {
        return new SqlSessionTemplate(sqlSessionFactory);
    }
}
