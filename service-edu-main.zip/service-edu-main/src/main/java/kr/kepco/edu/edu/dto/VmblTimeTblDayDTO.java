package kr.kepco.edu.edu.dto;

import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VmblTimeTblDayDTO {
    private String eduDate;                // 20250924
    private String dwk;                    // 월/화/...
    private List<VmblTimeTblDTO> rows;
}
