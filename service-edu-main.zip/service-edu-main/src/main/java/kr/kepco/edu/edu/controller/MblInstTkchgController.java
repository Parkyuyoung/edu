package kr.kepco.edu.edu.controller;

import kr.kepco.edu.edu.dto.MblInstTkchgDTO;
import kr.kepco.edu.edu.dto.VmblInstTkchgDTO;
import kr.kepco.edu.edu.req.VmblInstTkchgReq;
import kr.kepco.edu.edu.service.MblInstTkchgService;
import kr.kepco.edu.edu.util.Page;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/edu/mblInstTkchg")
public class MblInstTkchgController {
    private static final Logger log = LoggerFactory.getLogger(MblInstTkchgController.class);
    private final MblInstTkchgService mblInstTkchgService;

    public MblInstTkchgController(MblInstTkchgService mblInstTkchgService) {
        this.mblInstTkchgService = mblInstTkchgService;
    }

    @PostMapping(value = "/list", consumes = "application/json", produces = "application/json")
    public Page<VmblInstTkchgDTO> getVmblInstTkchgList(@RequestBody VmblInstTkchgReq req) {
        // 총 건수
        int totalCount = mblInstTkchgService.getMblInstTkchgListCnt(req);

        // 페이징 객체 구성
        Page<VmblInstTkchgReq> pageReq = new Page<>(req.getCurrentPage(), req.getPageSize(), totalCount);

        // 목록 조회
        List<VmblInstTkchgDTO> list = mblInstTkchgService.getMblInstTkchgList(req, pageReq);

        // 응답 페이지에 컨텐츠 세팅
        Page<VmblInstTkchgDTO> page = new Page<>(req.getCurrentPage(), req.getPageSize(), totalCount);

        page.setContent(list);

        return page;
    }

    @PostMapping(value = "/detail")
    public VmblInstTkchgDTO getVmblInstTkchgDetail( @RequestBody VmblInstTkchgReq req ) {
        return mblInstTkchgService.getMblInstTkchgDetail(req);
    }

    @PostMapping(value = "/insert")
    public int insertVmblInstTkchg(@RequestBody MblInstTkchgDTO dto) {
        return mblInstTkchgService.insertVmblInstTkchg(dto);
    }
}
