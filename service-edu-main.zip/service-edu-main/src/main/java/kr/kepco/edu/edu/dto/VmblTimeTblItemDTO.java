package kr.kepco.edu.edu.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.ALWAYS)
public class VmblTimeTblItemDTO {
    private Integer rnum;

    private String cours;

    private String coursName;

    private String cardinal;

    private String clas;

    private String eduDate;

    private String curcl;

    private String curclName;

    private String instSerialNo;

    private Integer startClassTime;

    private Integer endClassTime;

    private String tkchgType;

    private String instName;

    private Integer lectHour;

    private Integer jointClassGroup;

    private String instMobilePhone;

    private String instType;

    private String instEmpNo;

    private String dwk;

    private String hdayYn;

    private String crtrYy;

    private String crtrMm;

    private String crtrMmWeek;

    private String weekStrtYmd;

    private String weekEndYmd;
}
