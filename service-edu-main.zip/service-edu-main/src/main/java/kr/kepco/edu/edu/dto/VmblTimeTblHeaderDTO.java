package kr.kepco.edu.edu.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VmblTimeTblHeaderDTO {

    private String cours;

    private String coursName;

    private String cardinal;

    private String clas;

    private String eduStrtYmd;

    private String eduEndYmd;

    private String timeTableStatus;

    private int lectHourTotal;

    private String crtrYy;

    private String crtrMm;

    private String crtrMmWeek;

}
