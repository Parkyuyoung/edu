package kr.kepco.edu.edu.mappers.mapperOracle;

import kr.kepco.edu.edu.dto.EduDeptDTO;
import kr.kepco.edu.edu.dto.SelectOptionDTO;
import kr.kepco.edu.edu.dto.ValidateWeekNavDTO;
import kr.kepco.edu.edu.dto.WeekNavDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface CommonFilterMapper {
    List<SelectOptionDTO> selectCoursOptions(@Param("tkchgEmpNo") String tkchgEmpNo, @Param("coursName") String coursName);

    List<SelectOptionDTO> selectCardinalOptions(@Param("cours") String cours);

    List<SelectOptionDTO> selectClasOptions(@Param("cours") String cours,
                                            @Param("cardinal") String cardinal);

    WeekNavDTO selectNextWeek(@Param("crtrYy") String crtrYy,
                              @Param("crtrMm") String crtrMm,
                              @Param("crtrMmWeek") String crtrMmWeek);

    WeekNavDTO selectPrevWeek(@Param("crtrYy") String crtrYy,
                              @Param("crtrMm") String crtrMm,
                              @Param("crtrMmWeek") String crtrMmWeek);

    ValidateWeekNavDTO validateWeekNav(@Param("crtrYy") String crtrYy,
                                       @Param("crtrMm") String crtrMm,
                                       @Param("crtrMmWeek") String crtrMmWeek);

    List<String> selectYears();

    List<String> selectMonthsByYear(@Param("crtrYy") String crtrYy);

    List<WeekNavDTO> selectWeeksByYearMonth(@Param("crtrYy") String crtrYy,
                                                     @Param("crtrMm") String crtrMm);

    WeekNavDTO selectTodayYmw();

    List<EduDeptDTO> selectDeptInEduOper();
}
