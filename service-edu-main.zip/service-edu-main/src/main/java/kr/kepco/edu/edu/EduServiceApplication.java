package kr.kepco.edu.edu;

import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;

@SpringBootApplication
public class EduServiceApplication {
    public static void main(String[] a) {
        SpringApplication.run(EduServiceApplication.class, a);
    }
}