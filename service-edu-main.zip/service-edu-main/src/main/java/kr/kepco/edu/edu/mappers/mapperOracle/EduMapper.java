package kr.kepco.edu.edu.mappers.mapperOracle;

import kr.kepco.edu.edu.dto.MbnMngDTO;
import kr.kepco.edu.edu.dto.MbnPlanDTO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface EduMapper {
    int selectMbnPlanListCnt(Map<String, Object> map);

    List<MbnPlanDTO> selectMbnPlanList(Map<String, Object> map);

    MbnPlanDTO selectMbnPlanDetail(Map<String, Object> param);

    int insertMbnPlan(Map<String, Object> param);

    int selectMbnMngListCnt(Map<String, Object> map);

    List<MbnMngDTO> selectMbnMngList(Map<String, Object> map);

    MbnMngDTO selectMbnMngDetail(Map<String, Object> param);

    int insertMbnMng(Map<String, Object> param);
}

