package kr.kepco.edu.edu.controller;

import kr.kepco.edu.edu.dto.CommonCodeDTO;
import kr.kepco.edu.edu.dto.MbnMngDTO;
import kr.kepco.edu.edu.dto.MbnPlanDTO;
import kr.kepco.edu.edu.service.CommonCodeService;
import kr.kepco.edu.edu.service.EduService;
import kr.kepco.edu.edu.util.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/edu")
public class BoardApiController {

    @Autowired
    EduService eduService;

    @Autowired
    CommonCodeService commonCodeService;

    @PostMapping("/getMbnPlanList")
    public Page<MbnPlanDTO> getMbnPlanList(@RequestBody Map<String,Object> param) {

        Page<MbnPlanDTO> page = new Page<>(param,eduService.selectMbnPlanListCnt(param));
        param.put("page",page);
        page.setContent(eduService.selectMbnPlanList(param));

        return page;
    }

    @PostMapping("/getMbnPlanDetail")
    public MbnPlanDTO getMbnPlanDetail(@RequestBody Map<String,Object> param) {
        return eduService.selectMbnPlanDetail(param);
    }

    @PostMapping("/insMbnPlan")
    public int insertMbnPlan(@RequestBody Map<String,Object> param) {
        return eduService.insertMbnPlan(param);
    }

    @PostMapping("/getMbnMngList")
    public Page<MbnMngDTO> getMbnMngList(@RequestBody Map<String,Object> param) {

        Page<MbnMngDTO> page = new Page<>(param,eduService.selectMbnMngListCnt(param));
        param.put("page",page);
        page.setContent(eduService.selectMbnMngList(param));

        return page;
    }

    @PostMapping("/getMbnMngDetail")
    public MbnMngDTO getMbnMngDetail(@RequestBody Map<String,Object> param) {
        return eduService.selectMbnMngDetail(param);
    }

    @PostMapping("/insMbnMng")
    public int insertMbnMng(@RequestBody Map<String,Object> param) {
        return eduService.insertMbnMng(param);
    }

    @PostMapping("/getComCode")
    public List<CommonCodeDTO> getCommonCode(@RequestBody Map<String,Object> param) {
        return commonCodeService.selectCommonCode(param);
    }
}