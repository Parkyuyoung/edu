package kr.kepco.edu.edu.req;


import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class VmblInstTkchgReq extends BaseRequest
{
    private String instEmpNo;

    private String tkchgEmpNo;

    private String cours;

    private String cardinal;

    private String clas;

    private String curcl;

    private String startDate;     // YYYYMMDD

    private String endDate;

    private String instTypeCdName;

    private String tkchgSetYn;
}
