package kr.kepco.edu.edu.dto;

import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VmblTimeTblResponseDTO {
    private VmblTimeTblHeaderDTO header;
    private List<VmblTimeTblDayDTO> list;
}