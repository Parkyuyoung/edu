package kr.kepco.edu.edu.dto;

import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MblEnexpAplDTO {
    private int seqNo;

    private LocalDateTime frstRegDt;

    private String frstRegrEmpno;

    private LocalDateTime lstChgDt;

    private String lstChgrEmpno;

    private String edamsCrcmCd;

    private String eduAdmstPseq;

    private String memberId;

    private String enexpAplYn;

    private String enexpRmk;

}
