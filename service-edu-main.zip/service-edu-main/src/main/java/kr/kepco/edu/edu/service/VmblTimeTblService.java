package kr.kepco.edu.edu.service;


import kr.kepco.edu.edu.dto.VmblTimeTblHeaderDTO;
import kr.kepco.edu.edu.dto.VmblTimeTblItemDTO;
import kr.kepco.edu.edu.dto.VmblTimeTblListDTO;
import kr.kepco.edu.edu.mappers.mapperOracle.VmblTimeTblMapper;
import kr.kepco.edu.edu.req.VmblTimeTblListReq;
import kr.kepco.edu.edu.req.VmblTimeTblReq;
import kr.kepco.edu.edu.util.Page;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class VmblTimeTblService {
    private final VmblTimeTblMapper vmblTimeTblMapper;
    //private final EmpNameUtil empNameUtil;

    @Transactional
    public int getVmblTimeTblListCnt(VmblTimeTblListReq param) {
        return vmblTimeTblMapper.selectVmblTimeTblListCnt(param);
    }

    @Transactional
    public List<VmblTimeTblListDTO> getVmblTimeTblList(VmblTimeTblListReq param,
                                                       Page<VmblTimeTblListReq> page) {
        return vmblTimeTblMapper.selectVmblTimeTblList(param, page);
    }

    @Transactional
    public VmblTimeTblHeaderDTO getVmblTimeTblHeader(VmblTimeTblReq param) {
        return vmblTimeTblMapper.selectVmblTimeTblHeader(param);
    }

    @Transactional
    public int getVmblTimeTblCnt(VmblTimeTblReq param) {
        return vmblTimeTblMapper.selectVmblTimeTblCnt(param);
    }

    @Transactional
    public List<VmblTimeTblItemDTO> getVmblTimeTbl(VmblTimeTblReq param) {
        List<VmblTimeTblItemDTO> list = vmblTimeTblMapper.selectVmblTimeTbl(param);

        // 사번 기반 사내폰 조회 → 없으면 사외폰으로 대체
//        empNameUtil.enrichPhone(
//                list,
//                VmblTimeTblDTO::getInstEmpNo,   // 사내강사 사번
//                VmblTimeTblDTO::setInstMobilePhone,   // 최종 휴대폰 세팅 대상
//                VmblTimeTblDTO::getInstMobilePhone // fallback(사외 휴대폰번호)
//        );

        return list;
    }
}
