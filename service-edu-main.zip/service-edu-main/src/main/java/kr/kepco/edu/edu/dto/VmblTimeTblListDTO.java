package kr.kepco.edu.edu.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VmblTimeTblListDTO {
    private int rnum;

    private String cours;

    private String coursName;

    private String cardinal;

    private String clas;

    private String eduStrtYmd;

    private String eduEndYmd;

    private String eduDays;

    private String timeDay;

    private Integer totQuota;

    private Integer eduCnt;

    private String hostDeptName;

    private String tkchgProfName;

    private String tkchgEmpNo;

    private String timeTableStatus;
}
