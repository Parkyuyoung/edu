package kr.kepco.edu.edu.service;

import kr.kepco.edu.edu.dto.*;
import kr.kepco.edu.edu.mappers.mapperOracle.VmblEduOperMapper;
import kr.kepco.edu.edu.req.MyLectureScheduleReq;
import kr.kepco.edu.edu.req.VmblEduOperListReq;
import kr.kepco.edu.edu.util.Page;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class VmblEduOperService {
    private final VmblEduOperMapper vmblEduOperMapper;

    @Transactional(readOnly = true)
    public int getEduOperListCnt(VmblEduOperListReq param) {
        return vmblEduOperMapper.selectVmblEduOperListCnt(param);
    }

    @Transactional(readOnly = true)
    public List<VmblEduOperListDTO> getEduOperList(VmblEduOperListReq param,
                                                   Page<VmblEduOperListDTO> page) {
        List<VmblEduOperListDTO> list = vmblEduOperMapper.selectVmblEduOperList(param, page);
        return list == null ? Collections.emptyList() : list;
    }

    @Transactional(readOnly = true)
    public VmblEduOperDtlDTO getEduOperDetail(String cours, String cardinal, String clas) {
        VmblEduOperDtlDTO header = vmblEduOperMapper.selectVmblEduOperDetail(cours, cardinal, clas);
        if (header == null) return null;

        List<VmblStudentDTO> students =
                vmblEduOperMapper.selectVmblEduOperStudents(cours, cardinal, clas);
        header.setStudents(students == null ? Collections.emptyList() : students);

        return header;
    }

    @Transactional(readOnly = true)
    public List<VmblStudentDTO> getStduentList(String cours, String cardinal, String clas){
        List<VmblStudentDTO> students =
                vmblEduOperMapper.selectVmblEduOperStudents(cours, cardinal, clas);
        return students;
    }

    /* 편의 메서드: 상세를 키 DTO로 받는 버전 */
    @Transactional(readOnly = true)
    public VmblEduOperDtlDTO getEduOperDetail(VmblEduOperListDTO key) {
        if (key == null) return null;
        return getEduOperDetail(key.getCours(), key.getCardinal(), key.getClas());
    }

    @Transactional
    public int insertEnexpApl(MblEnexpAplDTO dto){
        return insertEnexpApl(dto);
    }

    @Transactional
    public int insertEnexpAplBatch(List<MblEnexpAplDTO> list){
        int cnt = 0;
        for(MblEnexpAplDTO dto : list){
            cnt += vmblEduOperMapper.insertMblEnexpApl(dto);
        }
        return cnt;
    }

    @Transactional(readOnly = true)
    public List<MyLectureScheduleDTO> getMyLectureSchedule(MyLectureScheduleReq req) {
        List<MyLectureScheduleDTO> list = vmblEduOperMapper.selectMyLectureSchedule(req);
        return list == null ? Collections.emptyList() : list;
    }

    @Transactional(readOnly = true)
    public List<MyLectureScheduleDTO> getMyEduOper(VmblEduOperListReq req) {
        return vmblEduOperMapper.selectMyEduOper(req);
    }

    public List<VmblEduOperListDTO> selectSearchCoursList(Map<String, Object> param) {
        return vmblEduOperMapper.selectSearchCoursList(param);
    }
}
