package kr.kepco.edu.edu.controller;


import kr.kepco.edu.edu.dto.CalendarDayDTO;
import kr.kepco.edu.edu.req.VeduPlanMonthReq;
import kr.kepco.edu.edu.service.VeduPlanMonthService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/edu/vEduPlanMonth")
public class VeduPlanMonthController {
    private static final Logger log = LoggerFactory.getLogger(VeduPlanMonthController.class);
    private final VeduPlanMonthService veduPlanMonthService;

    public VeduPlanMonthController(VeduPlanMonthService veduPlanMonthService) {
        this.veduPlanMonthService = veduPlanMonthService;
    }

    @PostMapping(value = "/list", consumes = "application/json", produces = "application/json")
    public List<CalendarDayDTO> getVmblInstTkchgList(@RequestBody VeduPlanMonthReq req) {

        // 목록 조회
        List<CalendarDayDTO> list = veduPlanMonthService.getEduPlanMonthList(req);

        return list;
    }

}
