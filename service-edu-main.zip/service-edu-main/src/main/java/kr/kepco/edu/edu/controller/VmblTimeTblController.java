package kr.kepco.edu.edu.controller;

import com.fasterxml.jackson.annotation.JsonView;
import kr.kepco.edu.edu.dto.*;
import kr.kepco.edu.edu.req.VmblTimeTblListReq;
import kr.kepco.edu.edu.req.VmblTimeTblReq;
import kr.kepco.edu.edu.service.VmblTimeTblService;
import kr.kepco.edu.edu.util.Page;
import kr.kepco.edu.edu.validation.RequestGroup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("api/edu/vMblTimeTbl")
public class VmblTimeTblController {
    private static final Logger log = LoggerFactory.getLogger(VmblTimeTblController.class);

    private final VmblTimeTblService vmblTimeTblService;

    public VmblTimeTblController(VmblTimeTblService vmblTimeTblService) {
        this.vmblTimeTblService = vmblTimeTblService;
    }


    @PostMapping(value = "/list")
    public Page<VmblTimeTblListDTO> getVmblTimeTblList(
            @RequestBody @JsonView(RequestGroup.Search.class) VmblTimeTblListReq req
    ) {
        // 총 건수
        int totalCount = vmblTimeTblService.getVmblTimeTblListCnt(req);

        // 페이징 객체 구성 (프로젝트 공통 Page 사용 가정)
        Page<VmblTimeTblListReq> pageReq = new Page<>(req.getCurrentPage(), req.getPageSize(), totalCount);

        // 목록 조회
        List<VmblTimeTblListDTO> list = vmblTimeTblService.getVmblTimeTblList(req, pageReq);

        Page<VmblTimeTblListDTO> page = new Page<>(req.getCurrentPage(), req.getPageSize(), totalCount);
        page.setContent(list);

        return page;
    }
//
//    @PostMapping(value = "/detail")
//    public Map<String, Object> getVmblTimeTbl(
//            @RequestBody @Validated @JsonView(RequestGroup.Search.class) VmblTimeTblReq req
//    ) {
//        // 총 건수
//        int totalCount = vmblTimeTblService.getVmblTimeTblCnt(req);
//
//        //헤더 조회
//        VmblTimeTblHeaderDTO header = vmblTimeTblService.getVmblTimeTblHeader(req);
//        if (header == null) {
//            header = new VmblTimeTblHeaderDTO();
//        }
//
//        header.setCours(req.getCours());
//        header.setCardinal(req.getCardinal());
//        header.setClas(req.getClas());
//
//        // 1) 원본 목록 조회
//        List<VmblTimeTblItemDTO> rawList = vmblTimeTblService.getVmblTimeTbl(req);
//
//// 2) 날짜 기준으로 그룹핑
//        Map<String, List<VmblTimeTblItemDTO>> byDate = new LinkedHashMap<>();
//        for (VmblTimeTblItemDTO item : rawList) {
//            byDate.computeIfAbsent(item.getEduDate(), k -> new ArrayList<>()).add(item);
//        }
//
//// 3) 날짜별 + 교시별 변환
//        List<Map<String, Object>> dayList = new ArrayList<>();
//
//        for (Map.Entry<String, List<VmblTimeTblItemDTO>> entry : byDate.entrySet()) {
//
//            String eduDate = entry.getKey();
//            List<VmblTimeTblItemDTO> items = entry.getValue();
//
//            // 같은 날짜의 첫 번째 행을 기준으로 요일, 주차 등 가져옴
//            VmblTimeTblItemDTO first = items.get(0);
//
//            // 교시별 그룹핑
//            // 교시별 그룹핑
//            Map<Integer, List<VmblTimeTblItemDTO>> byPeriod = new LinkedHashMap<>();
//            for (VmblTimeTblItemDTO dto : items) {
//                Integer start = dto.getStartClassTime();
//                Integer end   = dto.getEndClassTime();
//
//                if (start == null || end == null) {
//                    continue;
//                }
//                // start ~ end 교시 전부에 이 수업을 포함
//                for (int period = start; period <= end; period++) {
//                    byPeriod
//                            .computeIfAbsent(period, k -> new ArrayList<>())
//                            .add(dto);
//                }
//            }
//
//
//            // 교시 오름차순 정렬
//            List<Integer> sortedPeriods = new ArrayList<>(byPeriod.keySet());
//            Collections.sort(sortedPeriods);
//
//            // rows 생성 — 없는 교시는 자동 제외됨
//            List<Map<String, Object>> rows = new ArrayList<>();
//            for (Integer period : sortedPeriods) {
//                Map<String, Object> rowObj = new LinkedHashMap<>();
//                rowObj.put("period", period);
//                rowObj.put("data", byPeriod.get(period));
//                rows.add(rowObj);
//            }
//
//            // 날짜 단위 객체 생성
//            Map<String, Object> dayObj = new LinkedHashMap<>();
//            dayObj.put("eduDate", eduDate);
//            dayObj.put("dwk", first.getDwk());  // 요일
//            dayObj.put("crtrYy", first.getCrtrYy());
//            dayObj.put("crtrMm", first.getCrtrMm());
//            dayObj.put("crtrMmWeek", first.getCrtrMmWeek());
//            dayObj.put("weekStrtYmd", first.getWeekStrtYmd());
//            dayObj.put("weekEndYmd", first.getWeekEndYmd());
//            dayObj.put("rows", rows);
//
//            dayList.add(dayObj);
//        }
//
//// 최종 응답
//        Map<String, Object> data = new LinkedHashMap<>();
//        data.put("header", header);
//        data.put("list", dayList);
//        return data;
//
//    }

    @PostMapping(value = "/detail")
    public VmblTimeTblResponseDTO getVmblTimeTbl(
            @RequestBody @Validated @JsonView(RequestGroup.Search.class) VmblTimeTblReq req
    ) {
        // 1) header
        VmblTimeTblHeaderDTO header = vmblTimeTblService.getVmblTimeTblHeader(req);
        if (header == null) {
            header = new VmblTimeTblHeaderDTO();
            header.setCours(req.getCours());
            header.setCardinal(req.getCardinal());
            header.setClas(req.getClas());
        }

        // 2) 리스트 (DB row 그대로)
        List<VmblTimeTblItemDTO> items = vmblTimeTblService.getVmblTimeTbl(req);

        // 3) 요일/날짜 + 교시별 그룹으로 변환
        List<VmblTimeTblDayDTO> dayList = buildDayPeriodStructure(items);

        VmblTimeTblResponseDTO res = new VmblTimeTblResponseDTO();
        res.setHeader(header);
        res.setList(dayList);
        return res;
    }

    private List<VmblTimeTblDayDTO> buildDayPeriodStructure(List<VmblTimeTblItemDTO> items) {

        // 날짜 기준으로 그룹핑: LinkedHashMap으로 순서 유지
        Map<String, VmblTimeTblDayDTO> dayMap = new LinkedHashMap<>();

        for (VmblTimeTblItemDTO item : items) {
            String date = item.getEduDate();
            if (date == null) {
                continue;
            }

            // 1) 날짜/요일 그룹 만들기
            VmblTimeTblDayDTO day = dayMap.computeIfAbsent(date, d -> {
                VmblTimeTblDayDTO dto = new VmblTimeTblDayDTO();
                dto.setEduDate(d);
                dto.setDwk(item.getDwk());  // 같은 날짜는 같은 요일이므로
                dto.setRows(new ArrayList<>());
                return dto;
            });
        }

        // 날짜별로 다시 교시 그룹핑
        for (VmblTimeTblItemDTO item : items) {
            String date = item.getEduDate();
            if (date == null) continue;
            VmblTimeTblDayDTO day = dayMap.get(date);
            if (day == null) continue;

            // 과목이 없는 빈 행(일자만 채우기 용도)이면 교시 생성하지 않음
            if (item.getCurcl() == null && item.getCurclName() == null) {
                continue;
            }

            // day 안에서 period(교시)별로 묶기 위한 임시 map
            // rows 리스트만 가지고는 찾기 힘드니, 한 번 맵으로 변환
            Map<String, VmblTimeTblDTO> periodMap = day.getRows().stream()
                    .collect(Collectors.toMap(
                            VmblTimeTblDTO::getPeriod,
                            dto -> dto,
                            (a, b) -> a,
                            LinkedHashMap::new
                    ));

            int start = item.getStartClassTime() != null ? item.getStartClassTime() : 0;
            int end   = item.getEndClassTime()   != null ? item.getEndClassTime()   : start;

            for (int p = start; p <= end; p++) {
                if (p <= 0) continue;

                String periodKey = String.valueOf(p);
                VmblTimeTblDTO periodDto = periodMap.computeIfAbsent(periodKey, k -> {
                    VmblTimeTblDTO dto = new VmblTimeTblDTO();
                    dto.setPeriod(k);
                    dto.setData(new ArrayList<>());
                    return dto;
                });

                periodDto.getData().add(item);
            }

            // 변경된 periodMap 을 다시 rows 로 반영 (교시순 정렬)
            List<VmblTimeTblDTO> rowsSorted = periodMap.values().stream()
                    .sorted(Comparator.comparingInt(r -> Integer.parseInt(r.getPeriod())))
                    .collect(Collectors.toList());

            day.setRows(rowsSorted);
        }

        // 날짜 오름차순 정렬 (원하면 요일 순 + 날짜 순으로 정렬도 가능)
        return dayMap.values().stream()
                .sorted(Comparator.comparing(VmblTimeTblDayDTO::getEduDate))
                .collect(Collectors.toList());
    }


}
