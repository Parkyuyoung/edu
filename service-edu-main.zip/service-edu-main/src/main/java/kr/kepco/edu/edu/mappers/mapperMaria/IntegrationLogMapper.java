package kr.kepco.edu.edu.mappers.mapperMaria;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface IntegrationLogMapper {

    int updateStatus(@Param("hisId") String hisId,
                     @Param("statusCd") String statusCd);
}
