package kr.kepco.edu.edu.req;

import lombok.*;

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public class CommonFilterReq extends BaseRequest {

        private String coursName;

        private String cours;

        private String cardinal;

        private String tkchgEmpNo;
    }