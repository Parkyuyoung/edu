package kr.kepco.edu.edu.mappers.mapperOracle;

import kr.kepco.edu.edu.dto.CalendarDayDTO;
import kr.kepco.edu.edu.dto.VeduPlanMonthDTO;
import kr.kepco.edu.edu.req.VeduPlanMonthReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface VeduPlanMonthMapper {
    List<VeduPlanMonthDTO> selectVeduPlanMonthList(@Param("param") VeduPlanMonthReq param);
    List<CalendarDayDTO> selectCalendarDays(@Param("year") String year,
                                                @Param("month") String month);
}
