package kr.kepco.edu.edu.validation;

public class RequestGroup {
    public interface Search {}
    public interface Detail {}
    public interface Insert {}
    public interface Update {}
    public interface List {}
    public interface All extends Search,Detail,Insert,Update {}
}