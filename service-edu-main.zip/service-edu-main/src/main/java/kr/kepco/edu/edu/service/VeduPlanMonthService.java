package kr.kepco.edu.edu.service;

import kr.kepco.edu.edu.dto.CalendarDayDTO;
import kr.kepco.edu.edu.dto.VeduPlanMonthDTO;
import kr.kepco.edu.edu.mappers.mapperOracle.VeduPlanMonthMapper;
import kr.kepco.edu.edu.req.VeduPlanMonthReq;
import lombok.RequiredArgsConstructor;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@RequiredArgsConstructor
public class VeduPlanMonthService {
    private final VeduPlanMonthMapper veduPlanMonthMapper;

    @Transactional(readOnly = true)
    public List<CalendarDayDTO> getEduPlanMonthList(@NotNull VeduPlanMonthReq param) {
        List<CalendarDayDTO> days = veduPlanMonthMapper.selectCalendarDays(param.getYear(), param.getMonth());

        List<VeduPlanMonthDTO> plans = veduPlanMonthMapper.selectVeduPlanMonthList(param);

        Map<String, List<VeduPlanMonthDTO>> planMap = new HashMap<>();
        for (VeduPlanMonthDTO p : plans) {
            String key = p.getEduDate();
            if (key == null) continue;
            planMap.computeIfAbsent(key, k -> new ArrayList<>()).add(p);
        }
        for (CalendarDayDTO day : days) {
            List<VeduPlanMonthDTO> dayPlans =
                    planMap.getOrDefault(day.getCrtrYmd(), new ArrayList<>());
            day.setPlans(dayPlans); // 빈 배열이라도 무조건 셋팅됨
        }
        return days != null ? days : Collections.emptyList();
    }


}
