package kr.kepco.edu.edu.dto;

import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MblInstTkchgDTO {

    private int seqNo;

    private LocalDateTime frstRegDt;

    private String frstRegrEmpno;

    private LocalDateTime lstChgDt;

    private String lstChgrEmpno;

    private String cours;

    private String cardinal;

    private String clas;

    private String eduDate;

    private String curcl;

    private String instSerialNo;

    private int startClassTime;

    private String tkchgSetRqs;

    private LocalDateTime conDt;

    private String conSucsYn;

    private String conErrCtt;
}
