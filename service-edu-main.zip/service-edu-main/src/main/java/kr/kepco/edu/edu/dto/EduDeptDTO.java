package kr.kepco.edu.edu.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EduDeptDTO {
    private String eduDeptCd;

    private String eduDeptName;
}
