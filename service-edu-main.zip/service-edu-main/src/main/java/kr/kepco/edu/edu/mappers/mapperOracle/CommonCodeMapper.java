package kr.kepco.edu.edu.mappers.mapperOracle;

import kr.kepco.edu.edu.dto.CommonCodeDTO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface CommonCodeMapper {
    List<CommonCodeDTO> selectCommonCode(Map<String, Object> req);
}
