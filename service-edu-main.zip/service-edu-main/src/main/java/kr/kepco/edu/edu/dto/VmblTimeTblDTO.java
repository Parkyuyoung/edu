package kr.kepco.edu.edu.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.ALWAYS)
public class VmblTimeTblDTO {
    private String period;
    private List<VmblTimeTblItemDTO > data;

}
