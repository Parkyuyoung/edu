package kr.kepco.edu.edu.req;

import com.fasterxml.jackson.annotation.JsonView;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WeekNavReq {
    public interface View {
        interface Months {}     // 연도 → 월 목록
        interface Weeks {}      // 연/월 → 주차 목록
        interface Navigate {}   // 연/월/주차 + 방향
        interface Years {}      // (필드 사용 안함; 호환용)
    }

    @JsonView({ View.Months.class, View.Weeks.class, View.Navigate.class })
    private String crtrYy;

    @JsonView({ View.Weeks.class, View.Navigate.class })
    private String crtrMm;

    @JsonView({ View.Navigate.class })
    private String crtrMmWeek; // '5'처럼 문자열로 보관

    @JsonView({ View.Navigate.class })
    private String direction;
}