package kr.kepco.edu.edu.util;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.regex.Pattern;

public class CommonUtil {
    public enum ViewType {SEARCH, DETAIL}

    public static String toUserReason(Throwable e) {
        if (e == null) return "시스템 오류";
        String msg = String.valueOf(e.getMessage());

        // 최소 매핑(필요하면 확장)
        if (msg != null) {
            if (msg.contains("ORA-00001")) return "중복 데이터";
            if (msg.contains("ORA-01400")) return "필수 값 누락";
            if (msg.contains("ORA-12899")) return "입력 값 길이 초과";
            if (msg.contains("ORA-02290")) return "제약 조건 위반";
            if (msg.contains("ORA-00060")) return "데드락 발생";
            if (msg.contains("ORA-02049")) return "잠금 대기 시간 초과";
        }
        // DB/라이브러리 메시지 노출하지 않음
        return "시스템 오류";
    }

    /**
     * Object가 null이 아니고 문자열로 변환했을 때 비어있지 않으면 true 반환
     * @param param 검사할 객체
     * @return 유효하면 true, 그렇지 않으면 false
     */
    public static boolean isValid(Object param) {
        if (param == null) {
            return false;
        }
        if (param instanceof Collection<?>) {
            return !((Collection<?>) param).isEmpty();
        }
        if (param.getClass().isArray()) {
            return Array.getLength(param) > 0;
        }
        String str = param.toString().trim();
        return !str.isEmpty() && !"undefined".equalsIgnoreCase(str);
    }

    public static String formatDate(java.util.Date date) {
        if (date == null) return null;
        return new java.text.SimpleDateFormat("yyyy-MM-dd").format(date);
    }

}
