package kr.kepco.edu.edu.dto;

import lombok.Data;

@Data
public class CommonCodeDTO {
    private String groupCd;         //그룹코드
    private String commonCd;        //공통코드
    private String upperCd;         //상위코드
    private String groupCdName;     //그룹코드명
    private String commonCdName;    //공통코드명
    private String upperCdName;     //상위코드명
}
