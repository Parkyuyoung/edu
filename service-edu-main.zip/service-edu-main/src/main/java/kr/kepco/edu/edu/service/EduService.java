package kr.kepco.edu.edu.service;

import kr.kepco.edu.edu.dto.MbnMngDTO;
import kr.kepco.edu.edu.dto.MbnPlanDTO;
import kr.kepco.edu.edu.mappers.mapperOracle.EduMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class EduService {

    @Autowired
    EduMapper eduMapper;

    public int selectMbnPlanListCnt(Map<String,Object> param) {
        return eduMapper.selectMbnPlanListCnt(param);
    }

    public List<MbnPlanDTO> selectMbnPlanList(Map<String,Object> param) {
        return eduMapper.selectMbnPlanList(param);
    }

    public MbnPlanDTO selectMbnPlanDetail(Map<String, Object> param) {
        return eduMapper.selectMbnPlanDetail(param);
    }

    public int insertMbnPlan(Map<String, Object> param) { return eduMapper.insertMbnPlan(param); }

    public int selectMbnMngListCnt(Map<String,Object> param) {
        return eduMapper.selectMbnMngListCnt(param);
    }

    public List<MbnMngDTO> selectMbnMngList(Map<String,Object> param) {
        return eduMapper.selectMbnMngList(param);
    }

    public MbnMngDTO selectMbnMngDetail(Map<String, Object> param) {
        return eduMapper.selectMbnMngDetail(param);
    }

    public int insertMbnMng(Map<String, Object> param) { return eduMapper.insertMbnMng(param); }
}
