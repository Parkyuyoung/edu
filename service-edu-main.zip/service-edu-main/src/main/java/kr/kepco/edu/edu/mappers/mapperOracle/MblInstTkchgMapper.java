package kr.kepco.edu.edu.mappers.mapperOracle;

import kr.kepco.edu.edu.dto.MblInstTkchgDTO;
import kr.kepco.edu.edu.dto.VmblInstTkchgDTO;
import kr.kepco.edu.edu.req.VmblInstTkchgReq;
import kr.kepco.edu.edu.util.Page;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface MblInstTkchgMapper {

    int selectVmblInstTkchgListCnt(@Param("param") VmblInstTkchgReq param);

    List<VmblInstTkchgDTO> selectVmblInstTkchgList(@Param("param") VmblInstTkchgReq param, @Param("page") Page<VmblInstTkchgReq> page);

    VmblInstTkchgDTO selectVmblInstTkchgDetail(VmblInstTkchgReq param);

    int insertMblInstTkchg(MblInstTkchgDTO dto);
}
