package kr.kepco.edu.edu.dto;

import lombok.Data;

import java.util.List;

@Data
public class CalendarDayDTO {
    private String crtrYmd;
    private String dwk;
    private String hdayYn;
    private String crtrYy;
    private String crtrMm;
    private String crtrmmWeek;
    private String weekStrtYmd;
    private String weekEndYmd;
    private List<VeduPlanMonthDTO> plans;
}
