package kr.kepco.edu.edu.req;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VeduPlanMonthReq {
    private String year;
    private String month;
    private String category;
}
