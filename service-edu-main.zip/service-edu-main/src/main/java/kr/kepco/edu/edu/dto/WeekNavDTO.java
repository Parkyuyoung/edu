package kr.kepco.edu.edu.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WeekNavDTO {
    private String crtrYy;

    private String crtrMm;

    private String crtrMmWeek;

    private String weekStrtYmd;

    private String weekEndYmd;
}
