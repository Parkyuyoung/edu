package kr.kepco.edu.edu.req;

import com.fasterxml.jackson.annotation.JsonView;
import kr.kepco.edu.edu.validation.RequestGroup;
import lombok.Data;

@Data
public class MyLectureScheduleReq {
    @JsonView(RequestGroup.Search.class)
    private String crtrYy;

    @JsonView(RequestGroup.Search.class)
    private String crtrMm;

    @JsonView(RequestGroup.Search.class)
    private String coursName;

    @JsonView(RequestGroup.Search.class)
    private String tkchgEmpNo;

    @JsonView(RequestGroup.Search.class)
    private String cours;

    @JsonView(RequestGroup.Search.class)
    private String cardinal;

}
