package kr.kepco.edu.edu.service;


import kr.kepco.edu.edu.dto.MblInstTkchgDTO;
import kr.kepco.edu.edu.dto.VmblInstTkchgDTO;
import kr.kepco.edu.edu.mappers.mapperOracle.MblInstTkchgMapper;
import kr.kepco.edu.edu.req.VmblInstTkchgReq;
import kr.kepco.edu.edu.util.Page;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MblInstTkchgService {
    private final MblInstTkchgMapper mblInstTkchgMapper;

    @Transactional
    public int getMblInstTkchgListCnt(VmblInstTkchgReq param) {
        return mblInstTkchgMapper.selectVmblInstTkchgListCnt(param);
    }

    @Transactional
    public List<VmblInstTkchgDTO> getMblInstTkchgList (VmblInstTkchgReq param, Page<VmblInstTkchgReq> page) {
        return mblInstTkchgMapper.selectVmblInstTkchgList(param, page);
    }

    @Transactional
    public VmblInstTkchgDTO getMblInstTkchgDetail(VmblInstTkchgReq req) {
        return mblInstTkchgMapper.selectVmblInstTkchgDetail(req);
    }

    @Transactional
    public int insertVmblInstTkchg(MblInstTkchgDTO dto) {
        return mblInstTkchgMapper.insertMblInstTkchg(dto);
    }

}
