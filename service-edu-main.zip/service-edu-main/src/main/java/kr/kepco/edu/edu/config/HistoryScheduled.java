package kr.kepco.edu.edu.config;

import kr.kepco.edu.edu.mappers.mapperMaria.IntegrationLogMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
@EnableScheduling
public class HistoryScheduled {

    @Autowired
    IntegrationLogMapper integrationLogMapper;

    @PostConstruct
    public void init() {
        refresh();
    }

    @Scheduled(fixedDelay = 600_000L)
    public void refresh() {
        // 연계테이블 상태값 조회해서 연계 히스트로 테이블 내역 업데이트
        
        // integrationLogMapper.updateStatus();
    }
}
