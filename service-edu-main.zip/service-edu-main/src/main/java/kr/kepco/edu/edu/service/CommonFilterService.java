package kr.kepco.edu.edu.service;

import kr.kepco.edu.edu.dto.EduDeptDTO;
import kr.kepco.edu.edu.dto.SelectOptionDTO;
import kr.kepco.edu.edu.dto.ValidateWeekNavDTO;
import kr.kepco.edu.edu.dto.WeekNavDTO;
import kr.kepco.edu.edu.mappers.mapperOracle.CommonFilterMapper;
import kr.kepco.edu.edu.req.WeekNavReq;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CommonFilterService {
    private final CommonFilterMapper commonFiltermapper;

    @Transactional(readOnly = true)
    public List<SelectOptionDTO> getCoursOptions(String tkchgEmpNo, String coursName) {
        return commonFiltermapper.selectCoursOptions(tkchgEmpNo,coursName);
    }

    @Transactional(readOnly = true)
    public List<SelectOptionDTO> getCardinalOptions(String cours) {
        return commonFiltermapper.selectCardinalOptions(cours);
    }

    @Transactional(readOnly = true)
    public List<SelectOptionDTO> getClasOptions(String cours, String cardinal) {
        return commonFiltermapper.selectClasOptions(cours, cardinal);
    }

    @Transactional(readOnly = true)
    public WeekNavDTO weekNavigate(WeekNavReq req) {
        String crtrYy = req.getCrtrYy().trim();
        String crtrMm = req.getCrtrMm().trim();
        String crtrMmWeek = req.getCrtrMmWeek().trim();
        String dir = req.getDirection().trim();

        WeekNavDTO res;
        if ("NEXT".equalsIgnoreCase(dir)) {
            res = commonFiltermapper.selectNextWeek(crtrYy, crtrMm, crtrMmWeek);
        } else if ("PREV".equalsIgnoreCase(dir)) {
            res = commonFiltermapper.selectPrevWeek(crtrYy, crtrMm, crtrMmWeek);
        } else {
            throw new IllegalArgumentException("direction 은 NEXT 또는 PREV 이어야 합니다.");
        }

        // 양 끝(가장 처음/가장 마지막 주)에서 next/prev가 없으면 null 가능 → 기본적으로 현재 유지하도록 처리(선택)
        if (res == null) {
            return WeekNavDTO.builder()
                    .crtrYy(crtrYy).crtrMm(crtrMm).crtrMmWeek(crtrMmWeek)
                    // 시작/종료일은 현재 주로 채우고 싶다면 아래처럼 조회 추가 가능
                    .build();
        }
        return res;
    }

    public ValidateWeekNavDTO validateWeekNav(String crtrYy, String crtrMm, String crtrMmWeek) {
       return commonFiltermapper.validateWeekNav(crtrYy, crtrMm, crtrMmWeek);
    }

    @Transactional(readOnly = true)
    public String validateOrFail(String crtrYy, String crtrMm, String crtrMmWeek) {
        // 형식 체크
        if (crtrYy == null || crtrMm == null || crtrMmWeek == null
                || crtrYy.isBlank() || crtrMm.isBlank() || crtrMmWeek.isBlank()) {
            return "F";
        }
        if (!crtrYy.matches("\\d{4}") || !crtrMm.matches("\\d{1,2}") || !crtrMmWeek.matches("\\d{1,2}")) {
            return "F";
        }

        ValidateWeekNavDTO v = commonFiltermapper.validateWeekNav(crtrYy, crtrMm, crtrMmWeek);
        System.out.println("v >>>"+v);
        if (v == null) {
            return "F";
        }

        if (v.getYearCnt() == 0) {
            return "F";
        }
        if (v.getMonthCnt() == 0) {
            return "F";
        }

        int wkInt = Integer.parseInt(crtrMmWeek);
        if (wkInt < v.getMinWk() || wkInt > v.getMaxWk()) {
            return "F";
        }
        if (v.getWeekCnt() == 0) {
            return "F";
        }
        return "T";
    }

    public List<String> getYears() {
        List<String> years = commonFiltermapper.selectYears();
        return years == null ? Collections.emptyList() : years;
    }

    /** 특정 연도의 월 목록 (01~12, XML에서 정렬) */
    public List<String> getMonthsByYear(String crtrYy) {
        if (crtrYy.isBlank()) return Collections.emptyList();
        List<String> months = commonFiltermapper.selectMonthsByYear(crtrYy);
        return months == null ? Collections.emptyList() : months;
    }

    /** 연/월 기준 주차 목록 (주차번호 + 시작/종료일) */
    public List<WeekNavDTO> getWeeksByYearMonth(String crtrYy, String crtrMm) {
        if (crtrYy.isBlank() || crtrMm.isBlank()) return Collections.emptyList();
        List<WeekNavDTO> weeks = commonFiltermapper.selectWeeksByYearMonth(crtrYy, crtrMm);
        return weeks == null ? Collections.emptyList() : weeks;
    }

    /** 오늘 기준 기본 연/월/주차 1건 */
    public WeekNavDTO getTodayYmw() {
        return commonFiltermapper.selectTodayYmw();
    }

    public List<EduDeptDTO> getDeptInEduOper(){
        return commonFiltermapper.selectDeptInEduOper();
    }

}
