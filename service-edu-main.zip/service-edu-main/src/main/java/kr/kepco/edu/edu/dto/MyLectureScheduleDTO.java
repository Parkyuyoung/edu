package kr.kepco.edu.edu.dto;

import lombok.Data;

@Data
public class MyLectureScheduleDTO {
    private String cours;

    private String coursName;

    private String cardinal;

    private String tkchgProfName;

    private String tkchgEmpNo;

    private String eduDate;

    private String curcl;

    private String curclName;

    private Integer startClassTime;

    private Integer endClassTime;

    private Integer lectHour;

    private String instName;

    private String instType;

    private String instMobilePhone;

    private String crtrYy;

    private String crtrMm;

    private String clas;

    private String crtrMmWeek;

    private String startClassTimeList;

    private String endClassTimeList;

    private String eduDateList;

    private String lectHourList;
    private String totQuota;
    private String tkchgProf;

    private String classroomStatus;
    private String eduStrtYmd;
    private String eduEndYmd;

}
