package kr.kepco.edu.edu.dto;

import lombok.*;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ValidateWeekNavDTO {

    private int yearCnt;   // 0 또는 1+

    private int monthCnt;  // 0 또는 1+

    private int minWk;     // null 가능

    private int maxWk;     // null 가능

    private int weekCnt;
}
