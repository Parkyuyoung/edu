package kr.kepco.edu.edu.mappers.mapperOracle;

import kr.kepco.edu.edu.dto.VmblTimeTblHeaderDTO;
import kr.kepco.edu.edu.dto.VmblTimeTblItemDTO;
import kr.kepco.edu.edu.dto.VmblTimeTblListDTO;
import kr.kepco.edu.edu.req.VmblTimeTblListReq;
import kr.kepco.edu.edu.req.VmblTimeTblReq;
import kr.kepco.edu.edu.util.Page;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface VmblTimeTblMapper {

    int selectVmblTimeTblListCnt(@Param("param") VmblTimeTblListReq param);

    List<VmblTimeTblListDTO> selectVmblTimeTblList(@Param("param") VmblTimeTblListReq param,
                                                   @Param("page") Page<VmblTimeTblListReq> page);
    int selectVmblTimeTblCnt(@Param("param") VmblTimeTblReq param);

    VmblTimeTblHeaderDTO selectVmblTimeTblHeader(@Param("param") VmblTimeTblReq param);

    List<VmblTimeTblItemDTO> selectVmblTimeTbl(@Param("param") VmblTimeTblReq param);

}
