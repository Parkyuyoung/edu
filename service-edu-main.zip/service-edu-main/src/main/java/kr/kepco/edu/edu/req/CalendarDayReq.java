package kr.kepco.edu.edu.req;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CalendarDayReq {
    private String year;
    private String month;
}
