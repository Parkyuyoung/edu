package kr.kepco.edu.edu.dto;


import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VmblInstTkchgDTO {

    private int rnum;

    private String cours;

    private String coursName;

    private String cardinal;

    private String clas;

    private String eduDate;

    private String curcl;

    private String instSerialNo;

    private Integer startClassTime;

    private String tkchgSetYn;

    private Integer endClassTime;

    private String curclName;

    private String classYn;

    private String instName;

    private String instTypeCdName;

    private String companyName;

    private String instEmpNo;

    private String instRankCdName;

    private String rankNameNm;

    private String instFeeRankName;

    private int setInstFee;

    private int lectHour;

    private int totHour;

    private int instFee;

    private int limitAmount;


    private int totInstFee;

    private int totLimitAmount;

    private int applyInstFee;

    private int transFee;

    private int paymtAmount;

    private String tkchgProfName;

    private String instFeeResn;
    private String tkchgSetRqs;

}
