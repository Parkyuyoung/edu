package kr.kepco.edu.edu.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class MbnMngDTO {
    private int  rnum;
    private Long bltnbNo;             // 게시글 번호
    private String bltnbTitlNm;       // 제목

    private String frstRegrEmpno;     // 등록자 사번
    private String frstRegrName;      // 등록자 이름
    private String rqsDeptNm;         // 요청부서명

    private LocalDateTime frstRegDt;  // 등록일시
    private LocalDateTime lstChgDt;   // 최종 변경일시

    private String rqsPurpEtcCtt;
    private String rqsMttrCtt;

    private String cours;             // 과정 코드
    private Integer cardinal;         // 기수
    private String coursName;         // 과정명

    private String eduStrtYmd;     // 교육 시작일
    private String eduEndYmd;      // 교육 종료일

    private String replCtt;           // 답변 내용
    private String replRegrId;         // 답변 등록자 ID
    private String replRegrName;       // 답변 등록자 이름
    private String replRegDt;  // 답변 등록일
    private String replUpdDt;  // 답변 수정일
}
