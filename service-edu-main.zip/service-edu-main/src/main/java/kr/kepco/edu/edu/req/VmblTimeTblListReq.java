package kr.kepco.edu.edu.req;

import com.fasterxml.jackson.annotation.JsonView;
import kr.kepco.edu.edu.validation.RequestGroup;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VmblTimeTblListReq extends BaseRequest {

    @JsonView({ RequestGroup.Search.class, RequestGroup.List.class })
    private String crtrYy;

    @JsonView({ RequestGroup.Search.class, RequestGroup.List.class })
    private String crtrMm;

    @JsonView({ RequestGroup.Search.class, RequestGroup.List.class })
    private String crtrMmWeek;

    @JsonView({ RequestGroup.Search.class, RequestGroup.List.class })
    private String tkchgEmpNo;

    @JsonView({ RequestGroup.Search.class, RequestGroup.List.class })
    private String cours;

    @JsonView({ RequestGroup.Search.class, RequestGroup.List.class })
    private String cardinal;
}
