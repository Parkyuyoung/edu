package kr.kepco.edu.edu.dto;

import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VmblEduOperDtlDTO {
    private String cours;

    private String cardinal;

    private String clas;

    private String coursName;

    private String edamsEduMhdClCdName;

    private String tkchgProfName;

    private String tkchgEmpNo;

    private String tkchgProf;

    private String eduStrtYmd;

    private String eduEndYmd;

    private String eduDeptCd;

    private String eduDeptName;

    private String fldstEduYn;

    private String classroom;

    private Integer totQuota;

    private Integer studentCnt;

    // ── 상세 전용 항목
    private String classroomStatus;

    private String timeTableStatus;

    private String edamsTchmtClCdName;

    private String tbletAplYn;

    private Integer stayInCnt;

    private Integer nonStayInCnt;

    private String gradeStatus;

    private String instPayStatus;

    private String complStatus;

    private List<VmblStudentDTO> students;
}
