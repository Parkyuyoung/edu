package kr.kepco.edu.admin.request;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.media.Schema;
import kr.kepco.edu.admin.validation.RequestGroup;
import lombok.Data;

import javax.validation.constraints.Size;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Schema(name = "BannerReq", description = "배너 관리 DTO")
public class BannerReq extends BaseRequest{

    @JsonView({RequestGroup.Detail.class,RequestGroup.Update.class})
    @Schema(description = "배너 일련번호", example = "BN00001")
    private String bnrSerNo;

    @Schema(description = "최초등록일시", example = "2025-10-20T14:30:00")
    private LocalDateTime frstRegDt;

    @JsonView(RequestGroup.Search.class)
    @Schema(description = "최초등록자사번", example = "EMP00123")
    private String frstRegrEmpno;

    @Schema(description = "최종변경일시", example = "2025-10-20T15:45:00")
    private LocalDateTime lstChgDt;

    @Schema(description = "최종변경자사번", example = "EMP00456")
    private String lstChgrEmpno;

    @JsonView({RequestGroup.Insert.class,RequestGroup.Update.class,RequestGroup.Search.class})
    @Schema(description = "배너 제목명", example = "한전 교육행정 서비스 오픈 안내")
    private String bnrTitlNm;

    @JsonView({RequestGroup.Insert.class,RequestGroup.Update.class})
    @Schema(description = "배너 본문 내용", example = "모바일 교육행정 서비스가 새롭게 오픈되었습니다.")
    private String bnrCtt;

    @JsonView({RequestGroup.Insert.class,RequestGroup.Update.class})
    @Schema(description = "정렬 순서", example = "1")
    private String scrSortSeqo;

    @JsonView(RequestGroup.Update.class)
    @Schema(description = "게시 여부(Y/N)", example = "Y")
    private String pstnYn;

    @JsonView(RequestGroup.Update.class)
    @Schema(description = "삭제 여부(Y/N)", example = "N")
    private String delYn;

    @Size(max=10)
    @Schema(description = "검색 이름", example = "홍길동")
    @JsonView({ RequestGroup.Search.class })
    private String searchEmpName;

    @Schema(description = "사번 배열", example = "['112233','111111']")
    @JsonIgnore
    private List<String> searchEmpNo;
}
