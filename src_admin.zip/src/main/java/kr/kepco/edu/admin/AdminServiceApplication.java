package kr.kepco.edu.admin;

import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;

@org.springframework.cloud.openfeign.EnableFeignClients
@SpringBootApplication
public class AdminServiceApplication {
    public static void main(String[] a) {
        SpringApplication.run(AdminServiceApplication.class, a);
    }
}