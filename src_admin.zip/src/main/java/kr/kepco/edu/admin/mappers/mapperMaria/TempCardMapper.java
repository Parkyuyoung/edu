package kr.kepco.edu.admin.mappers.mapperMaria;

import kr.kepco.edu.admin.dto.TempCardDTO;
import kr.kepco.edu.admin.request.TempCardReq;
import kr.kepco.edu.admin.response.Page;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface TempCardMapper {
    int selectTempCardListCnt(@Param("param") TempCardReq req);

    List<TempCardDTO> selectTempCardList(@Param("param") TempCardReq req, @Param("page") Page<TempCardDTO> page);

    int insertTempCard(TempCardReq req);

    TempCardDTO selectTempCardDetail(TempCardReq req);

    Integer updateTempCard(TempCardReq req);

    Integer deleteTempCard(TempCardReq req);

    Integer approveTempCard(TempCardReq req);

}
