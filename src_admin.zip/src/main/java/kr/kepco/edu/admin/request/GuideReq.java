package kr.kepco.edu.admin.request;

import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.media.Schema;
import kr.kepco.edu.admin.validation.RequestGroup;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Schema(name = "GideReq", description = "요청 DTO(그룹: Create/Update/Search). viewType으로 응답 형태 지정")
public class GuideReq extends BaseRequest {

    @Schema(description = "교육행정 안내유형코드", example = "1")
    @JsonView({RequestGroup.Search.class,RequestGroup.Detail.class})
    private String measGuideTpCd;

    @Schema(description = "교육행정 안내 일련번호", example = "1")
    @JsonView(RequestGroup.Detail.class)
    private String guideMstSerno;

    @Schema(description = "정렬순서", example = "1")
    private String scrSortSeqo;

    @Schema(description = "게시여부(Y/N)", example = "Y")
    private String pstnYn;

    @Schema(description = "삭제여부(Y/N)", example = "Y")
    private String delYn;

    @Schema(description = "교육행정 안내 마스터(입교안내/시설안내 구분용)", example = "입교안내")
    private String guideTitlKrnNm;

    @JsonView(RequestGroup.Detail.class)
    @Schema(description = "교육행정 안내 섹션 일련번호", example = "SECT00001")
    private String guideSctnVerNo;

    @Schema(description = "섹션 제목명", example = "입교 안내 절차")
    private String guideSctnTitlNm;

    @Schema(description = "섹션 본문 내용", example = "입교 절차는 3단계로 구성되어 있습니다...")
    private String guideSctnCtt;

    @Schema(description = "최초등록자사번", example = "EMP00123")
    private String frstRegrEmpno;

    @Schema(description = "수정등록자사번", example = "EMP00123")
    private String lstChgrEmpno;

}
