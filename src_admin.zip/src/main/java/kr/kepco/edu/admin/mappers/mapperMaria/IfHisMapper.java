package kr.kepco.edu.admin.mappers.mapperMaria;

import kr.kepco.edu.admin.dto.IfHisDTO;
import kr.kepco.edu.admin.request.IfHisReq;
import kr.kepco.edu.admin.response.Page;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface IfHisMapper {
    int selectIfHisListCnt(@Param("param") IfHisReq req);

    List<IfHisDTO> selectIfHisList(@Param("param") IfHisReq req, @Param("page") Page<IfHisDTO> page);
}
