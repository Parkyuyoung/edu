package kr.kepco.edu.admin.request;

import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.media.Schema;
import kr.kepco.edu.admin.validation.RequestGroup;
import lombok.Data;

@Data
@Schema(name = "AccessLogStatReq", description = "통계 요청 DTO")
public class AccessLogStatReq extends BaseRequest{

    @Schema(description = "조회 기간 타입", example = "1month / 3month / 6month / 1year")
    @JsonView(RequestGroup.Search.class)
    private String periodType;

    @Schema(description = "시작일자", example = "2025-10-01")
    @JsonView(RequestGroup.Search.class)
    private String startDate;

    @Schema(description = "종료일자", example = "2025-10-31")
    @JsonView(RequestGroup.Search.class)
    private String endDate;

    @Schema(description = "메뉴 ID", example = "MAIN")
    @JsonView(RequestGroup.Search.class)
    private String menuId;
}
