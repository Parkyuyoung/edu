package kr.kepco.edu.admin.request;

import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.media.Schema;

import kr.kepco.edu.admin.validation.RequestGroup;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaseRequest {

    @Schema(description = "현재 페이지 번호", example = "1")
    @JsonView({ RequestGroup.Search.class })
    private int currentPage = 1;

    @Schema(description = "페이지당 표시할 데이터 개수", example = "10")
    @JsonView({ RequestGroup.Search.class })
    private int pageSize = 10;

    @Schema(description = "검색타입", example = "10")
    @JsonView({ RequestGroup.Search.class })
    private String searchType;

    @Schema(description = "검색값", example = "테스트")
    @JsonView({ RequestGroup.Search.class })
    private String searchValue;

    @Schema(description = "시작일", example = "2025-10-20")
    @JsonView({ RequestGroup.Search.class })
    private String startDate;

    @Schema(description = "종료일", example = "2025-11-20")
    @JsonView({ RequestGroup.Search.class })
    private String endDate;
}