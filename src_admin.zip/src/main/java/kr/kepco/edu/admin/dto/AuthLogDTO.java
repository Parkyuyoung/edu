package kr.kepco.edu.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Schema(name = "AuthLogDTO", description = "권한 로그 DTO")
public class AuthLogDTO {
    @Schema(description = "순번", example = "1")
    private String rnum;

    @Schema(description = "로그 일련번호", example = "BNR00001")
    private String logSerno;

    @Schema(description = "최초등록일시", example = "2025-10-20T14:30:00")
    private LocalDateTime frstRegDt;

    @Schema(description = "최초등록자사번", example = "EMP00123")
    private String frstRegrEmpno;

    @Schema(description = "최종변경일시", example = "2025-10-20T15:45:00")
    private LocalDateTime lstChgDt;

    @Schema(description = "최종변경자사번", example = "EMP00456")
    private String lstChgrEmpno;

    @Schema(description = "최종변경자이름", example = "김철수")
    private String lstChgrEmpnm;

    @Schema(description = "사번", example = "11111111")
    private String userId;

    @Schema(description = "이름", example = "홍길동")
    private String userNm;

    @Schema(description = "부서명", example = "ICT운영처")
    private String userDeptNm;

    @Schema(description = "직급", example = "3직급")
    private String userLevelNm;

    @Schema(description = "직급명", example = "모바일담당")
    private String userTitle;

    @Schema(description = "권한코드", example = "sys")
    private String eduAuthCd;

    @Schema(description = "권한명", example = "시스템총괄관리자")
    private String eduAuthNm;

    @Schema(description = "로그내용(변경사항)", example = "변경사항 (1:부여, 2:말소, 3: 권한변경) ")
    private String logCtt;
}
