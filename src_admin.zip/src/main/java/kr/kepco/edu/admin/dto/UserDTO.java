package kr.kepco.edu.admin.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Data
public class UserDTO {
    private String userId;
    private String userNm;
    private String edamsAuthCd;
    private LocalDateTime frstRegDt;
    private String frstRegrEmpno;
    private LocalDateTime lstChgDt;
    private String lstChgrEmpno;
    private String userDeptNm;
    private String delYn;
    private String suerDeptNm;
    private List<String> menuIds;
    private Set<String> roles = new HashSet<>();
}