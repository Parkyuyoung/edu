package kr.kepco.edu.admin.controller;

import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import kr.kepco.edu.admin.dto.GuideDTO;
import kr.kepco.edu.admin.dto.NoticeDTO;
import kr.kepco.edu.admin.request.*;
import kr.kepco.edu.admin.response.ApiListResponse;
import kr.kepco.edu.admin.validation.ErrorCode;
import kr.kepco.edu.admin.dto.InfoDetailDTO;
import kr.kepco.edu.admin.dto.InfoMasterDTO;
import kr.kepco.edu.admin.response.ApiResponse;
import kr.kepco.edu.admin.response.Page;
import kr.kepco.edu.admin.service.CustomUserDetails;
import kr.kepco.edu.admin.service.InfoService;
import kr.kepco.edu.admin.util.CommonUtil;
import kr.kepco.edu.admin.validation.RequestGroup;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Tag(name = "09.시설안내/안전정보/오시는길", description = "시설안내/안전정보/오시는길 관리")
@RestController
@RequestMapping("${base.url}/info")
public class InfoController {

    @Autowired
    InfoService infoService;

    @Operation(
            summary = "안내정보 목록 조회",
            description = "안내정보 목록 조회",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = InfoMasterReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "시설안내",
                                            value = "{ \"measInfoClCd\": \"FACILITY\" }"
                                    ),
                                    @ExampleObject(
                                            name = "안전정보",
                                            value = "{ \"measInfoClCd\": \"SAFETY\" }"
                                    ),
                                    @ExampleObject(
                                            name = "오시는길",
                                            value = "{ \"measInfoClCd\": \"FACILITY\" }"
                                    )
                            }
                    )
            )
    )
    @PostMapping(value = "/getInfoListAll" , consumes = "application/json", produces = "application/json")
    public ApiResponse<Page<InfoDetailDTO>> getInfoListAll(@AuthenticationPrincipal CustomUserDetails user, @RequestBody InfoDetailReq req) {

        Page<InfoDetailDTO> page = new Page<>(req.getCurrentPage(),req.getPageSize(), infoService.selectInfoListCntAll(req));
        page.setContent(infoService.selectInfoListAll(req, page));

        if (CommonUtil.isValid(page.getContent())) {
            return ApiResponse.ok(HttpStatus.OK, page, "OK");
        } else {
            return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }
    }

    @Operation(
            summary = "정보 상세 단건 조회",
            description = "정보 상세 조회",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = InfoDetailReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "상세 조회",
                                            value = "{ \"dtlsInfoSerno\": \"INFOD00001\" }"
                                    ),
                            }
                    )
            )
    )
    @PostMapping(value = "/getInfoDetailOne" , consumes = "application/json", produces = "application/json")
    public ApiResponse<InfoDetailDTO> getInfoDetailOne(@AuthenticationPrincipal CustomUserDetails user, @RequestBody InfoDetailReq req) {

        if(!CommonUtil.isValid(req.getDtlsInfoSerno())) {
            return ApiResponse.fail(ErrorCode.REQ_MISSING_PARAM);
        }

        InfoDetailDTO infoDetailDTO = infoService.selectInfoDetailOne(req);

        if(CommonUtil.isValid(infoDetailDTO)) {
            return ApiResponse.ok(HttpStatus.OK, infoDetailDTO, "OK");
        } else {
            return ApiResponse.fail(ErrorCode.VAL_VALUE_EMPTY);
        }
    }

    @PostMapping("/getInfoMasterList")
    public ApiListResponse<InfoMasterDTO> getInfoMasterList(@AuthenticationPrincipal CustomUserDetails user, @RequestBody InfoMasterReq dto) {
        return ApiListResponse.ok(HttpStatus.OK, infoService.getInfoMasterList(dto), "OK");
    }

    @PostMapping("/getInfoPstnCnt")
    public ApiResponse<Integer> getMasterPstnCnt(@AuthenticationPrincipal CustomUserDetails user, @RequestBody InfoMasterReq dto) {
        return ApiResponse.ok(HttpStatus.OK, infoService.getInfoMasterPstnCnt(dto), "OK");
    }

    @Operation(
            summary = "안내정보 등록",
            description = "안내정보 등록",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = InfoMasterReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "시설정보 등록",
                                            value = "{ \"measInfoClCd\": \"FACILITY\"" +
                                                    ", \"grpTitlNm\": \"건물배치도\" }"
                                    ),
                                    @ExampleObject(
                                            name = "안전정보 등록",
                                            value = "{ \"measInfoClCd\": \"SAFETY\"" +
                                                    ", \"grpTitlNm\": \"기숙사\" }"
                                    ),
                                    @ExampleObject(
                                            name = "오시는길 등록",
                                            value = "{ \"measInfoClCd\": \"ROUTE\"" +
                                                    ", \"grpTitlNm\": \"지도\" }"
                                    ),

                            }
                    )
            )
    )
    @PostMapping(value = "/insInfoM" , consumes = "application/json", produces = "application/json")
    public ApiResponse<String> insertInfoMaster(@AuthenticationPrincipal CustomUserDetails user, @RequestBody InfoMasterReq req) {
        /** 유효성 검증 - String인 경우 null이나 빈 값, 특수문자 변환 */
        if (!CommonUtil.sanitizeDto(req, "measInfoClCd", "grpTitlNm")) {
            return ApiResponse.fail(ErrorCode.VAL_INVALID);
        }

        /** 등록자 사번 추가 */
        req.setFrstRegrEmpno(user.getUsername());
        req.setLstChgrEmpno(user.getUsername());

        int i = infoService.insertInfoMaster(req);

        if(i>0){
            return ApiResponse.ok(HttpStatus.OK, "정상적으로 등록되었습니다." , "OK");
        } else {
            return ApiResponse.fail(ErrorCode.INSERT_INTERNAL);
        }
    }

    @Operation(
            summary = "안내 상세정보 등록",
            description = "안내 상세정보 등록",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = InfoMasterReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "시설 상세정보 등록",
                                            value = "{ \"infoSerno\": \"INFOM00001\"" +
                                                    ", \"dtlsInfoTitlNm\": \"1층\" " +
                                                    ", \"dtlsInfoCtt\": \"내용입니다\" }"
                                    ),
                                    @ExampleObject(
                                            name = "안전 상세정보 등록",
                                            value = "{ \"infoSerno\": \"INFOM00002\"" +
                                                    ", \"dtlsInfoTitlNm\": \"1층\" " +
                                                    ", \"dtlsInfoCtt\": \"안전 관리 내용입니다\" }"
                                    ),
                                    @ExampleObject(
                                            name = "오시는길 상세정보 등록",
                                            value = "{ \"infoSerno\": \"INFOM00003\"" +
                                                    ", \"dtlsInfoTitlNm\": \"1층\" " +
                                                    ", \"dtlsInfoCtt\": \"오시는길 내용입니다\" }"
                                    ),
                            }
                    )
            )
    )
    @PostMapping(value = "/insInfoD" ,
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse<String> insertInfoDetail(@AuthenticationPrincipal CustomUserDetails user,
                                                 @RequestPart("infoReq") String infoReqJson,
                                                 @RequestPart(value = "mFile",required = false) MultipartFile mFile) throws Exception  {

        InfoDetailReq infoReq = new ObjectMapper().readValue(infoReqJson, InfoDetailReq.class);

        /** 유효성 검증 - String인 경우 null이나 빈 값, 특수문자 변환 */
        if (!CommonUtil.sanitizeDto(infoReq, "infoSerno","dtlsInfoTitlNm")) {
            return ApiResponse.fail(ErrorCode.VAL_INVALID);
        }

        /** 등록자 사번 추가 */
        infoReq.setFrstRegrEmpno(user.getUsername());
        infoReq.setLstChgrEmpno(user.getUsername());

        if(infoService.insertInfoDetail(infoReq, mFile)){
            return ApiResponse.ok(HttpStatus.OK, "등록에 성공하였습니다.","OK");
        } else {
            return ApiResponse.fail(ErrorCode.INSERT_INTERNAL);
        }
    }


    @Operation(
            summary = "안내 상세정보 수정",
            description = "안내 상세정보 수정",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = InfoMasterReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "시설 상세정보 수정",
                                            value = "{ \"dtlsInfoSerno\": \"INFOD00001\"" +
                                                    ", \"infoSerno\": \"INFOM00001\" " +
                                                    ", \"dtlsInfoTitlNm\": \"1층ㅎ수정ㅎ\" " +
                                                    ", \"dtlsInfoCtt\": \"내용입니다ㅋㅋㅋ\" }"
                                    ),
                                    @ExampleObject(
                                            name = "안전 상세정보 수정",
                                            value = "{ \"dtlsInfoSerno\": \"INFOD00002\"" +
                                                    ", \"infoSerno\": \"INFOM00002\" " +
                                                    ", \"dtlsInfoTitlNm\": \"1층ㅎ수정ㅎ\" " +
                                                    ", \"dtlsInfoCtt\": \"안전 관리 내용입니다ㅎㅎㅎ\" }"
                                    ),
                                    @ExampleObject(
                                            name = "오시는길 상세정보 수정",
                                            value = "{ \"dtlsInfoSerno\": \"INFOD00003\"" +
                                                    ", \"infoSerno\": \"INFOM00003\" " +
                                                    ", \"dtlsInfoTitlNm\": \"1층ㅎ수정ㅎ\" " +
                                                    ", \"dtlsInfoCtt\": \"오시는길 내용입니다ㅍㅍㅍ\" }"
                                    ),
                            }
                    )
            )
    )
    @PostMapping(value = "/updInfoD" ,
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse<String> updateInfoDetail(@AuthenticationPrincipal CustomUserDetails user, @RequestPart("infoReq") String infoReqJson,
                                                @RequestPart(value = "mFile",required = false) MultipartFile mFile) throws Exception {

        InfoDetailReq infoReq = new ObjectMapper().readValue(infoReqJson, InfoDetailReq.class);

        /** 기준값 없으면 return */
        if(!CommonUtil.isValid(infoReq.getDtlsInfoSerno())) {
            return ApiResponse.fail(ErrorCode.REQ_MISSING_PARAM);
        }

        /** 유효성 검증 - String인 경우 null이나 빈 값, 특수문자 변환 */
        if (!CommonUtil.sanitizeDto(infoReq, "dtlsInfoSerno", "infoSerno")) {
            return ApiResponse.fail(ErrorCode.VAL_INVALID);
        }

        /** 수정자 사번 추가 */
        infoReq.setLstChgrEmpno(user.getUsername());

        if(infoService.updateInfoDetail(infoReq, mFile)){
            return ApiResponse.ok(HttpStatus.OK, "정상적으로 수정되었습니다." , "OK");
        } else {
            return ApiResponse.fail(ErrorCode.INSERT_INTERNAL);
        }
    }

    @Operation(
            summary = "안내정보 삭제",
            description = "안내정보 삭제",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = InfoMasterReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "시설정보 삭제",
                                            value = "{ \"dtlsInfoSerno\": \"INFOM00001\" }"
                                    ),
                                    @ExampleObject(
                                            name = "안전정보 삭제",
                                            value = "{ \"dtlsInfoSerno\": \"INFOM00002\" }"
                                    ),
                                    @ExampleObject(
                                            name = "오시는길 삭제",
                                            value = "{ \"dtlsInfoSerno\": \"INFOM00003\" }"
                                    ),

                            }
                    )
            )
    )
    @PostMapping(value = "/delInfoM" , consumes = "application/json", produces = "application/json")
    public ApiResponse<String> deleteInfoMaster(@AuthenticationPrincipal CustomUserDetails user, @RequestBody InfoMasterReq req) {

        /** 기준값 없으면 return */
        if(!CommonUtil.isValid(req.getInfoSerno())) {
            return ApiResponse.fail(ErrorCode.REQ_MISSING_PARAM);
        }

        /** 수정자 사번 추가 */
        req.setLstChgrEmpno(user.getUsername());

        int i = infoService.deleteInfoMaster(req);

        if(i>0){
            return ApiResponse.ok(HttpStatus.OK, "정상적으로 삭제되었습니다." , "OK");
        } else {
            return ApiResponse.fail(ErrorCode.INSERT_INTERNAL);
        }
    }


    @Operation(
            summary = "안내 상세정보 삭제",
            description = "안내 상세정보 삭제",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = InfoMasterReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "시설 상세정보 삭제",
                                            value = "{ \"dtlsInfoSerno\": \"INFOD00001\" }"
                                    ),
                                    @ExampleObject(
                                            name = "안전 상세정보 삭제",
                                            value = "{ \"dtlsInfoSerno\": \"INFOD00002\" }"
                                    ),
                                    @ExampleObject(
                                            name = "오시는길 상세정보 삭제",
                                            value = "{ \"dtlsInfoSerno\": \"INFOD00003\" }"
                                    ),
                            }
                    )
            )
    )
    @PostMapping(value = "/delInfoD" , consumes = "application/json", produces = "application/json")
    public ApiResponse<String> deleteInfoDetail(@AuthenticationPrincipal CustomUserDetails user, @RequestBody InfoDetailReq req) {

        /** 기준값 없으면 return */
        if(!CommonUtil.isValid(req.getDtlsInfoSerno())) {
            return ApiResponse.fail(ErrorCode.REQ_MISSING_PARAM);
        }

        /** 수정자 사번 추가 */
        req.setLstChgrEmpno(user.getUsername());

        int i = infoService.deleteInfoDetail(req);
        if(i>0){
            return ApiResponse.ok(HttpStatus.OK, "정상적으로 삭제되었습니다." , "OK");
        } else {
            return ApiResponse.fail(ErrorCode.INSERT_INTERNAL);
        }
    }
}
