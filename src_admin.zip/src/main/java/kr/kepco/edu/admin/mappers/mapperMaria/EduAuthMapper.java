package kr.kepco.edu.admin.mappers.mapperMaria;

import kr.kepco.edu.admin.dto.EduAuthDTO;
import kr.kepco.edu.admin.request.EduAuthReq;
import kr.kepco.edu.admin.response.Page;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface EduAuthMapper {
    int selectEduAuthListCnt(@Param("param") EduAuthReq eduAuthReq);
    List<EduAuthDTO> selectEduAuthList(@Param("param") EduAuthReq eduAuthReq, @Param("page") Page<EduAuthDTO> page);
    int insertEduAuth(EduAuthReq param);

    int updateEduAuth(EduAuthReq param);

    int deleteEduAuth(EduAuthReq param);

    int deleteEduAuthUsers(EduAuthReq param);

    int selectEduAuthCdDupCnt(@Param("param") EduAuthReq eduAuthReq);

    int selectEduAuthNmDupCnt(@Param("param") EduAuthReq eduAuthReq);

    List<EduAuthDTO> selectAuthFilter();

}
