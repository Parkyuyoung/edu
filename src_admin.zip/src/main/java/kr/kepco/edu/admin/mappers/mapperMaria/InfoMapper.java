package kr.kepco.edu.admin.mappers.mapperMaria;

import kr.kepco.edu.admin.dto.IfHisDTO;
import kr.kepco.edu.admin.dto.InfoDetailDTO;
import kr.kepco.edu.admin.dto.InfoMasterDTO;
import kr.kepco.edu.admin.request.InfoDetailReq;
import kr.kepco.edu.admin.request.InfoMasterReq;
import kr.kepco.edu.admin.response.Page;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface InfoMapper {
    int insertInfoMaster(InfoMasterReq req);

    int insertInfoDetail(InfoDetailReq req);

    int updateInfoDetail(InfoDetailReq req);

    int deleteInfoMaster(InfoMasterReq req);

    int deleteInfoDetail(InfoDetailReq req);

    int selectInfoListCntAll(@Param("param") InfoDetailReq req);

    List<InfoDetailDTO> selectInfoListAll(@Param("param") InfoDetailReq req, @Param("page") Page<InfoDetailDTO> page);

    InfoDetailDTO selectInfoDetailOne(InfoDetailReq req);

    List<InfoMasterDTO> selectInfoMasterList(InfoMasterReq dto);

    Integer selectInfoMasterPstnCnt(InfoMasterReq dto);

    int updateInfoMasterSortOrder(InfoDetailReq dto);
}
