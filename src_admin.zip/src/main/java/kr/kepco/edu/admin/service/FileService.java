package kr.kepco.edu.admin.service;

import kr.kepco.edu.admin.dto.FileDTO;
import kr.kepco.edu.admin.mappers.mapperMaria.FileMapper;
import kr.kepco.edu.admin.util.FileUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

@Slf4j
@Service
@RequiredArgsConstructor
public class FileService {

    private final FileMapper fileMapper;

    @Value("${file.upload.path}")
    private String uploadRoot; // ex) "./files/"

    /**
     * 파일 등록 (물리 저장 + DB Insert)
     * 트랜잭션 내에서 예외 발생 시 롤백, 물리 파일도 정리.
     */
    @Transactional(rollbackFor = Exception.class)
    public FileDTO register(MultipartFile file,
                            String menu,
                            String menuSerno,
                            String type,
                            Integer sortNo,
                            String category,
                            String empno
    ) {

        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("업로드할 파일이 없습니다.");
        }

        Path root = Paths.get(uploadRoot).toAbsolutePath().normalize();
        String fileUrl = null;
        String relPath = null;

        try {
            fileUrl = FileUtil.save(file, root, category);   // ex) "/files/banner/2025/10/26/uuid.png"
            relPath = fileUrl.substring("/files/".length());

            FileDTO vo = new FileDTO();
            vo.setMenuSerno(menuSerno);
            vo.setType(type);
            vo.setFilePthNm(relPath);
            vo.setFilePthCtt(fileUrl);
            vo.setOrgsFileNm(file.getOriginalFilename());
            vo.setSavFileNm(relPath.substring(relPath.lastIndexOf('/') + 1));
            vo.setFextNm(extractExt(vo.getSavFileNm()));
            vo.setUpldFileMimeTpNm(file.getContentType());
            vo.setFileSizeCpct(file.getSize());
            vo.setSortSeqo(sortNo == null ? 0 : sortNo);
            vo.setDelYn("N");
            vo.setFrstRegrEmpno(empno);
            vo.setLstChgrEmpno(empno);

            fileMapper.insertFile(vo);

            log.info("[FileService] File 등록 성공 - FILE_SERNO={}, {}", vo.getFileSerno(), vo.getFilePthCtt());
            return vo;

        } catch (IOException e) {
            log.error("[FileService] 파일 저장 중 오류", e);
            throw new RuntimeException("파일 저장 실패: " + e.getMessage(), e);

        } catch (DataAccessException e) {
            log.error("[FileService] DB 처리 오류", e);
            cleanupFileSafe(fileUrl);
            throw new RuntimeException("DB 처리 중 오류 발생", e);

        } catch (Exception e) {
            log.error("[FileService] 예상치 못한 예외 발생", e);
            cleanupFileSafe(fileUrl);
            throw new RuntimeException("파일 등록 중 알 수 없는 오류가 발생했습니다.", e);
        }
    }

    @Transactional(rollbackFor = Exception.class)
    public void delete(Long fileSerno, String empno, boolean hardDelete) {
        FileDTO vo = fileMapper.selectFile(fileSerno);
        if (vo == null) {
            throw new IllegalArgumentException("해당 파일 정보가 존재하지 않습니다.");
        }
        if ("Y".equals(vo.getDelYn())) {
            log.warn("[FileService] 이미 삭제된 파일입니다. FILE_SERNO={}", fileSerno);
            return;
        }

        try {
            fileMapper.deleteFile(fileSerno, empno);
            log.info("[FileService] 파일 소프트 삭제 완료 FILE_SERNO={}", fileSerno);

            if (hardDelete) {
                Path root = Paths.get(uploadRoot).toAbsolutePath().normalize();
                FileUtil.deleteByUrl(vo.getFilePthCtt(), root);
                log.info("[FileService] 파일 물리 삭제 완료 FILE_SERNO={}", fileSerno);
            }

        } catch (IOException e) {
            log.error("[FileService] 파일 삭제 실패", e);
            throw new RuntimeException("파일 삭제 실패: " + e.getMessage(), e);

        } catch (DataAccessException e) {
            log.error("[FileService] DB 삭제 처리 중 오류", e);
            throw new RuntimeException("DB 삭제 처리 중 오류 발생", e);

        } catch (Exception e) {
            log.error("[FileService] 삭제 중 알 수 없는 오류", e);
            throw new RuntimeException("파일 삭제 중 오류가 발생했습니다.", e);
        }
    }

    //@Transactional(rollbackFor = Exception.class)
    public void deleteSearch(String fileSerno, String empno,String menu , String type ,boolean hardDelete) {
        FileDTO vo = fileMapper.selectMenuFile(fileSerno,menu,type);
        if (vo == null) {
            log.warn("[FileService] 해당 파일 정보가 존재하지 않습니다. FILE_SERNO={}", fileSerno);
            return;
            //throw new IllegalArgumentException("해당 파일 정보가 존재하지 않습니다.");
        }
        if ("Y".equals(vo.getDelYn())) {
            log.warn("[FileService] 이미 삭제된 파일입니다. FILE_SERNO={}", fileSerno);
            return;
        }

        try {
            fileMapper.deleteFile(Long.parseLong(vo.getFileSerno()), empno);
            log.info("[FileService] 파일 소프트 삭제 완료 FILE_SERNO={}", fileSerno);

            if (hardDelete) {
                Path root = Paths.get(uploadRoot).toAbsolutePath().normalize();
                FileUtil.deleteByUrl(vo.getFilePthCtt(), root);
                log.info("[FileService] 파일 물리 삭제 완료 FILE_SERNO={}", fileSerno);
            }

        } catch (IOException e) {
            log.error("[FileService] 파일 삭제 실패", e);
            throw new RuntimeException("파일 삭제 실패: " + e.getMessage(), e);

        } catch (DataAccessException e) {
            log.error("[FileService] DB 삭제 처리 중 오류", e);
            throw new RuntimeException("DB 삭제 처리 중 오류 발생", e);

        } catch (Exception e) {
            log.error("[FileService] 삭제 중 알 수 없는 오류", e);
            throw new RuntimeException("파일 삭제 중 오류가 발생했습니다.", e);
        }
    }

    /** 안전하게 물리 파일 삭제 시도 (실패해도 무시) */
    private void cleanupFileSafe(String fileUrl) {
        if (fileUrl == null || fileUrl.isBlank()) return;
        try {
            Path root = Paths.get(uploadRoot).toAbsolutePath().normalize();
            FileUtil.deleteByUrl(fileUrl, root);
            log.info("[FileService] 롤백 중 파일 정리 완료: {}", fileUrl);
        } catch (Exception ex) {
            log.warn("[FileService] 롤백 중 파일 정리 실패: {}", fileUrl, ex);
        }
    }

    private static String extractExt(String name) {
        if (name == null) return null;
        int i = name.lastIndexOf('.');
        return (i > -1 && i < name.length() - 1) ? name.substring(i + 1).toLowerCase() : null;
    }
}
