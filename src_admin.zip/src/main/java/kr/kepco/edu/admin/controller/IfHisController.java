package kr.kepco.edu.admin.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import kr.kepco.edu.admin.validation.ErrorCode;
import kr.kepco.edu.admin.dto.IfHisDTO;
import kr.kepco.edu.admin.request.IfHisReq;
import kr.kepco.edu.admin.request.NoticeReq;
import kr.kepco.edu.admin.response.ApiResponse;
import kr.kepco.edu.admin.response.Page;
import kr.kepco.edu.admin.service.CustomUserDetails;
import kr.kepco.edu.admin.service.IfHisService;
import kr.kepco.edu.admin.util.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "06.연계이력관리", description = "연계이력 관리")
@RestController
@RequestMapping("${base.url}/ifhis")
public class IfHisController {

    @Autowired
    IfHisService ifHisService;

    @Operation(
            summary = "연계이력 목록",
            description = "연계이력 목록 조회",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = NoticeReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "전체 검색",
                                            value = "{ \"currentPage\": \"1\" , \"pageSize\": \"10\" }"
                                    ),
                                    @ExampleObject(
                                            name = "등록자 검색",
                                            value = "{ \"mngrId\": \"11112223\" , \"currentPage\": \"1\" , \"pageSize\": \"10\" }"
                                    )
                            }
                    )
            )
    )
    @PostMapping(value = "/getIfHisList" , consumes = "application/json", produces = "application/json")
    public ApiResponse<Page<IfHisDTO>> getIfHisList(@AuthenticationPrincipal CustomUserDetails user, @RequestBody IfHisReq req) {

        Page<IfHisDTO> page = new Page<>(req.getCurrentPage(),req.getPageSize(), ifHisService.selectIfHisListCnt(req));
        page.setContent(ifHisService.selectIfHisList(req,page));

        if (CommonUtil.isValid(page.getContent())) {
            return ApiResponse.ok(HttpStatus.OK, page, "OK");
        } else {
            return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }
    }
}
