package kr.kepco.edu.admin.request;

import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.media.Schema;
import kr.kepco.edu.admin.validation.RequestGroup;
import lombok.Data;

import java.util.List;

@Data
@Schema(name = "AccessLogReq", description = "시스템 접속 이력 목록 조회 요청 DTO")
public class AccessLogReq extends BaseRequest {
    @Schema(description = "시작일자", example = "2025-10-12")
    @JsonView(RequestGroup.Search.class)
    private String startDate;

    @Schema(description = "종료일자", example = "2025-10-31")
    @JsonView(RequestGroup.Search.class)
    private String endDate;

    @Schema(description = "검색타입", example = "nm/no")
    @JsonView(RequestGroup.Search.class)
    private String srchType;

    @Schema(description = "검색값(사번)", example = "11112223")
    @JsonView(RequestGroup.Search.class)
    private String srchEmpNo;

    @Schema(description = "검색값(사번)", example = "11112223")
    @JsonView(RequestGroup.Search.class)
    private List<String> srchEmpNos;

    @Schema(description = "검색값(이름)", example = "11112223")
    @JsonView(RequestGroup.Search.class)
    private String srchEmpNm;

    @Schema(description = "메뉴명", example = "시스템접속이력")
    @JsonView(RequestGroup.Search.class)
    private String menuNm;


    @Schema(description = "권한", example = "SYS")
    @JsonView(RequestGroup.Search.class)
    private String srchAuthCd;
}
