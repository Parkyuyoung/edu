package kr.kepco.edu.admin.controller;

import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import kr.kepco.edu.admin.validation.ErrorCode;
import kr.kepco.edu.admin.validation.RequestGroup;
import kr.kepco.edu.admin.dto.MealDTO;
import kr.kepco.edu.admin.request.MealReq;
import kr.kepco.edu.admin.response.ApiResponse;
import kr.kepco.edu.admin.response.Page;
import kr.kepco.edu.admin.service.CustomUserDetails;
import kr.kepco.edu.admin.service.FileService;
import kr.kepco.edu.admin.service.MealService;
import kr.kepco.edu.admin.util.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Tag(name = "03.주간식단", description = "주간식단 게시판")
@RestController
@RequestMapping("${base.url}/meal")
public class MealController {

    @Autowired
    MealService mealService;

    @Autowired
    FileService fileService;

    @Operation(
            summary = "주간식단 등록",
            description = "MealDTO(JSON) + 파일 업로드",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "MediaType.MULTIPART_FORM_DATA_VALUE",
                            schema = @Schema(implementation = MealReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "저장 칼럼",
                                            value = "{ \"planYear\": \"2025\", " +
                                                    "\"planMonth\": \"3\"," +
                                                    "\"planWeekNo\": \"1\"," +
                                                    "\"weekMealPlanTtlNm\": \"제목 예시\"}"
                                    )
                            }
                    )
            )
    )
    @PostMapping(value = "/insMeal",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse<String> insertMeal(@AuthenticationPrincipal CustomUserDetails user, @RequestPart("mealReq") String mealReqJson,
                                              @RequestPart(value = "mFile",required = false) MultipartFile mFile
    ) throws Exception {

        MealReq mealReq = new ObjectMapper().readValue(mealReqJson, MealReq.class);

        if(!CommonUtil.isValid(mealReq.getWklyMealplTitlNm()) || !CommonUtil.isValid(mealReq.getWklyMealplYy()) || !CommonUtil.isValid(mealReq.getWklyMealplWkcnt())) {
            return ApiResponse.fail(ErrorCode.REQ_MISSING_PARAM);
        }

        int i = mealService.existsYearWeek(mealReq);

        if (i > 0) {
            return ApiResponse.fail(ErrorCode.RES_DUPLICATED);
        }

        mealReq.setFrstRegrEmpno(user.getUsername());
        mealReq.setLstChgrEmpno(user.getUsername());

        if(mealService.insertMealList(mealReq, mFile)) {
            return ApiResponse.ok(HttpStatus.OK, "등록에 성공하였습니다.","OK");
        } else {
            return ApiResponse.fail(ErrorCode.INSERT_INTERNAL);
        }
    }

    @Operation(
            summary = "주간식단 수정",
            description = "MealDTO(JSON) + 파일 업로드",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "MediaType.MULTIPART_FORM_DATA_VALUE",
                            schema = @Schema(implementation = MealReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "저장 칼럼",
                                            value = "{ \"eduWeeklyMealPlanSerno\": \"1\", " +
                                                    "\"planYear\": \"2025\"," +
                                                    "\"planMonth\": \"3\"," +
                                                    "\"planWeekNo\": \"1\"," +
                                                    "\"weekMealPlanTtlNm\": \"제목 예시\"}"
                                    )
                            }
                    )
            )
    )
    @PostMapping(value = "/updMeal",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse<String> updateMealList(@AuthenticationPrincipal CustomUserDetails user, @RequestPart("mealReq") String mealReqJson,
                                              @RequestPart(value = "mFile",required = false) MultipartFile mFile
    ) throws Exception {

        MealReq mealReq = new ObjectMapper().readValue(mealReqJson, MealReq.class);

        if(!CommonUtil.isValid(mealReq.getWklyMealplTitlNm()) || !CommonUtil.isValid(mealReq.getWklyMealplYy()) || !CommonUtil.isValid(mealReq.getWklyMealplWkcnt())) {
            return ApiResponse.fail(ErrorCode.REQ_MISSING_PARAM);
        }
        MealDTO mealDTO = mealService.selectMealDetail(mealReq);

        if(!mealDTO.getWklyMealplYy().equals(mealReq.getWklyMealplYy()) && mealDTO.getWklyMealplWkcnt().equals(mealReq.getWklyMealplWkcnt()) ) {
            int i = mealService.existsYearWeek(mealReq);
            if (i > 0) {
                return ApiResponse.fail(ErrorCode.RES_DUPLICATED);
            }
        }

        mealReq.setLstChgrEmpno(user.getUsername());

        if(mealService.updateMealList(mealReq, mFile)) {
            return ApiResponse.ok(HttpStatus.OK,"수정이 정상적으로 처리되었습니다.", "OK");
        } else {
            return ApiResponse.fail(ErrorCode.DELETE_INTERNAL);
        }
    }


    @Operation(
            summary = "주간식단 리스트 조회",
            description = "주간식단 전체 목록 조회",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = MealReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "전체 검색",
                                            value = "{ \"currentPage\": \"1\" , \"pageSize\": \"10\" }"
                                    ),
                                    @ExampleObject(
                                            name = "제목 검색",
                                            value = "{ \"weekMealPlanTtlNm\": \"2025년 2주차 주간식단\" , \"currentPage\": \"1\" , \"pageSize\": \"10\" }"
                                    )
                            }
                    )
            )
    )
    @PostMapping(value = "/getMealList", consumes = "application/json", produces = "application/json")
    public ApiResponse<Page<MealDTO>> selectMealList(@AuthenticationPrincipal CustomUserDetails user, @RequestBody @JsonView(RequestGroup.Search.class) MealReq req
    ) {

        Page<MealDTO> page = new Page<>(req.getCurrentPage(), req.getPageSize(), mealService.selectMealListCnt(req));
        page.setContent(mealService.selectMealList(req,page));

        if(CommonUtil.isValid(page.getContent())){
            return ApiResponse.ok(HttpStatus.OK, page, "OK");
        } else {
            return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }
    }

    @Operation(
            summary = "주간식단 상세",
            description = "주간식단 상세 조회",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = MealReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "상세 조회",
                                            value = "{ \"eduWeeklyMealPlanSerno\": \"1\" }"
                                    ),
                            }
                    )
            )
    )
    @PostMapping(value = "/getMealDetail" , consumes = "application/json", produces = "application/json")
    public ApiResponse<MealDTO> getNoticeDetail(@AuthenticationPrincipal CustomUserDetails user, @RequestBody @JsonView(RequestGroup.Detail.class) MealReq req) {

        if(!CommonUtil.isValid(req.getWklyMealplSerno())) {
            return ApiResponse.fail(ErrorCode.REQ_MISSING_PARAM);
        }

        MealDTO mealDTO = mealService.selectMealDetail(req);
        if(CommonUtil.isValid(mealDTO)){
            return ApiResponse.ok(HttpStatus.OK, mealDTO, "OK");
        } else {
            return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }
    }

    @Operation(
            summary = "주간식단 삭제",
            description = "주간식단 삭제",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = MealReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "삭제",
                                            value = "{ \"eduWeeklyMealPlanSerno\": \"1\" }"
                                    ),
                            }
                    )
            )
    )
    @PostMapping(value = "/delMeal" , consumes = "application/json", produces = "application/json")
    public ApiResponse<String> deleteMeal(@AuthenticationPrincipal CustomUserDetails user, @RequestBody @JsonView(RequestGroup.Detail.class) MealReq req) {

        if(!CommonUtil.isValid(req.getWklyMealplSerno())) {
            return ApiResponse.fail(ErrorCode.REQ_MISSING_PARAM);
        }
        req.setLstChgrEmpno(user.getUsername());

        if(mealService.deleteMeal(req)) {
            return ApiResponse.ok(HttpStatus.OK,"정상적으로 삭제되었습니다.","ok");
        } else {
            return ApiResponse.fail(ErrorCode.DELETE_INTERNAL);
        }
    }
}
