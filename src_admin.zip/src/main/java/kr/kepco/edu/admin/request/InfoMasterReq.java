package kr.kepco.edu.admin.request;

import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.media.Schema;
import kr.kepco.edu.admin.validation.RequestGroup;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Schema(name = "InfoMasterReq", description = "요청 DTO(그룹: Create/Update/Search). viewType으로 응답 형태 지정")
public class InfoMasterReq extends BaseRequest {

    @Schema(description = "안내 정보 일련번호", example = "1")
    @JsonView(RequestGroup.Search.class)
    private String infoSerno;

    @Schema(description = "최초등록자사번", example = "EMP00123")
    private String frstRegrEmpno;

    @Schema(description = "최종변경자사번", example = "EMP00456")
    private String lstChgrEmpno;

    @Schema(description = "정보구분", example = "FACILITY")
    @JsonView(RequestGroup.Search.class)
    private String measInfoClCd;

    @Schema(description = "그룹명", example = "건물배치도")
    private String grpTitlNm;

    @Schema(description = "정렬순서", example = "1")
    private String scrSortSeqo;
}
