package kr.kepco.edu.admin.mappers.mapperOracle;

import kr.kepco.edu.admin.dto.UserDTO;
import kr.kepco.edu.admin.request.LoginRequest;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper {
    UserDTO loginUser(String empNo);

    int chkPassword(LoginRequest req);
}