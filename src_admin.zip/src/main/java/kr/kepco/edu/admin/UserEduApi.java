package kr.kepco.edu.admin;

import kr.kepco.edu.admin.client.EduClient;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin")
public class UserEduApi {
    private final EduClient edu;

    public UserEduApi(EduClient e) {
        this.edu = e;
    }

    @GetMapping("/edu-courses")
    public java.util.List<String> c() {
        return edu.getCourses();
    }
}