package kr.kepco.edu.admin.config;

import feign.FeignException;
import io.jsonwebtoken.ExpiredJwtException;
import io.swagger.v3.oas.annotations.Hidden;
import kr.kepco.edu.admin.response.ApiResponse;
import kr.kepco.edu.admin.validation.ErrorCode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.dao.CannotAcquireLockException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DeadlockLoserDataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingPathVariableException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.servlet.NoHandlerFoundException;

import javax.validation.ConstraintViolationException;
import java.nio.file.AccessDeniedException;
import java.sql.SQLSyntaxErrorException;
import java.util.stream.Collectors;

@Hidden
@Slf4j
@RestControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
public class GlobalExceptionHandler {

    // ===== 400/422 입력·유효성 =====
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiResponse<Void>> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
        String summary = ex.getBindingResult().getFieldErrors().stream()
                .map(fe -> fe.getField() + ":" + fe.getDefaultMessage())
                .collect(Collectors.joining(","));
        log.debug("400 VAL_INVALID {}", summary);
        return fail(ErrorCode.VAL_INVALID);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ApiResponse<Void>> handleConstraintViolation(ConstraintViolationException ex) {
        log.debug("422 VAL_INVALID {}", ex.getMessage());
        return fail(ErrorCode.VAL_INVALID);
    }

    @ExceptionHandler(MissingServletRequestParameterException.class)
    public ResponseEntity<ApiResponse<Void>> handleMissingParam(MissingServletRequestParameterException ex) {
        log.debug("400 REQ_MISSING_PARAM {}", ex.getParameterName());
        return fail(ErrorCode.REQ_MISSING_PARAM);
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ApiResponse<Void>> handleTypeMismatch(MethodArgumentTypeMismatchException ex) {
        log.debug("400 REQ_TYPE_MISMATCH {} -> {}", ex.getName(), ex.getRequiredType());
        return fail(ErrorCode.REQ_TYPE_MISMATCH);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ApiResponse<Void>> handleNotReadable(HttpMessageNotReadableException ex) {
        log.debug("400 REQ_MALFORMED_JSON {}", ex.getMessage());
        return fail(ErrorCode.REQ_MALFORMED_JSON);
    }

    @ExceptionHandler(MissingPathVariableException.class)
    public ResponseEntity<ApiResponse<Void>> handleMissingPathVar(MissingPathVariableException ex) {
        log.debug("400 REQ_MISSING_PARAM pathVar={}", ex.getVariableName());
        return fail(ErrorCode.REQ_MISSING_PARAM);
    }

    // ===== 405 / 415 / 406 / 413 =====
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<ApiResponse<Void>> handleMethodNotSupported(HttpRequestMethodNotSupportedException ex) {
        log.debug("405 REQ_METHOD {}", ex.getMethod());
        return fail(ErrorCode.REQ_METHOD);
    }

    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<ApiResponse<Void>> handleMediaTypeNotSupported(HttpMediaTypeNotSupportedException ex) {
        MediaType ct = ex.getContentType();
        log.debug("415 REQ_MEDIA_TYPE {}", ct);
        return fail(ErrorCode.REQ_MEDIA_TYPE);
    }

    @ExceptionHandler(HttpMediaTypeNotAcceptableException.class)
    public ResponseEntity<ApiResponse<Void>> handleNotAcceptable(HttpMediaTypeNotAcceptableException ex) {
        log.debug("406 REQ_NOT_ACCEPTABLE {}", ex.getSupportedMediaTypes());
        return fail(ErrorCode.REQ_NOT_ACCEPTABLE);
    }

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<ApiResponse<Void>> handleMaxUpload(MaxUploadSizeExceededException ex) {
        log.debug("413 REQ_PAYLOAD_TOO_LARGE limit={}", ex.getMaxUploadSize());
        return fail(ErrorCode.REQ_PAYLOAD_TOO_LARGE);
    }

    @ExceptionHandler(MultipartException.class)
    public ResponseEntity<ApiResponse<Void>> handleMultipart(MultipartException ex) {
        log.debug("400 FILE_MISSING {}", ex.getMessage());
        return fail(ErrorCode.FILE_MISSING);
    }

    // ===== 401 / 403 =====
    @ExceptionHandler(MissingRequestHeaderException.class)
    public ResponseEntity<ApiResponse<Void>> handleMissingHeader(MissingRequestHeaderException ex) {
        if ("Authorization".equalsIgnoreCase(ex.getHeaderName())) {
            log.debug("401 AUTH_TOKEN_MISSING");
            return fail(ErrorCode.AUTH_TOKEN_MISSING);
        }
        log.debug("400 REQ_MISSING_HEADER {}", ex.getHeaderName());
        return fail(ErrorCode.REQ_MISSING_HEADER);
    }

    @ExceptionHandler(ExpiredJwtException.class)
    public ResponseEntity<ApiResponse<Void>> handleExpired(ExpiredJwtException ex) {
        log.debug("401 AUTH_TOKEN_EXPIRED");
        return fail(ErrorCode.AUTH_TOKEN_EXPIRED);
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ApiResponse<Void>> handleDenied(AccessDeniedException ex) {
        log.debug("403 AUTH_FORBIDDEN");
        return fail(ErrorCode.AUTH_FORBIDDEN);
    }

    // ===== 404 =====
    @ExceptionHandler(NoHandlerFoundException.class)
    public ResponseEntity<ApiResponse<Void>> handle404(NoHandlerFoundException ex) {
        log.debug("404 RES_NOT_FOUND {}", ex.getRequestURL());
        return fail(ErrorCode.RES_NOT_FOUND);
    }

    // ===== DB 관련 예외 =====
    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<ApiResponse<Void>> handleDataIntegrity(DataIntegrityViolationException ex) {
        log.warn("409 DB constraint violation {}", ex.getMessage());
        return fail(ErrorCode.DB_FK);
    }

    @ExceptionHandler(DuplicateKeyException.class)
    public ResponseEntity<ApiResponse<Void>> handleDuplicateKey(DuplicateKeyException ex) {
        log.warn("409 DB unique violation {}", ex.getMessage());
        return fail(ErrorCode.DB_UNIQUE);
    }

    @ExceptionHandler(CannotAcquireLockException.class)
    public ResponseEntity<ApiResponse<Void>> handleLockTimeout(CannotAcquireLockException ex) {
        log.warn("503 DB lock timeout {}", ex.getMessage());
        return fail(ErrorCode.DB_LOCK_TIMEOUT);
    }

    @ExceptionHandler(DeadlockLoserDataAccessException.class)
    public ResponseEntity<ApiResponse<Void>> handleDeadlock(DeadlockLoserDataAccessException ex) {
        log.warn("503 DB deadlock {}", ex.getMessage());
        return fail(ErrorCode.DB_DEADLOCK);
    }

    @ExceptionHandler(SQLSyntaxErrorException.class)
    public ResponseEntity<ApiResponse<Void>> handleSqlSyntax(SQLSyntaxErrorException ex) {
        log.error("500 DB syntax error {}", ex.getMessage());
        return fail(ErrorCode.DB_SYNTAX);
    }

    @ExceptionHandler(CannotGetJdbcConnectionException.class)
    public ResponseEntity<ApiResponse<Void>> handleDbConnection(CannotGetJdbcConnectionException ex) {
        log.error("503 DB connection error {}", ex.getMessage());
        return fail(ErrorCode.DB_CONNECTION);
    }

    // ===== 연동/네트워크 =====
    @ExceptionHandler(FeignException.class)
    public ResponseEntity<ApiResponse<Void>> handleFeign(FeignException ex) {
        int st = ex.status();
        log.warn("Feign status={}, msg={}", st, ex.getMessage());
        if (st >= 500) return fail(ErrorCode.INTEG_UPSTREAM_5XX);
        if (st >= 400) return fail(ErrorCode.INTEG_UPSTREAM_4XX);
        return fail(ErrorCode.INTEG_NETWORK);
    }

    // ===== 마지막 안전망 =====
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse<Void>> handleEtc(Exception ex) {
        log.error("500 SRV_INTERNAL", ex);
        return fail(ErrorCode.SRV_INTERNAL);
    }

    // ---------- 공통 반환 ----------
    private ResponseEntity<ApiResponse<Void>> fail(ErrorCode ec) {
        ApiResponse<Void> body = ApiResponse.fail(ec); // detail 절대 포함 안 함
        return ResponseEntity.status(ec.getStatus()).body(body);
    }
}
