package kr.kepco.edu.admin.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import kr.kepco.edu.admin.validation.ErrorCode;
import lombok.*;
import org.springframework.http.HttpStatus;

@ToString
@Getter @Builder
@AllArgsConstructor @NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiResponse<T> {
    @Schema(description = "처리 성공 여부", example = "TRUE")
    private boolean success;
    @Schema(description = "HTTP status code", example = "200")
    private int status;
    @Schema(description = "사용자 메시지", example = "성공")
    private String message;
    @Schema(description = "응답 시각 (epoch millis)", example = "1700000000000")
    private long timestamp;
    @Schema(description = "데이터", example = "{'':''}")
    private T data;
    @Schema(description = "에러 코드 (실패 시)", example = "EDU-400-COMMON-MISSING_PARAM")
    private String code;
    @Schema(description = "상세정보", example = "XXX 가 비어있습니다.")
    private String detail;

    // 성공(데이터 포함) - 기본 200
    public static <T> ApiResponse<T> ok(T data) {
        return ok(HttpStatus.OK, data, null);
    }
    // 성공(메시지만) - 기본 200
    public static ApiResponse<Void> okMsg(String message) {
        return ok(HttpStatus.OK, null, message);
    }
    // 성공(상태/데이터/메시지 커스텀)
    public static <T> ApiResponse<T> ok(HttpStatus status, T data, String message) {
        return ApiResponse.<T>builder()
                .success(true)
                .status(status.value())
                .message(message)
                .timestamp(System.currentTimeMillis())
                .data(data)
                .build();
    }
    // --- 실패: 단순 메시지 ---
    public static <T> ApiResponse<T> fail(HttpStatus status, String message) {
        return ApiResponse.<T>builder()
                .success(false)
                .status(status.value())
                .message(message)
                .timestamp(System.currentTimeMillis())
                .build();
    }

    // --- 실패: ErrorCode 기반 (추천) ---
    public static <T> ApiResponse<T> fail(ErrorCode errorCode) {
        return ApiResponse.<T>builder()
                .success(false)
                .status(errorCode.getStatus().value())
                .message(errorCode.getMessage())
                .code(errorCode.getCode())
                .timestamp(System.currentTimeMillis())
                .build();
    }

    // --- 실패: ErrorCode + 상세 정보 ---
    public static <T> ApiResponse<T> fail(ErrorCode errorCode, String detail) {
        return ApiResponse.<T>builder()
                .success(false)
                .status(errorCode.getStatus().value())
                .message(errorCode.getMessage())
                .code(errorCode.getCode())
                .timestamp(System.currentTimeMillis())
                .detail(detail)
                .build();
    }
}
