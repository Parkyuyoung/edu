package kr.kepco.edu.admin.service;

import kr.kepco.edu.admin.dto.MealDTO;
import kr.kepco.edu.admin.mappers.mapperMaria.MealMapper;
import kr.kepco.edu.admin.request.MealReq;
import kr.kepco.edu.admin.response.Page;
import kr.kepco.edu.admin.util.CommonUtil;
import kr.kepco.edu.admin.util.EmpNameUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
public class MealService {

    @Autowired
    MealMapper mealMapper;

    @Autowired
    EmpNameUtil empNameUtil;

    @Autowired
    FileService fileService;

    @Transactional
    public boolean insertMealList(MealReq dto, MultipartFile mFile) {

        int i = mealMapper.insertMealList(dto);

        if(i > 0 && CommonUtil.isValid(dto.getWklyMealplSerno())) {
            if (CommonUtil.isValid(mFile)) {
                fileService.register(
                        mFile,
                        "meal",
                        dto.getWklyMealplSerno(),
                        "M",
                        0,
                        "meal",
                        dto.getFrstRegrEmpno()
                );
            }
        }

        return i > 0;
    }

    public int selectMealListCnt(MealReq req) { return mealMapper.selectMealListCnt(req); }

    public List<MealDTO> selectMealList(MealReq req, Page<MealDTO> page) {

        List<MealDTO> mealDTOS = mealMapper.selectMealList(req, page);

        if(!CommonUtil.isValid(mealDTOS)){
            return mealDTOS;
        }

        empNameUtil.enrichName(
                mealDTOS,
                MealDTO::getFrstRegrEmpno,
                MealDTO::setFrstRegrEmpnm,
                "홍길동"
        );
        return mealDTOS;
    }

    public MealDTO selectMealDetail(MealReq req) {
        MealDTO mealDTO = mealMapper.selectMealDetail(req);

        if(!CommonUtil.isValid(mealDTO)){
            return mealDTO;
        }

        empNameUtil.enrichNameOne(
                mealDTO,
                MealDTO::getFrstRegrEmpno,
                MealDTO::setFrstRegrEmpnm
        );

        System.out.println("empNameUtil >>> " + mealDTO.toString());

        return mealDTO;
    }

    @Transactional
    public boolean deleteMeal(MealReq req) {
        if (mealMapper.deleteMeal(req) > 0) {
            try {
                fileService.deleteSearch(req.getWklyMealplSerno(), req.getLstChgrEmpno(), "M", "meal",true);
            } catch (IllegalArgumentException i) {
                System.out.println("파일삭제실패");
            }
            return true;
        }
        return false;
    }

    @Transactional
    public boolean updateMealList(MealReq req, MultipartFile mFile) {
        int i = mealMapper.updateMeal(req);

        if (i > 0) {
            if (CommonUtil.isValid(mFile)) {
                fileService.deleteSearch(req.getWklyMealplSerno(),req.getLstChgrEmpno(), "M","meal",true);
                fileService.register(
                        mFile,
                        "meal",
                        req.getWklyMealplSerno(),
                        "M",
                        0,
                        "meal",
                        req.getLstChgrEmpno()
                );
            }
        }
        return i > 0;
    }

    public int existsYearWeek(MealReq req){
        return mealMapper.existsYearWeek(req);
    }
}
