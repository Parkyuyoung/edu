package kr.kepco.edu.admin.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.media.*;
import io.swagger.v3.oas.models.responses.ApiResponse;
import io.swagger.v3.oas.models.responses.ApiResponses;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.servers.Server;
import org.springdoc.core.GroupedOpenApi;
import org.springdoc.core.customizers.OpenApiCustomiser;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI kepcoEduOpenAPI() {
        // 에러 응답 Envelope 스키마 (data는 null 허용)
        Schema<?> errorEnvelope = new ObjectSchema()
                .addProperties("success", new BooleanSchema()._default(false).example(false))
                .addProperties("status",  new IntegerSchema().example(400))
                .addProperties("message", new StringSchema().example("요청 데이터가 유효하지 않습니다."))
                .addProperties("timestamp", new NumberSchema().format("int64").example(1700000000000L))
                .addProperties("data", new ObjectSchema().nullable(true).example(null));

        Components components = new Components()
                .addSchemas("ErrorEnvelope", errorEnvelope)
                .addResponses("CommonBadRequest", new ApiResponse()
                        .description("잘못된 요청")
                        .content(json(errorEnvelope, ex(false, 400, "요청 데이터가 유효하지 않습니다.", 1700000000000L, null))))
                .addResponses("CommonUnauthorized", new ApiResponse()
                        .description("인증 실패/토큰 없음")
                        .content(json(errorEnvelope, ex(false, 401, "인증 토큰이 누락되었거나 유효하지 않습니다.", 1700000000000L, null))))
                .addResponses("CommonForbidden", new ApiResponse()
                        .description("권한 없음")
                        .content(json(errorEnvelope, ex(false, 403, "접근 권한이 없습니다.", 1700000000000L, null))))
                .addResponses("CommonNotFound", new ApiResponse()
                        .description("리소스 없음")
                        .content(json(errorEnvelope, ex(false, 404, "요청하신 리소스를 찾을 수 없습니다.", 1700000000000L, null))))
                .addResponses("CommonMethodNotAllowed", new ApiResponse()
                        .description("허용되지 않은 메서드")
                        .content(json(errorEnvelope, ex(false, 405, "허용되지 않은 요청 방식입니다.", 1700000000000L, null))))
                .addResponses("CommonServerError", new ApiResponse()
                        .description("서버 오류")
                        .content(json(errorEnvelope, ex(false, 500, "시스템 오류가 발생했습니다. 관리자에게 문의하세요.", 1700000000000L, null))));

        return new OpenAPI()
                .info(new Info()
                        .title("모바일 교육행정 API")
                        .description("KEPCO 교육행정 MSA 서비스 OpenAPI 문서")
                        .version("v1.0")
                        .license(new License().name("Kepco Internal Use Only")))
                .components(
                        components.addSecuritySchemes("BearerAuth",
                                new SecurityScheme().type(SecurityScheme.Type.HTTP).scheme("bearer").bearerFormat("JWT")))
                .addSecurityItem(new SecurityRequirement().addList("BearerAuth"))
                .servers(List.of(new Server().url("/").description("로컬 개발")));
    }

    // 전역 공통 응답 주입
    @Bean
    public OpenApiCustomiser globalResponsesCustomiser() {
        return openApi -> {
            if (openApi.getPaths() == null) return;
            openApi.getPaths().values().forEach(path ->
                    path.readOperations().forEach(op -> {
                        ApiResponses rs = op.getResponses();
                        addIfAbsent(rs, "400", "CommonBadRequest");
                        addIfAbsent(rs, "401", "CommonUnauthorized");
                        addIfAbsent(rs, "403", "CommonForbidden");
                        addIfAbsent(rs, "404", "CommonNotFound");
                        addIfAbsent(rs, "405", "CommonMethodNotAllowed");
                        addIfAbsent(rs, "500", "CommonServerError");
                    })
            );
        };
    }

    // 모든 경로에 위 커스터마이저 적용
    @Bean
    public GroupedOpenApi allApis(OpenApiCustomiser globalResponsesCustomiser) {
        return GroupedOpenApi.builder()
                .group("all")
                .pathsToMatch("/**")
                .addOpenApiCustomiser(globalResponsesCustomiser)
                .build();
    }

    // --- helpers ---
    private static Content json(Schema<?> schema, Object example) {
        return new Content().addMediaType("application/json",
                new MediaType().schema(schema).example(example));
    }

    // ✅ Map.of 대신 null 허용되는 LinkedHashMap 사용
    private static Map<String, Object> ex(boolean success, int status, String message, long ts, Object data) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("success", success);
        m.put("status", status);
        m.put("message", message);
        m.put("timestamp", ts);
        m.put("data", data);   // null 가능
        return m;
    }

    private static void addIfAbsent(ApiResponses rs, String code, String refName) {
        if (rs.get(code) == null) {
            rs.addApiResponse(code, new ApiResponse().$ref("#/components/responses/" + refName));
        }
    }
}
