package kr.kepco.edu.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(name = "MenuFilterDTO", description = "메뉴 필터 DTO")
public class MenuFilterDTO {
    @Schema(description = "상위메뉴ID", example = "ADMIN")
    private String parentMenuId;
    @Schema(description = "상위메뉴명", example = "관리자")
    private String parentMenuNm;
    @Schema(description = "메뉴ID", example = "ADMIN_100")
    private String menuId;
    @Schema(description = "메뉴명", example = "임시사원증 관리")
    private String menuNm;
}
