package kr.kepco.edu.admin.mappers.mapperMaria;

import kr.kepco.edu.admin.dto.AccessLogDTO;
import kr.kepco.edu.admin.dto.SelectOptionDTO;
import kr.kepco.edu.admin.request.AccessLogReq;
import kr.kepco.edu.admin.response.Page;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface AccessLogMapper {
    int selectAccessLogListCnt(@Param("param") AccessLogReq accessLogReq);
    List<AccessLogDTO> selectAccessLogList(@Param("param") AccessLogReq accessLogReq, @Param("page") Page<AccessLogDTO> page);

    List<SelectOptionDTO> selectMenuList();

    void accessLog(String mngrId , String menuId);

    List<Map<String, Object>> selectAccessLogStatByMenus(Map<String, Object> param);
}
