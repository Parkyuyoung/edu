package kr.kepco.edu.admin.mappers.mapperMaria;

import kr.kepco.edu.admin.dto.GuideDTO;
import kr.kepco.edu.admin.request.GuideReq;
import kr.kepco.edu.admin.response.Page;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface GuideMapper {
    List<GuideDTO> selectGuideList(@Param("page") Page<GuideDTO> page, @Param("params") GuideReq req);
    int selectGuideListCount(@Param("params") GuideReq req);
    int insertGuideMaster(GuideReq dto);
    int insertGuideDetail(GuideReq dto);
    int updateGuideList(GuideReq dto);
    int updateGuideDetail(GuideReq dto);
    int deleteGuideList(GuideReq dto);
    int deleteGuideDetail(GuideReq dto);
    int updateGuideListPstnYn(GuideReq dto);
    int updateGuideDetailPstnYn(GuideReq dto);

    List<GuideDTO> selectMGuideList(GuideReq req);
    GuideDTO selectGuideDetail(GuideReq req);
    List<GuideDTO> selectGuideMasterList(GuideReq req);
    int selectGuideMasterPstnCnt(GuideReq dto);
    int updateGuideMasterSortOrder(GuideReq dto);
    int updateGuideMasterOrderSetting(GuideReq dto);
}
