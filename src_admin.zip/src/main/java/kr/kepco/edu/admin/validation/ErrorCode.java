package kr.kepco.edu.admin.validation;

import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public enum ErrorCode {

    // ==== 입력·유효성 ====
    REQ_MISSING_PARAM(HttpStatus.BAD_REQUEST, "EDU-400-REQ-MISSING_PARAM", "필수 파라미터가 누락되었습니다."),
    REQ_MISSING_BODY(HttpStatus.BAD_REQUEST, "EDU-400-REQ-MISSING_BODY", "요청 본문이 필요합니다."),
    REQ_MALFORMED_JSON(HttpStatus.BAD_REQUEST, "EDU-400-REQ-MALFORMED_JSON", "요청 본문 형식이 올바르지 않습니다."),
    REQ_UNKNOWN_FIELD(HttpStatus.BAD_REQUEST, "EDU-400-REQ-UNKNOWN_FIELD", "지원하지 않는 필드가 포함되었습니다."),
    REQ_TYPE_MISMATCH(HttpStatus.BAD_REQUEST, "EDU-400-REQ-TYPE_MISMATCH", "요청 파라미터 타입이 올바르지 않습니다."),
    REQ_MISSING_HEADER(HttpStatus.BAD_REQUEST, "EDU-400-REQ-MISSING_HEADER", "필수 요청 헤더가 누락되었습니다."),
    REQ_INVALID_HEADER(HttpStatus.BAD_REQUEST, "EDU-400-REQ-INVALID_HEADER", "요청 헤더 값이 올바르지 않습니다."),
    REQ_PAGE_PARAM(HttpStatus.BAD_REQUEST, "EDU-400-REQ-PAGE_PARAM", "페이지/사이즈 값이 올바르지 않습니다."),
    REQ_SORT_FIELD(HttpStatus.BAD_REQUEST, "EDU-400-REQ-SORT_FIELD", "정렬 필드가 올바르지 않습니다."),
    REQ_FILTER_FIELD(HttpStatus.BAD_REQUEST, "EDU-400-REQ-FILTER_FIELD", "필터 필드가 올바르지 않습니다."),
    REQ_STATE_CONFLICT(HttpStatus.BAD_REQUEST, "EDU-400-REQ-STATE-CONFLICT", "이미 진행중인 단계입니다. 신규로 등록해 주세요."),
    VAL_INVALID(HttpStatus.UNPROCESSABLE_ENTITY, "EDU-422-VAL-INVALID", "입력값이 올바르지 않습니다."),
    VAL_OUT_OF_RANGE(HttpStatus.UNPROCESSABLE_ENTITY, "EDU-422-VAL-OUT_OF_RANGE", "입력값이 허용 범위를 벗어났습니다."),
    VAL_PATTERN(HttpStatus.UNPROCESSABLE_ENTITY, "EDU-422-VAL-PATTERN", "입력값 형식이 올바르지 않습니다."),
    VAL_ENUM(HttpStatus.UNPROCESSABLE_ENTITY, "EDU-422-VAL-ENUM", "허용되지 않는 값입니다."),
    VAL_DEPENDENCY(HttpStatus.UNPROCESSABLE_ENTITY, "EDU-422-VAL-DEPENDENCY", "파라미터 종속 조건을 만족하지 않습니다."),
    VAL_LIST_EMPTY(HttpStatus.UNPROCESSABLE_ENTITY, "EDU-422-VAL-LIST_EMPTY", "리스트가 비어 있습니다."),
    VAL_VALUE_EMPTY(HttpStatus.UNPROCESSABLE_ENTITY, "EDU-422-VAL-VALUE_EMPTY", "조회할 내용이 없습니다."),
    VAL_LIST_TOO_LARGE(HttpStatus.UNPROCESSABLE_ENTITY, "EDU-422-VAL-LIST_TOO_LARGE", "리스트 크기가 허용 한도를 초과했습니다."),
    VAL_DATETIME(HttpStatus.UNPROCESSABLE_ENTITY, "EDU-422-VAL-DATETIME", "날짜/시간 형식이 올바르지 않습니다."),
    REQ_METHOD(HttpStatus.METHOD_NOT_ALLOWED, "EDU-405-REQ-METHOD", "지원하지 않는 HTTP 메서드입니다."),
    REQ_MEDIA_TYPE(HttpStatus.UNSUPPORTED_MEDIA_TYPE, "EDU-415-REQ-MEDIA_TYPE", "지원하지 않는 콘텐츠 타입입니다."),
    REQ_NOT_ACCEPTABLE(HttpStatus.NOT_ACCEPTABLE, "EDU-406-REQ-NOT_ACCEPTABLE", "요청한 응답 타입을 제공할 수 없습니다."),
    REQ_PAYLOAD_TOO_LARGE(HttpStatus.PAYLOAD_TOO_LARGE, "EDU-413-REQ-PAYLOAD_TOO_LARGE", "요청 본문이 허용 용량을 초과했습니다."),

    // ==== 인증/인가 ====
    AUTH_UNAUTHORIZED(HttpStatus.UNAUTHORIZED, "EDU-401-AUTH-UNAUTHORIZED", "인증이 필요합니다."),
    AUTH_TOKEN_MISSING(HttpStatus.UNAUTHORIZED, "EDU-401-AUTH-TOKEN_MISSING", "인증 토큰이 누락되었습니다."),
    AUTH_TOKEN_INVALID(HttpStatus.UNAUTHORIZED, "EDU-401-AUTH-TOKEN_INVALID", "인증 토큰이 올바르지 않습니다."),
    AUTH_TOKEN_EXPIRED(HttpStatus.UNAUTHORIZED, "EDU-401-AUTH-TOKEN_EXPIRED", "인증 토큰이 만료되었습니다."),
    AUTH_TOKEN_MALFORMED(HttpStatus.UNAUTHORIZED, "EDU-401-AUTH-TOKEN_MALFORMED", "인증 토큰 형식이 올바르지 않습니다."),
    AUTH_TOKEN_SIGNATURE(HttpStatus.UNAUTHORIZED, "EDU-401-AUTH-TOKEN_SIGNATURE", "인증 토큰 서명이 유효하지 않습니다."),
    AUTH_TOKEN_NOT_BEFORE(HttpStatus.UNAUTHORIZED, "EDU-401-AUTH-TOKEN_NOT_BEFORE", "인증 토큰이 아직 유효하지 않습니다."),
    AUTH_FORBIDDEN(HttpStatus.FORBIDDEN, "EDU-403-AUTH-FORBIDDEN", "접근 권한이 없습니다."),
    AUTH_INSUFFICIENT_SCOPE(HttpStatus.FORBIDDEN, "EDU-403-AUTH-INSUFFICIENT_SCOPE", "필요한 권한 범위를 만족하지 않습니다."),
    AUTH_ACCOUNT_LOCKED(HttpStatus.FORBIDDEN, "EDU-403-AUTH-ACCOUNT_LOCKED", "계정이 잠겨 있거나 비활성화되었습니다."),
    AUTH_CSRF(HttpStatus.FORBIDDEN, "EDU-403-AUTH-CSRF", "CSRF 검증에 실패했습니다."),

    // ==== 리소스/상태 ====
    RES_NOT_FOUND(HttpStatus.NOT_FOUND, "EDU-404-RES-NOT_FOUND", "요청한 API 주소를 찾을 수 없습니다."),
    RES_DUPLICATED(HttpStatus.CONFLICT, "EDU-409-RES-DUPLICATED", "중복된 데이터가 존재합니다."),
    RES_STATE_CONFLICT(HttpStatus.CONFLICT, "EDU-409-RES-STATE_CONFLICT", "리소스 상태가 올바르지 않습니다."),
    RES_OPTIMISTIC_LOCK(HttpStatus.CONFLICT, "EDU-409-RES-OPTIMISTIC_LOCK", "리소스가 동시에 수정되었습니다."),
    RES_PRECONDITION(HttpStatus.PRECONDITION_FAILED, "EDU-412-RES-PRECONDITION", "선행조건 검증에 실패했습니다."),
    RES_PRECONDITION_REQUIRED(HttpStatus.PRECONDITION_REQUIRED, "EDU-428-RES-PRECONDITION_REQUIRED", "선행조건 헤더가 필요합니다."),

    // ==== 파일 ====
    FILE_MISSING(HttpStatus.BAD_REQUEST, "EDU-400-FILE-MISSING", "업로드 파일이 누락되었습니다."),
    FILE_EMPTY(HttpStatus.BAD_REQUEST, "EDU-400-FILE-EMPTY", "업로드 파일이 비어 있습니다."),
    FILE_TOO_LARGE(HttpStatus.PAYLOAD_TOO_LARGE, "EDU-413-FILE-TOO_LARGE", "파일 크기가 허용 한도를 초과했습니다."),
    FILE_TOO_MANY(HttpStatus.PAYLOAD_TOO_LARGE, "EDU-413-FILE-TOO_MANY", "업로드 파일 개수가 허용 한도를 초과했습니다."),
    FILE_UNSUPPORTED_TYPE(HttpStatus.UNSUPPORTED_MEDIA_TYPE, "EDU-415-FILE-UNSUPPORTED_TYPE", "지원하지 않는 파일 형식입니다."),
    FILE_CORRUPTED(HttpStatus.UNPROCESSABLE_ENTITY, "EDU-422-FILE-CORRUPTED", "파일이 손상되었습니다."),
    FILE_SECURITY_REJECTED(HttpStatus.UNPROCESSABLE_ENTITY, "EDU-422-FILE-SECURITY_REJECTED", "파일이 보안 검사를 통과하지 못했습니다."),

    // ==== 정책/트래픽 ====
    POL_RATE_LIMIT(HttpStatus.TOO_MANY_REQUESTS, "EDU-429-POL-RATE_LIMIT", "요청이 너무 많습니다."),
    POL_IDEMPOTENCY_REQUIRED(HttpStatus.PRECONDITION_REQUIRED, "EDU-428-POL-IDEMPOTENCY_REQUIRED", "Idempotency-Key가 필요합니다."),
    POL_IDEMPOTENCY_CONFLICT(HttpStatus.CONFLICT, "EDU-409-POL-IDEMPOTENCY_CONFLICT", "중복된 Idempotency-Key 요청입니다."),
    POL_CORS(HttpStatus.FORBIDDEN, "EDU-403-POL-CORS", "CORS 정책에 의해 차단되었습니다."),
    POL_SECURITY(HttpStatus.FORBIDDEN, "EDU-403-POL-SECURITY", "보안 정책 위반으로 요청이 거부되었습니다."),

    // ==== 연동/네트워크 ====
    INTEG_TIMEOUT(HttpStatus.GATEWAY_TIMEOUT, "EDU-504-INTEG-TIMEOUT", "연계 서비스 응답이 지연되었습니다."),
    INTEG_UPSTREAM_4XX(HttpStatus.BAD_GATEWAY, "EDU-502-INTEG-UPSTREAM_4XX", "연계 서비스 요청이 올바르지 않습니다."),
    INTEG_UPSTREAM_5XX(HttpStatus.BAD_GATEWAY, "EDU-502-INTEG-UPSTREAM_5XX", "연계 서비스에서 오류가 발생했습니다."),
    INTEG_NETWORK(HttpStatus.BAD_GATEWAY, "EDU-502-INTEG-NETWORK", "외부 서비스 연결에 실패했습니다."),
    INTEG_FALLBACK(HttpStatus.SERVICE_UNAVAILABLE, "EDU-503-INTEG-FALLBACK", "연계 대체 처리로 응답했습니다."),

    // ==== 데이터베이스 ====
    DB_UNIQUE(HttpStatus.CONFLICT, "EDU-409-DB-UNIQUE", "중복 키로 인해 저장할 수 없습니다."),
    DB_FK(HttpStatus.UNPROCESSABLE_ENTITY, "EDU-422-DB-FK", "참조 무결성 제약을 위반했습니다."),
    DB_DEADLOCK(HttpStatus.SERVICE_UNAVAILABLE, "EDU-503-DB-DEADLOCK", "데드락이 발생했습니다."),
    DB_LOCK_TIMEOUT(HttpStatus.SERVICE_UNAVAILABLE, "EDU-503-DB-LOCK_TIMEOUT", "락 대기 시간이 초과되었습니다."),
    DB_SYNTAX(HttpStatus.INTERNAL_SERVER_ERROR, "EDU-500-DB-SYNTAX", "데이터베이스 쿼리 문법 오류입니다."),
    DB_CONNECTION(HttpStatus.SERVICE_UNAVAILABLE, "EDU-503-DB-CONNECTION", "데이터베이스 연결에 실패했습니다."),

    // ==== 서버/게이트웨이 ====
    SRV_INTERNAL(HttpStatus.INTERNAL_SERVER_ERROR, "EDU-500-SRV-INTERNAL", "서버 내부 오류가 발생했습니다.\n 관리자에게 문의해주세요."),
    SRV_UNAVAILABLE(HttpStatus.SERVICE_UNAVAILABLE, "EDU-503-SRV-UNAVAILABLE", "서비스를 일시적으로 사용할 수 없습니다."),
    SRV_CONFIG(HttpStatus.INTERNAL_SERVER_ERROR, "EDU-500-SRV-CONFIG", "서버 설정이 올바르지 않습니다."),
    GW_BAD_GATEWAY(HttpStatus.BAD_GATEWAY, "EDU-502-GW-BAD_GATEWAY", "게이트웨이에서 잘못된 응답을 수신했습니다."),
    GW_TIMEOUT(HttpStatus.GATEWAY_TIMEOUT, "EDU-504-GW-TIMEOUT", "게이트웨이 응답 대기 시간이 초과되었습니다."),

    // === 저장 오류 ===
    INSERT_INTERNAL(HttpStatus.INTERNAL_SERVER_ERROR, "EDU-500-INSERT_INTERNAL", "등록에 실패하였습니다.\n관리자에게 문의해주세요."),
    UPDATE_INTERNAL(HttpStatus.INTERNAL_SERVER_ERROR, "EDU-500-UPDATE_INTERNAL", "수정에 실패하였습니다.\n관리자에게 문의해주세요."),
    DELETE_INTERNAL(HttpStatus.INTERNAL_SERVER_ERROR, "EDU-500-DELETE_INTERNAL", "삭제에 실패하였습니다.\n관리자에게 문의해주세요."),

    // === 파일 오류 ===
    FILE_PATH_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "EDU-500-FILE_PATH_ERROR", "파일 저장 경로가 올바르지 않습니다.\n관리자에게 문의해주세요."),
    FILE_UPLOAD_FAIL(HttpStatus.INTERNAL_SERVER_ERROR, "EDU-500-FILE_UPLOAD_FAIL", "파일 업로드에 실패하였습니다.\n관리자에게 문의해주세요.");



    private final HttpStatus status;
    private final String code;
    private final String message;

    ErrorCode(HttpStatus status, String code, String message) {
        this.status = status;
        this.code = code;
        this.message = message;
    }
}
