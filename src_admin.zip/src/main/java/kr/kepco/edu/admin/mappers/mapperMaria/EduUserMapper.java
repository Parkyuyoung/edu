package kr.kepco.edu.admin.mappers.mapperMaria;

import kr.kepco.edu.admin.dto.EduUserDTO;
import kr.kepco.edu.admin.request.AuthLogReq;
import kr.kepco.edu.admin.request.EduUserReq;
import kr.kepco.edu.admin.response.Page;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface EduUserMapper {
    int selectEduUserListCnt(@Param("param") EduUserReq eduUserReq);

    List<EduUserDTO> selectEduUserList(@Param("param") EduUserReq eduUserReq, @Param("page") Page<EduUserDTO> page);

    int insertEduUser(EduUserReq eduUserReq);

    int updateEduUser(EduUserReq eduUserReq);

    int deleteEduUser(EduUserReq eduUserReq);

    int selectEduUserDupCnt(@Param("param") EduUserReq eduUserReq);

    int insertAuthLog(AuthLogReq authLogReq);

    int selectEduAuthExists(@Param("edamsAuthCd") String edamsAuthCd);

    int selectAdminExists(@Param("userId") String userId);


}
