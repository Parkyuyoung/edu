package kr.kepco.edu.admin.controller;

import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import kr.kepco.edu.admin.validation.ErrorCode;
import kr.kepco.edu.admin.validation.RequestGroup;
import kr.kepco.edu.admin.dto.NoticeDTO;
import kr.kepco.edu.admin.request.LoginRequest;
import kr.kepco.edu.admin.request.NoticeReq;
import kr.kepco.edu.admin.response.ApiResponse;
import kr.kepco.edu.admin.response.Page;
import kr.kepco.edu.admin.service.CustomUserDetails;
import kr.kepco.edu.admin.service.JojicService;
import kr.kepco.edu.admin.service.NoticeService;
import kr.kepco.edu.admin.util.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Tag(name = "02.공지사항", description = "공지사항 API 설명")
@RestController
@RequestMapping("${base.url}/notice")
public class NoticeController {

    @Autowired
    NoticeService noticeService;

    @Autowired
    JojicService jojicService;

    @Operation(
            summary = "공지사항 목록",
            description = "공지사항 목록 조회",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = NoticeReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "전체 검색",
                                            value = "{ \"currentPage\": \"1\" , \"pageSize\": \"10\" }"
                                    ),
                                    @ExampleObject(
                                            name = "제목 검색",
                                            value = "{ \"searchType\": \"ntiMttrTitlNm\" ,\"searchValue\": \"테스트\" , \"currentPage\": \"1\" , \"pageSize\": \"10\" }"
                                    ),
                                    @ExampleObject(
                                            name = "이름 검색 - 나중에 추가",
                                            value = "{ \"searchType\": \"frstRegrEmpnm\" , \"searchValue\": \"정인택\" ,  \"currentPage\": \"1\" , \"pageSize\": \"10\" }"
                                    )
                            }
                    )
            )
    )
    @PostMapping(value = "/getNoticeList" , consumes = "application/json", produces = "application/json")
    public ApiResponse<Page<NoticeDTO>> getNoticeList(@AuthenticationPrincipal CustomUserDetails user, @RequestBody @JsonView(RequestGroup.Search.class) NoticeReq req) {

        if (CommonUtil.isValid(req.getSearchType()) && req.getSearchType().equals("frstRegrEmpnm")){
            List<String> empNoList = jojicService.getSeachEmpList(req.getSearchValue());
            if(!CommonUtil.isValid(empNoList)) return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
            req.setSearchEmpNo(empNoList);
        }

        Page<NoticeDTO> page = new Page<>(req.getCurrentPage(),req.getPageSize(), noticeService.selectNoticeListCnt(req));
        page.setContent(noticeService.selectNoticeList(req,page));

        if (CommonUtil.isValid(page.getContent())) {
            return ApiResponse.ok(HttpStatus.OK, page, "OK");
        } else {
            return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }
    }

    @Operation(
            summary = "공지사항 상세",
            description = "공지사항 상세 조회",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = LoginRequest.class),
                            examples = {
                                    @ExampleObject(
                                            name = "상세 조회",
                                            value = "{ \"ntiMttrSerno\": \"1\" }"
                                    ),
                            }
                    )
            )
    )
    @PostMapping(value = "/getNoticeDetail" , consumes = "application/json", produces = "application/json")
    public ApiResponse<NoticeDTO> getNoticeDetail(@AuthenticationPrincipal CustomUserDetails user, @RequestBody @JsonView(RequestGroup.Detail.class) NoticeReq req) {

        if(!CommonUtil.isValid(req.getNtiMttrSerno())) {
            return ApiResponse.fail(ErrorCode.REQ_MISSING_PARAM);
        }
        NoticeDTO noticeDTO = noticeService.selectNoticeDetail(req);

        if(CommonUtil.isValid(noticeDTO)) {
            return ApiResponse.ok(HttpStatus.OK, noticeDTO, "OK");
        } else {
            return ApiResponse.fail(ErrorCode.VAL_VALUE_EMPTY);
        }
    }

    @Operation(
            summary = "공지사항 등록",
            description = "공지사항 등록",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = NoticeReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "공지사항 등록",
                                            value = "{ \"ntiMttrTitlNm\": \"공지사항 등록 테스트\"" +
                                                    ", \"ntiMttrCtt\": \"공지사항 내용 테스트\"" +
                                                    ", \"upndFixYn\": \"N\"" +
                                                    ", \"upndFixSeqno\": \"null\" }"
                                    ),
                            }
                    )
            )
    )
    @PostMapping(value = "/insNotice" , consumes = "application/json", produces = "application/json")
    public ApiResponse<String> insertNoticeList(@AuthenticationPrincipal CustomUserDetails user, @RequestBody NoticeReq req) {
        /** 유효성 검증 - String인 경우 null이나 빈 값, 특수문자 변환 */
        if (!CommonUtil.sanitizeDto(req, "noticeTtlNm", "noticeCtt")) {
            return ApiResponse.fail(ErrorCode.VAL_INVALID);
        }
        /** 등록자 사번 추가 */
        req.setFrstRegrEmpno(user.getUsername());
        req.setLstChgrEmpno(user.getUsername());

        if(noticeService.insert(req)) {
            return ApiResponse.ok(HttpStatus.OK, "정상적으로 등록되었습니다." , "OK");
        } else {
            return ApiResponse.fail(ErrorCode.INSERT_INTERNAL);
        }
    }

    @PostMapping(value = "/getNoticePinnedCnt")
    public ApiResponse<Integer> getNoticePinnedCnt(@AuthenticationPrincipal CustomUserDetails user) {
        return ApiResponse.ok(HttpStatus.OK, noticeService.getNoticePinnedCnt() , "정상적으로 등록되었습니다.");
    }

    @Operation(
            summary = "공지사항 수정",
            description = "공지사항 수정",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = NoticeReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "공지사항 수정",
                                            value = "{ \"ntiMttrSerno\": \"1\"" +
                                                    ", \"ntiMttrTitlNm\": \"제목 수정했어요\"" +
                                                    ", \"ntiMttrCtt\": \"내용도 수정했어요\"" +
                                                    ", \"upndFixYn\": \"Y\"" +
                                                    ", \"upndFixSeqno\": \"null\" }"
                                    ),
                            }
                    )
            )
    )
    @PostMapping(value = "/modify" , consumes = "application/json", produces = "application/json")
    public ApiResponse<String> updateNoticeList(@AuthenticationPrincipal CustomUserDetails user, @RequestBody NoticeReq req) {

        /** 기준값 없으면 return */
        if(!CommonUtil.isValid(req.getNtiMttrSerno())) {
            return ApiResponse.fail(ErrorCode.REQ_MISSING_PARAM);
        }

        /** 유효성 검증 - String인 경우 null이나 빈 값, 특수문자 변환 */
        if (!CommonUtil.sanitizeDto(req,  "noticeCtt")) {
            return ApiResponse.fail(ErrorCode.VAL_INVALID);
        }

        /** 최종 수정자 정보 추가 */
        req.setLstChgrEmpno(user.getUsername());

        if (noticeService.update(req)) {
            return ApiResponse.ok(HttpStatus.OK, "정상적으로 수정되었습니다.", "OK");
        } else {
            return ApiResponse.fail(ErrorCode.INSERT_INTERNAL);
        }
    }

    @Operation(
            summary = "공지사항 삭제",
            description = "공지사항 삭제",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = LoginRequest.class),
                            examples = {
                                    @ExampleObject(
                                            name = "삭제",
                                            value = "{ \"noticeSerno\": \"1\" }"
                                    ),
                            }
                    )
            )
    )
    @PostMapping(value = "/delNotice" , consumes = "application/json", produces = "application/json")
    public ApiResponse<String> deleteNotice(@AuthenticationPrincipal CustomUserDetails user, @RequestBody @JsonView(RequestGroup.Detail.class) NoticeReq req) {

        if(!CommonUtil.isValid(req.getNtiMttrSerno())) {
            return ApiResponse.fail(ErrorCode.REQ_MISSING_PARAM);
        }

        req.setLstChgrEmpno(user.getUsername());

        if (noticeService.delete(req)) {
            return ApiResponse.ok(HttpStatus.OK, "정상적으로 삭제되었습니다.", "OK");
        } else  {
            return ApiResponse.fail(ErrorCode.INSERT_INTERNAL);
        }
    }
}
