package kr.kepco.edu.admin.util;

import kr.kepco.edu.admin.dto.EmpInfoDTO;
import kr.kepco.edu.admin.mappers.mapperOracle.JojicMapper;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * ✅ 공통 유틸: 사번(empNo)을 기반으로 이름(name)을 매핑하는 유틸 클래스
 * ------------------------------------------------------------
 * - 리스트나 단일 객체 모두 처리 가능
 * - Oracle IN 1000 제한 대응 (내부에서 자동 분할)
 * - 사번 중복 시 최초값 유지
 * - null/공백 자동제거 및 trim 처리
 * - N+1 방지: 한 번에 벌크 조회 후 매핑
 * - 체이닝 세터(@Accessors(chain=true)) 대응: setter는 람다로 넘기기
 */
@Component
public class EmpNameUtil {

    private final JojicMapper jojicMapper;

    public EmpNameUtil(JojicMapper jojicMapper) {
        this.jojicMapper = jojicMapper;
    }

    // ─────────────────────────────────────────────
    // 🔸 1. 사번 리스트 → 이름 맵 조회
    // ─────────────────────────────────────────────
    /**
     * ✅ 예시:
     * <pre>
     * Set&lt;String&gt; empNos = Set.of("E1001", "E1002");
     * Map&lt;String, String&gt; nameMap = empNameUtil.getNameMapByEmpNos(empNos);
     * // 결과: {E1001=홍길동, E1002=김철수}
     * </pre>
     */
    public Map<String, String> getNameMapByEmpNos(Collection<String> empNos) {
        if (empNos == null || empNos.isEmpty()) return Collections.emptyMap();

        Set<String> cleaned = empNos.stream()
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toCollection(LinkedHashSet::new));
        if (cleaned.isEmpty()) return Collections.emptyMap();

        final int CHUNK = 900;
        List<String> list = new ArrayList<>(cleaned);
        Map<String, String> result = new LinkedHashMap<>();

        for (int i = 0; i < list.size(); i += CHUNK) {
            int end = Math.min(i + CHUNK, list.size());
            Set<String> slice = new LinkedHashSet<>(list.subList(i, end));

            List<EmpInfoDTO> rows = jojicMapper.selectSeachEmpNmList(slice);
            if (rows == null) continue;

            for (EmpInfoDTO row : rows) {
                if (row == null) continue;
                String no = safeTrim(row.getEmpNo());
                String nm = safeTrim(row.getName());
                if (no != null && nm != null && !no.isEmpty() && !nm.isEmpty()) {
                    result.putIfAbsent(no, nm);
                }
            }
        }
        return result;
    }

    // ─────────────────────────────────────────────
    // 🔸 2. 리스트(단일 사번 필드) → 이름 매핑
    // ─────────────────────────────────────────────
    /**
     * ✅ 예시:
     * <pre>
     * empNameUtil.enrichName(
     *     bannerList,
     *     BannerDTO::getFrstRegrEmpno,                // getter
     *     (BannerDTO b, String nm) -> b.setFrstRegrEmpnm(nm), // setter
     *     "(이름없음)"                                 // 기본값
     * );
     * </pre>
     */
    public <T> void enrichName(
            Collection<T> items,
            Function<? super T, ? extends String> empNoGetter,
            BiConsumer<? super T, ? super String> nameSetter,
            String defaultName
    ) {
        if (items == null || items.isEmpty()) return;

        Set<String> empNos = items.stream()
                .map(empNoGetter)
                .map(this::safeTrim)
                .filter(s -> s != null && !s.isEmpty())
                .collect(Collectors.toCollection(LinkedHashSet::new));

        if (empNos.isEmpty()) return;

        Map<String, String> nameMap = getNameMapByEmpNos(empNos);

        System.out.println("test");

        items.forEach(it -> {
            String no = safeTrim(empNoGetter.apply(it));
            if (no != null && !no.isEmpty()) {
                nameSetter.accept(it, nameMap.getOrDefault(no, defaultName));
            }
        });
    }

    /**
     * ✅ 예시 (defaultName 생략 버전)
     * <pre>
     * empNameUtil.enrichName(
     *     bannerList,
     *     BannerDTO::getFrstRegrEmpno,
     *     (BannerDTO b, String nm) -> b.setFrstRegrEmpnm(nm)
     * );
     * </pre>
     */
    public <T> void enrichName(
            Collection<T> items,
            Function<? super T, ? extends String> empNoGetter,
            BiConsumer<? super T, ? super String> nameSetter
    ) {
        enrichName(items, empNoGetter, nameSetter, "(이름없음)");
    }

    public <T> void enrichNameOne(
            T item,
            Function<? super T, ? extends String> empNoGetter,
            BiConsumer<? super T, ? super String> nameSetter
    ) {
        enrichName(Collections.singletonList(item), empNoGetter, nameSetter, "(이름없음)");
    }

    // ─────────────────────────────────────────────
    // 🔸 3. 리스트(다중 사번 필드: 등록자/수정자 등)
    // ─────────────────────────────────────────────
    /**
     * ✅ 예시:
     * <pre>
     * empNameUtil.enrichNames(
     *     bannerList,
     *     List.of(BannerDTO::getFrstRegrEmpno, BannerDTO::getLastModiEmpno),
     *     List.of(
     *         (BannerDTO b, String nm) -> b.setFrstRegrEmpnm(nm),
     *         (BannerDTO b, String nm) -> b.setLastModiEmpnm(nm)
     *     ),
     *     "(이름없음)"
     * );
     * </pre>
     */
    public <T> void enrichNames(
            Collection<T> items,
            List<Function<? super T, ? extends String>> empNoGetters,
            List<BiConsumer<? super T, ? super String>> nameSetters,
            String defaultName
    ) {
        if (items == null || items.isEmpty()) return;
        if (empNoGetters == null || nameSetters == null || empNoGetters.size() != nameSetters.size()) {
            throw new IllegalArgumentException("empNoGetters와 nameSetters의 크기가 같아야 합니다.");
        }

        Set<String> allNos = new LinkedHashSet<>();
        for (T it : items) {
            for (Function<? super T, ? extends String> g : empNoGetters) {
                String no = safeTrim(g.apply(it));
                if (no != null && !no.isEmpty()) allNos.add(no);
            }
        }
        if (allNos.isEmpty()) return;

        Map<String, String> nameMap = getNameMapByEmpNos(allNos);

        for (T it : items) {
            for (int i = 0; i < empNoGetters.size(); i++) {
                String no = safeTrim(empNoGetters.get(i).apply(it));
                if (no != null && !no.isEmpty()) {
                    String nm = nameMap.getOrDefault(no, defaultName);
                    nameSetters.get(i).accept(it, nm);
                }
            }
        }
    }

    /**
     * ✅ 예시 (기본값 생략 버전)
     * <pre>
     * empNameUtil.enrichNames(
     *     bannerList,
     *     List.of(BannerDTO::getFrstRegrEmpno, BannerDTO::getLastModiEmpno),
     *     List.of(
     *         (BannerDTO b, String nm) -> b.setFrstRegrEmpnm(nm),
     *         (BannerDTO b, String nm) -> b.setLastModiEmpnm(nm)
     *     )
     * );
     * </pre>
     */
    public <T> void enrichNames(
            Collection<T> items,
            List<Function<? super T, ? extends String>> empNoGetters,
            List<BiConsumer<? super T, ? super String>> nameSetters
    ) {
        enrichNames(items, empNoGetters, nameSetters, "(이름없음)");
    }

    // ─────────────────────────────────────────────
    // 🔸 4. 단일 객체
    // ─────────────────────────────────────────────
    /**
     * ✅ 예시:
     * <pre>
     * empNameUtil.enrichOne(
     *     bannerDto,
     *     BannerDTO::getFrstRegrEmpno,
     *     (BannerDTO b, String nm) -> b.setFrstRegrEmpnm(nm),
     *     "(이름없음)"
     * );
     * </pre>
     */
    public <T> void enrichOne(
            T item,
            Function<? super T, ? extends String> empNoGetter,
            BiConsumer<? super T, ? super String> nameSetter,
            String defaultName
    ) {
        if (item == null) return;
        String empNo = safeTrim(empNoGetter.apply(item));
        if (empNo == null || empNo.isEmpty()) return;

        Map<String, String> nameMap = getNameMapByEmpNos(List.of(empNo));
        nameSetter.accept(item, nameMap.getOrDefault(empNo, defaultName));
    }

    /**
     * ✅ 예시 (defaultName 생략)
     * <pre>
     * empNameUtil.enrichOne(
     *     bannerDto,
     *     BannerDTO::getFrstRegrEmpno,
     *     (BannerDTO b, String nm) -> b.setFrstRegrEmpnm(nm)
     * );
     * </pre>
     */
    public <T> void enrichOne(
            T item,
            Function<? super T, ? extends String> empNoGetter,
            BiConsumer<? super T, ? super String> nameSetter
    ) {
        enrichOne(item, empNoGetter, nameSetter, "(이름없음)");
    }

    // ─────────────────────────────────────────────
    // 내부 헬퍼
    // ─────────────────────────────────────────────
    private String safeTrim(String s) {
        return s == null ? null : s.trim();
    }



    /**
     * ✅ 예시:
     * <pre>
     * Set&lt;String&gt; empNos = Set.of("E1001", "E1002");
     * Map&lt;String, String&gt; nameMap = empNameUtil.getPhoneMapByEmpNos(empNos);
     * // 결과: {E1001=01012345678, E1002=01011111111}
     * </pre>
     */
    public Map<String, String> getPhoneMapByEmpNos(Collection<String> empNos) {
        if (empNos == null || empNos.isEmpty()) return Collections.emptyMap();

        Set<String> cleaned = empNos.stream()
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toCollection(LinkedHashSet::new));
        if (cleaned.isEmpty()) return Collections.emptyMap();

        final int CHUNK = 900;
        List<String> list = new ArrayList<>(cleaned);
        Map<String, String> result = new LinkedHashMap<>();

        for (int i = 0; i < list.size(); i += CHUNK) {
            int end = Math.min(i + CHUNK, list.size());
            Set<String> slice = new LinkedHashSet<>(list.subList(i, end));

            List<EmpInfoDTO> rows = jojicMapper.selectSearchPhoneList(slice);
            if (rows == null) continue;

            for (EmpInfoDTO row : rows) {
                if (row == null) continue;
                String no = safeTrim(row.getEmpNo());
                String phone = safeTrim(row.getCellno());
                if (no != null && phone != null && !no.isEmpty() && !phone.isEmpty()) {
                    result.putIfAbsent(no, phone);
                }
            }
        }
        return result;
    }

    // ─────────────────────────────────────────────
    // 🔸 2. 리스트(단일 사번 필드) → 이름 매핑
    // ─────────────────────────────────────────────
    /**
     * ✅ 예시:
     * <pre>
     * empNameUtil.enrichPhone(
     *     bannerList,
     *     BannerDTO::getFrstRegrEmpno,                // getter
     *     (BannerDTO b, String nm) -> b.setFrstRegrEmpnm(nm), // setter
     *     "(이름없음)"                                 // 기본값
     * );
     * </pre>
     */

    public <T> void enrichPhone(
            Collection<T> items,
            Function<? super T, ? extends String> empNoGetter,
            BiConsumer<? super T, ? super String> phoneSetter,
            Function<? super T, ? extends String> defualtPhoneGetter
    ) {
        if (items == null || items.isEmpty()) return;

        Set<String> empNos = items.stream()
                .map(empNoGetter)
                .map(this::safeTrim)
                .filter(s -> s != null && !s.isEmpty())
                .collect(Collectors.toCollection(LinkedHashSet::new));
        if (empNos.isEmpty()) return;

        Map<String, String> phoneMap = getPhoneMapByEmpNos(empNos);

        items.forEach(it -> {
            String no = safeTrim(empNoGetter.apply(it));

            if (no == null || no.isEmpty()) return;

            // phoneMap 에 사번이 없는 경우를 대비해서 get() 사용
            String phone = phoneMap.get(no);

            if (phone != null) {
                // 🔹 사번 매핑 성공
                phoneSetter.accept(it, phone);
            } else {
                // 🔹 사번 조회 실패 (select 안 된 경우)
                String defaultPhone = safeTrim(defualtPhoneGetter.apply(it));
               // phoneSetter.accept(it, defaultPhone);  // defaultPhone 은 null일 수도 있음
                phoneSetter.accept(it, "");
            }
        });
    }

    public Map<String, EmpInfoDTO> getUserMapByEmpNos(Collection<String> empNos) {
        if (empNos == null || empNos.isEmpty()) return Collections.emptyMap();

        Set<String> cleaned = empNos.stream()
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toCollection(LinkedHashSet::new));
        if (cleaned.isEmpty()) return Collections.emptyMap();

        final int CHUNK = 900;
        List<String> list = new ArrayList<>(cleaned);
        Map<String, EmpInfoDTO> result = new LinkedHashMap<>();

        for (int i = 0; i < list.size(); i += CHUNK) {
            int end = Math.min(i + CHUNK, list.size());
            Set<String> slice = new LinkedHashSet<>(list.subList(i, end));

            List<EmpInfoDTO> rows = jojicMapper.selectSearchUserInfoList(slice);
            if (rows == null) continue;

            for (EmpInfoDTO row : rows) {
                if (row == null) continue;
                String no = safeTrim(row.getEmpNo());
                if (no == null || no.isEmpty()) continue;

                // 같은 사번이 여러 번 나와도 최초 1건만 사용
                result.putIfAbsent(no, row);
            }
        }
        return result;
    }
    public <T> void enrichUserInfo(
            Collection<T> items,
            Function<? super T, ? extends String> empNoGetter,       // 사번 꺼내는 함수
            BiConsumer<? super T, ? super EmpInfoDTO> infoConsumer   // EmpInfoDTO를 받아서 셋팅하는 람다
    ) {
        if (items == null || items.isEmpty()) return;

        // 1) 사번 목록 추출
        Set<String> empNos = items.stream()
                .map(empNoGetter)
                .map(this::safeTrim)
                .filter(s -> s != null && !s.isEmpty())
                .collect(Collectors.toCollection(LinkedHashSet::new));

        if (empNos.isEmpty()) return;

        // 2) 사번 → EmpInfoDTO 맵 조회
        Map<String, EmpInfoDTO> userMap = getUserMapByEmpNos(empNos);
        if (userMap.isEmpty()) return;

        // 3) 각 item에 EmpInfoDTO 세팅
        items.forEach(it -> {
            String empNo = safeTrim(empNoGetter.apply(it));
            if (empNo == null || empNo.isEmpty()) return;

            EmpInfoDTO info = userMap.get(empNo);
            if (info != null) {
                infoConsumer.accept(it, info);
            }
        });
    }

    public <T> void enrichUserInfo2(
            Collection<T> items,
            Function<? super T, ? extends String> empNoGetter,
            BiConsumer<? super T, ? super String> nameSetter,
            BiConsumer<? super T, ? super String> deptSetter,
            BiConsumer<? super T, ? super String> levelSetter,
            BiConsumer<? super T, ? super String> titleSetter
    ) {
        if (items == null || items.isEmpty()) return;

        Set<String> empNos = items.stream()
                .map(empNoGetter)
                .map(this::safeTrim)
                .filter(s -> s != null && !s.isEmpty())
                .collect(Collectors.toCollection(LinkedHashSet::new));

        if (empNos.isEmpty()) return;

        Map<String, EmpInfoDTO> userMap = getUserMapByEmpNos(empNos);

        items.forEach(it -> {
            String empNo = safeTrim(empNoGetter.apply(it));
            if (empNo == null || empNo.isEmpty()) return;

            EmpInfoDTO info = userMap.get(empNo);
            if (info == null) return;

            if (nameSetter != null)  nameSetter.accept(it, safeTrim(info.getName()));
            if (deptSetter != null)  deptSetter.accept(it, safeTrim(info.getDeptNm()));
            if (levelSetter != null) levelSetter.accept(it, safeTrim(info.getLevelnm()));
            if (titleSetter != null) titleSetter.accept(it, safeTrim(info.getTitle()));
        });
    }

    public <T> void enrichUserDeptAndNm(
            T item,
            Function<? super T, ? extends String> empNoGetter,
            BiConsumer<? super T, ? super String> nameSetter,
            BiConsumer<? super T, ? super String> deptSetter
    ) {
        if(item == null) return;
        enrichUserInfo2(Collections.singletonList(item), empNoGetter, nameSetter, deptSetter, null, null);
    }


}
