package kr.kepco.edu.admin.dto;

import kr.kepco.edu.admin.request.BaseRequest;
import lombok.Data;

import java.util.HashSet;
import java.util.Set;

@Data
public class EmpInfoDTO  extends BaseRequest {
    private  int rnum;

    private String empNo;

    private String name;

    private String deptno;

    private String levelnm;

    private String title;

    private String cellno;

    private String mailno;

    private String deptNm;
    
    private String role;

    private Set<String> roles = new HashSet<>();

}