package kr.kepco.edu.admin.mappers.mapperMaria;

import kr.kepco.edu.admin.dto.NoticeDTO;
import kr.kepco.edu.admin.request.BannerReq;
import kr.kepco.edu.admin.request.NoticeReq;
import kr.kepco.edu.admin.response.Page;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface NoticeMapper {

    int selectNoticeListCnt(@Param("param") NoticeReq param);

    List<NoticeDTO> selectNoticeList(@Param("param") NoticeReq param, @Param("page") Page<NoticeDTO> page);

    NoticeDTO selectNoticeDetail(NoticeReq param);

    int insertNotice(NoticeReq req);

    int updateNotice(NoticeReq req);

    int deleteNotice(NoticeReq req);

    int selectNoticePinnedCnt();

    int updateSortOrder(NoticeReq req);

    int updateOrderSetting(NoticeReq req);
}
