package kr.kepco.edu.admin.service;

import kr.kepco.edu.admin.dto.IfHisDTO;
import kr.kepco.edu.admin.mappers.mapperMaria.IfHisMapper;
import kr.kepco.edu.admin.request.IfHisReq;
import kr.kepco.edu.admin.response.Page;
import kr.kepco.edu.admin.util.CommonUtil;
import kr.kepco.edu.admin.util.EmpNameUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IfHisService {
    @Autowired
    IfHisMapper ifHisMapper;

    @Autowired
    EmpNameUtil empNameUtil;


    public int selectIfHisListCnt(IfHisReq req) { return ifHisMapper.selectIfHisListCnt(req); }

    public List<IfHisDTO> selectIfHisList(IfHisReq req, Page<IfHisDTO> page) {

        List<IfHisDTO> ifHisDTOS = ifHisMapper.selectIfHisList(req, page);

        if(!CommonUtil.isValid(ifHisDTOS)){
            return ifHisDTOS;
        }

        empNameUtil.enrichName(
                ifHisDTOS,
                IfHisDTO::getFrstRegrEmpno,
                IfHisDTO::setFrstRegrEmpnm,
                "홍길동"
        );

        return ifHisDTOS;
    }
}
