package kr.kepco.edu.admin.config;

import kr.kepco.edu.admin.filter.AccessLogInterceptor;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.web.servlet.DispatcherServletAutoConfiguration;
import org.springframework.boot.autoconfigure.web.servlet.DispatcherServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.unit.DataSize;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.support.StandardServletMultipartResolver;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.servlet.MultipartConfigElement;
import java.nio.file.Path;
import java.nio.file.Paths;

@Configuration
@RequiredArgsConstructor
public class WebConfig implements WebMvcConfigurer {

    private final AccessLogInterceptor accessLogInterceptor;

    @Value("${file.upload.path}")
    private String uploadRoot;

    @Value("${spring.servlet.multipart.location:${java.io.tmpdir}}")
    private String multipartLocation;

    @Value("${spring.servlet.multipart.max-file-size}")
    private String maxFileSize;           // ex) "500MB"

    @Value("${spring.servlet.multipart.max-request-size}")
    private String maxRequestSize;        // ex) "500MB"


    // 404를 예외로 던지도록 DispatcherServlet 수동 등록 (사용 유지)
    @Bean(name = "dispatcherServlet")
    public DispatcherServlet dispatcherServlet() {
        DispatcherServlet ds = new DispatcherServlet();
        ds.setThrowExceptionIfNoHandlerFound(true);
        return ds;
    }

    // MultipartConfigElement: 서블릿에 멀티파트 설정 "반드시" 부착
    @Bean
    public MultipartConfigElement multipartConfigElement() {
        long maxFile = DataSize.parse(maxFileSize).toBytes();
        long maxReq  = DataSize.parse(maxRequestSize).toBytes();
        return new MultipartConfigElement(multipartLocation, maxFile, maxReq, 0);
    }

    // DispatcherServlet 등록 시 MultipartConfig 세팅
    @Bean
    public DispatcherServletRegistrationBean dispatcherServletRegistration(
            DispatcherServlet dispatcherServlet,
            MultipartConfigElement multipartConfigElement
    ) {
        DispatcherServletRegistrationBean reg =
                new DispatcherServletRegistrationBean(dispatcherServlet, "/");
        reg.setName(DispatcherServletAutoConfiguration.DEFAULT_DISPATCHER_SERVLET_REGISTRATION_BEAN_NAME);
        reg.setLoadOnStartup(1);
        // 핵심: 멀티파트 설정 부착
        reg.setMultipartConfig(multipartConfigElement);
        return reg;
    }

    // 표준 서블릿 기반 멀티파트 리졸버 (CommonsMultipartResolver 사용 안 함)
    @Bean
    public MultipartResolver multipartResolver() {
        return new StandardServletMultipartResolver();
    }

    // 정적 리소스: /files/** → file.upload.path
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        Path root = Paths.get(uploadRoot).toAbsolutePath().normalize();
        registry.addResourceHandler("/files/**")
                .addResourceLocations("file:" + root.toString() + "/");
    }

    // 인터셉터 등록
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(accessLogInterceptor)
                .addPathPatterns("/**");
    }
}
