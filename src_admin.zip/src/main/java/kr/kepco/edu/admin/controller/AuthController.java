package kr.kepco.edu.admin.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import kr.kepco.edu.admin.dto.EduUserDTO;
import kr.kepco.edu.admin.dto.UserDTO;
import kr.kepco.edu.admin.filter.jwt.JwtTokenProvider;
import kr.kepco.edu.admin.request.LoginRequest;
import kr.kepco.edu.admin.response.ApiResponse;
import kr.kepco.edu.admin.service.AccessLogService;
import kr.kepco.edu.admin.service.UserService;
import kr.kepco.edu.admin.util.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashSet;
import java.util.Set;


@Tag(name = "00.Login API", description = "사용자 로그인")
@RestController
@RequestMapping("${base.url}/auth")
@CrossOrigin(origins = "*")
public class AuthController {
    @Autowired
    JwtTokenProvider jwtTokenProvider;

    @Autowired
    UserService userDetailsService;
    
    @Autowired
    AccessLogService accessLogService;

    @Operation(
            summary = "사내직원 로그인",
            description = "empId로 사용자 확인 후 JWT 토큰을 발급합니다.",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = LoginRequest.class),
                            examples = {
                                    @ExampleObject(
                                            name = "정상 요청",
                                            value = "{ \"empId\": \"11112223\" }"
                                    ),
                                    @ExampleObject(
                                            name = "실패 요청",
                                            value = "{ \"empId\": \"EEEEEEEE\" }"
                                    )
                            }
                    )
            )
    )
    @PostMapping("/login")
    public ResponseEntity<ApiResponse<?>> kepcoLogin(@RequestBody LoginRequest loginRequest) {
        UserDTO user = userDetailsService.loginUser(loginRequest.getEmpId());

        if (!CommonUtil.isValid(user)) {
            return ResponseEntity.ok(ApiResponse.fail(HttpStatus.BAD_REQUEST, "요청하신 사번이 존재하지 않습니다."));
        }

        if(!userDetailsService.chkPassword(loginRequest)) {
            return ResponseEntity.ok(ApiResponse.fail(HttpStatus.BAD_REQUEST, "패스워드가 올바르지 않습니다."));
        }

        Set<String> roles = new HashSet<>();
        roles.add(user.getEdamsAuthCd());
        user.setRoles(roles);
        
        if(CommonUtil.isValid(user.getEdamsAuthCd())) {
            user.setMenuIds(userDetailsService.selectMenuIds(user.getEdamsAuthCd()));
        }

        accessLogService.accessLog(loginRequest.getEmpId(),"ADMIN_001");

        return ResponseEntity.ok(ApiResponse.ok(HttpStatus.CREATED, jwtTokenProvider.createToken(user), "토큰생성"));
    }
}

