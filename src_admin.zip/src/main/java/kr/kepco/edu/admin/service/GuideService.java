package kr.kepco.edu.admin.service;

import kr.kepco.edu.admin.dto.GuideDTO;
import kr.kepco.edu.admin.mappers.mapperMaria.GuideMapper;
import kr.kepco.edu.admin.request.GuideReq;
import kr.kepco.edu.admin.response.Page;
import kr.kepco.edu.admin.util.CommonUtil;
import kr.kepco.edu.admin.util.EmpNameUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class GuideService {

    @Autowired
    GuideMapper gideMapper;


    @Autowired
    EmpNameUtil empNameUtil;

    public List<GuideDTO> getGuideList(Page<GuideDTO> page, GuideReq req) {

        List<GuideDTO> guideDTOS = gideMapper.selectGuideList(page,req);

        if(!CommonUtil.isValid(guideDTOS)) {
            return guideDTOS;
        }

        empNameUtil.enrichName(
                guideDTOS,
                GuideDTO::getFrstRegrEmpno,
                GuideDTO::setFrstRegrEmpnm,
                "홍길동"
        );

        return guideDTOS;
    }

    public int selectGuideListCount(GuideReq req) {
        return gideMapper.selectGuideListCount(req);
    }

    public List<GuideDTO> getGuideMasterList(GuideReq req) {
        return gideMapper.selectGuideMasterList(req);
    }

    @Transactional
    public boolean insertGuideMaster(GuideReq dto) {
        return gideMapper.insertGuideMaster(dto) > 0;
    }

    @Transactional
    public int insertGuideDetail(GuideReq dto) {
        return gideMapper.insertGuideDetail(dto);
    }

    @Transactional
    public int updateGuideList(GuideReq dto) {
        return gideMapper.updateGuideList(dto);
    }

    @Transactional
    public int updateGuideDetail(GuideReq dto) {
        return gideMapper.updateGuideDetail(dto);
    }

    @Transactional
    public boolean deleteGuideList(GuideReq dto) {
        gideMapper.updateGuideMasterOrderSetting(dto);
        return gideMapper.deleteGuideList(dto) > 0;
    }

    @Transactional
    public boolean deleteGuideDetail(GuideReq dto) {
        if (gideMapper.deleteGuideDetail(dto) > 0) {
            gideMapper.updateGuideMasterOrderSetting(dto);
            return true;
        }
        return false;
    }

    @Transactional
    public boolean insert(GuideReq dto) {

//        if(!CommonUtil.isValid(dto.getEduGuideSerno())) {
//            gideMapper.insertGuideList(dto);
//        }

        if(gideMapper.insertGuideDetail(dto) > 0) {
            if (dto.getPstnYn().equals("Y")) {
                gideMapper.updateGuideDetailPstnYn(dto);
                gideMapper.updateGuideMasterSortOrder(dto);
            }
            return true;
        } else {
            return false;
        }
    }

    @Transactional
    public boolean modify(GuideReq dto) {
        if(gideMapper.updateGuideDetail(dto) > 0) {
            if (dto.getPstnYn().equals("Y")) {
                gideMapper.updateGuideDetailPstnYn(dto);
                gideMapper.updateGuideMasterSortOrder(dto);
            }
            return true;
        }
        return false;
    }

    public GuideDTO getGuideDetail(GuideReq req) {
        GuideDTO guideDTO = gideMapper.selectGuideDetail(req);

        if(!CommonUtil.isValid(guideDTO)) {
            return guideDTO;
        }

        empNameUtil.enrichOne(
                guideDTO,
                GuideDTO::getFrstRegrEmpno,
                GuideDTO::setFrstRegrEmpnm,
                "홍길동"
        );

        return guideDTO;
    }

    public int getGuideMasterPstnCnt(GuideReq dto) {
        return gideMapper.selectGuideMasterPstnCnt(dto);
    }

}
