package kr.kepco.edu.admin.request;

import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.media.Schema;
import kr.kepco.edu.admin.validation.RequestGroup;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Schema(name = "MealReq", description = "요청 DTO(그룹: Create/Update/Search). viewType으로 응답 형태 지정")
public class MealReq extends BaseRequest{

    @Schema(description = "주간식단 일련번호 (PK)", example = "WEEK20250101")
    @JsonView({ RequestGroup.Detail.class })
    private String wklyMealplSerno;

    @Schema(description = "최초등록일시", example = "2025-01-01 09:00:00")
    private String frstRegDt;

    @Schema(description = "최초등록자사번", example = "EMP001")
    private String frstRegrEmpno;

    @Schema(description = "최종변경일시", example = "2025-01-03 13:30:00")
    private String lstChgDt;

    @Schema(description = "최종변경자사번", example = "EMP002")
    private String lstChgrEmpno;

    @Schema(description = "년도", example = "2025")
    @JsonView({ RequestGroup.Search.class })
    private String wklyMealplYy;

    @Schema(description = "월", example = "03")
    @JsonView({ RequestGroup.Search.class })
    private String wklyMealplMm;

    @Schema(description = "주차", example = "02")
    @JsonView({ RequestGroup.Search.class })
    private String wklyMealplWkcnt;

    @Schema(description = "주간 식단 제목", example = "2025년 2주차 주간 식단표")
    @JsonView({ RequestGroup.Search.class })
    private String wklyMealplTitlNm;

    @Schema(description = "정렬", defaultValue = "null")
    private String sortOrd;

    @Schema(description = "삭제여부", example = "N", defaultValue = "N")
    private String delYn;

}
