package kr.kepco.edu.admin.service;

import kr.kepco.edu.admin.dto.AccessLogDTO;
import kr.kepco.edu.admin.dto.SelectOptionDTO;
import kr.kepco.edu.admin.mappers.mapperMaria.AccessLogMapper;
import kr.kepco.edu.admin.request.AccessLogReq;
import kr.kepco.edu.admin.response.Page;
import kr.kepco.edu.admin.util.EmpNameUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class AccessLogService {
    @Autowired
    AccessLogMapper accessLogMapper;

    @Autowired
    EmpNameUtil empNameUtil;


    public List<AccessLogDTO> getAccessLogList (AccessLogReq accessLogReq, Page<AccessLogDTO> page) {
        List<AccessLogDTO> list = accessLogMapper.selectAccessLogList(accessLogReq,page);

        empNameUtil.enrichUserInfo2(
                list,
                AccessLogDTO::getFrstRegrEmpno,
                AccessLogDTO::setUserNm,
                AccessLogDTO::setUserDeptNm,
                AccessLogDTO::setUserLevelNm,
                AccessLogDTO::setUserTitle
        );
        return list;
    }

    public int getAccessLogListCnt (AccessLogReq accessLogReq) {
        return accessLogMapper.selectAccessLogListCnt(accessLogReq);
    }

    public List<SelectOptionDTO> selectMenuList() {
        return accessLogMapper.selectMenuList();
    }

    public void accessLog(String mngrId, String menuId) {
        accessLogMapper.accessLog(mngrId,menuId);
    }

    public List<Map<String, Object>> selectAccessLogStatByMenus(
            Map<String, Object> param
    ) {
        return accessLogMapper.selectAccessLogStatByMenus(param);
    }


}
