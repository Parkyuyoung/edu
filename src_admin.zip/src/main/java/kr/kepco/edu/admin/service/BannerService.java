package kr.kepco.edu.admin.service;

import kr.kepco.edu.admin.dto.BannerDTO;
import kr.kepco.edu.admin.mappers.mapperMaria.BannerMapper;
import kr.kepco.edu.admin.request.BannerReq;
import kr.kepco.edu.admin.response.ApiResponse;
import kr.kepco.edu.admin.response.Page;
import kr.kepco.edu.admin.util.CommonUtil;
import kr.kepco.edu.admin.util.EmpNameUtil;
import kr.kepco.edu.admin.validation.ErrorCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
public class BannerService {

    @Autowired
    BannerMapper bannerMapper;

    @Autowired
    JojicService jojicService;

    @Autowired
    EmpNameUtil empNameUtil;

    @Autowired
    FileService fileService;

    public int insertBanner(BannerReq bannerReq) {
        return bannerMapper.insertBanner(bannerReq);
    }

    public List<BannerDTO> getBannerPostYnList(BannerReq bannerReq) {
        return bannerMapper.selectBannerPostYnList(bannerReq);
    }

    public List<BannerDTO> getBannerList(BannerReq bannerReq, Page<BannerDTO> page) {
        List<BannerDTO> list = bannerMapper.selectBannerList(bannerReq,page);

        empNameUtil.enrichName(
                list,
                BannerDTO::getFrstRegrEmpno,
                BannerDTO::setFrstRegrEmpnm,
                " "
        );

        return list;
    }

    public int getBannerListCnt(BannerReq bannerReq) {
        return bannerMapper.selectBannerListCnt(bannerReq);
    }

    public BannerDTO getBannerDetail(BannerReq bannerReq) {
        BannerDTO bannerDTO = bannerMapper.selectBannerDetail(bannerReq);
        empNameUtil.enrichOne(
                bannerDTO,
                BannerDTO::getFrstRegrEmpno,
                BannerDTO::setFrstRegrEmpnm,
                " "
        );
        return bannerDTO;
    }

    public int modifyBanner(BannerReq bannerReq) {
        return bannerMapper.modifyBanner(bannerReq);
    }

    @Transactional
    public boolean deleteBanner(BannerReq bannerReq) {
        if (bannerMapper.deleteBanner(bannerReq) > 0) {
            try {
                fileService.deleteSearch(bannerReq.getBnrSerNo(), bannerReq.getLstChgrEmpno(), "M", "banner",true);
                fileService.deleteSearch(bannerReq.getBnrSerNo(), bannerReq.getLstChgrEmpno(), "T", "banner",true);
            } catch (IllegalArgumentException i) {
                System.out.println("파일삭제실패");
            }
            bannerMapper.updateOrderSetting(bannerReq);
            return true;
        }
        return false;
    }

    public int modifyPostYn(BannerReq bannerReq) {
        return bannerMapper.modifyPostYn(bannerReq);
    }

    public int getPostnCnt() {
        return bannerMapper.selectPostnCnt();
    }

    @Transactional
    public boolean insert(BannerReq bannerReq, MultipartFile mFile, MultipartFile tFile) {

        int i = bannerMapper.insertBanner(bannerReq);

        if (bannerReq.getPstnYn().equals("Y")) {
            bannerMapper.updateSortOrder(bannerReq);
        }

        if(i > 0 && CommonUtil.isValid(bannerReq.getBnrSerNo())) {
            if (CommonUtil.isValid(mFile)) {
                fileService.register(
                        mFile,
                        "banner",
                        bannerReq.getBnrSerNo(),
                        "M",
                        0,
                        "banner",
                        bannerReq.getFrstRegrEmpno()
                );
            }

            if (CommonUtil.isValid(tFile)) {
                fileService.register(
                        tFile,
                        "banner",
                        bannerReq.getBnrSerNo(),
                        "T",
                        0,
                        "banner",
                        bannerReq.getFrstRegrEmpno()
                );
            }
        }

        return i > 0;
    }

    @Transactional
    public boolean modify(BannerReq bannerReq, MultipartFile mFile, MultipartFile tFile) {
        int i = bannerMapper.modifyBanner(bannerReq);

        if (bannerReq.getPstnYn().equals("Y")) {
            bannerMapper.updateSortOrder(bannerReq);
        }

        System.out.println("count >>>>>  " + i);

        if (i > 0) {
            if (CommonUtil.isValid(mFile)) {
                System.out.println("test@@@@@@@@@@@");
                fileService.deleteSearch(bannerReq.getBnrSerNo(),bannerReq.getLstChgrEmpno(), "M","banner",true);
                fileService.register(
                        mFile,
                        "banner",
                        bannerReq.getBnrSerNo(),
                        "M",
                        0,
                        "banner",
                        bannerReq.getLstChgrEmpno()
                );
                System.out.println("test@@@@@@333333@@@@@");
            }

            if (CommonUtil.isValid(tFile)) {
                fileService.deleteSearch(bannerReq.getBnrSerNo(),bannerReq.getLstChgrEmpno(),"T","banner",true);
                fileService.register(
                        tFile,
                        "banner",
                        bannerReq.getBnrSerNo(),
                        "T",
                        0,
                        "banner",
                        bannerReq.getLstChgrEmpno()
                );
            }
        }
        return i > 0;
    }
}
