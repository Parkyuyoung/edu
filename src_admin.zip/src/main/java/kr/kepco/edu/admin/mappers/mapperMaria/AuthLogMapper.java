package kr.kepco.edu.admin.mappers.mapperMaria;

import kr.kepco.edu.admin.dto.AuthLogDTO;
import kr.kepco.edu.admin.request.AuthLogReq;
import kr.kepco.edu.admin.response.Page;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface AuthLogMapper {
    int selectAuthLogListCnt(@Param("param") AuthLogReq authLogReq);
    List<AuthLogDTO> selectAuthLogList(@Param("param") AuthLogReq authLogReq, @Param("page") Page<AuthLogDTO> page);
}
