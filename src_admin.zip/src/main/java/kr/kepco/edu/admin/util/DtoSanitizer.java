package kr.kepco.edu.admin.util;

import kr.kepco.edu.admin.validation.ErrorCode;
import lombok.extern.slf4j.Slf4j;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.*;
@Slf4j
final class DtoSanitizer {
    private DtoSanitizer(){}

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.FIELD)
    public @interface SkipSanitize {}

    /**
     * 필수 필드 검사 + 전체 String 필드 XSS 정화
     * @param dto 검사 대상 객체
     * @param requiredFields 필수 필드 이름들
     * @return 모든 필수 필드가 유효하면 true, 아니면 false
     */
    public static <T> boolean sanitizeAndValidate(T dto, String... requiredFields) {
        if (dto == null) return false;

        Set<String> required = new HashSet<>(Arrays.asList(requiredFields));

        for (Field f : getAllFields(dto.getClass())) {
            if (Modifier.isStatic(f.getModifiers())) continue;
            if (f.isAnnotationPresent(SkipSanitize.class)) continue;
            if (f.getType() != String.class) continue;

            f.setAccessible(true);
            try {
                String val = (String) f.get(dto);
                String name = f.getName();

                // ---- 필수 필드 ----
                if (required.contains(name)) {
                    if (!CommonUtil.isValid(val)) {
                        log.error("{} ::: {} 의 {}이 존재하지 않습니다. :: 입력값 = {}", ErrorCode.VAL_INVALID, dto.getClass().getSimpleName(), name, val);
                        return false; // 필수 필드 유효성 실패
                    }
                    f.set(dto, XssSanitizer.removeXSS(val));
                    continue;
                }

                // ---- 옵션 필드 ----
                if (val == null) continue;
                if (!CommonUtil.isValid(val)) {
                    f.set(dto, null);
                } else {
                    f.set(dto, XssSanitizer.removeXSS(val));
                }

            } catch (IllegalAccessException | IllegalArgumentException e) {
                log.warn("필드 접근 불가 — {}.{} : {}", dto.getClass().getSimpleName(), f.getName(), e.getMessage());
            }
        }

        return true; // 모든 필수 필드 통과
    }

    private static List<Field> getAllFields(Class<?> cls) {
        List<Field> list = new ArrayList<>();
        for (Class<?> c = cls; c != null && c != Object.class; c = c.getSuperclass()) {
            Collections.addAll(list, c.getDeclaredFields());
        }
        return list;
    }
}
