package kr.kepco.edu.admin.service;

import kr.kepco.edu.admin.dto.EduUserDTO;
import kr.kepco.edu.admin.mappers.mapperMaria.EduUserMapper;
import kr.kepco.edu.admin.request.AuthLogReq;
import kr.kepco.edu.admin.request.EduUserReq;
import kr.kepco.edu.admin.response.Page;
import kr.kepco.edu.admin.util.EmpNameUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class EduUserService {

    @Autowired
    EduUserMapper eduUserMapper;

    @Autowired
    EmpNameUtil empNameUtil;

    public int geteduUserListCnt(EduUserReq eduUserReq) {
        return eduUserMapper.selectEduUserListCnt(eduUserReq);
    }

    public List<EduUserDTO> getEduUserList(EduUserReq eduUserReq, Page<EduUserDTO> page) {
        List<EduUserDTO> list =  eduUserMapper.selectEduUserList(eduUserReq, page);

        empNameUtil.enrichUserInfo2(
                list,
                EduUserDTO::getUserId,
                EduUserDTO::setUserNm,
                EduUserDTO::setUserDeptNm,
                EduUserDTO::setUserLevelNm,
                EduUserDTO::setUserTitle
        );

        return list;
    }

    public boolean isDupEduUser(EduUserReq req) {
        return eduUserMapper.selectEduUserDupCnt(req) > 0;
    }

    @Transactional
    public int insertEduUser(EduUserReq eduUserReq) {
        return eduUserMapper.insertEduUser(eduUserReq);
    }

    @Transactional
    public int updateEduUser(EduUserReq eduUserReq) {
        return eduUserMapper.updateEduUser(eduUserReq);
    }

    @Transactional
    public int deleteEduUser(EduUserReq eduUserReq){
        return eduUserMapper.deleteEduUser(eduUserReq);
    }

    @Transactional
    public int insertAuthLog(AuthLogReq authLogReq){
        empNameUtil.enrichUserDeptAndNm(
                authLogReq,
                AuthLogReq::getUserId,
                AuthLogReq::setUserNm,
                AuthLogReq::setUserDeptNm
        );

        empNameUtil.enrichNameOne(
                authLogReq,
                AuthLogReq::getLstChgrEmpno,
                AuthLogReq::setLstChgrEmpnm
        );
        return eduUserMapper.insertAuthLog(authLogReq);
    }

    public boolean isValidEduAuth(String eduAuthCd) {
        return eduUserMapper.selectEduAuthExists(eduAuthCd) > 0;
    }


    public boolean isValidAdmin(String userId) {
        return eduUserMapper.selectAdminExists(userId) > 0;
    }



}
