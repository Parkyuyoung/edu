package kr.kepco.edu.admin.mappers.mapperMaria;

import kr.kepco.edu.admin.dto.MealDTO;
import kr.kepco.edu.admin.request.MealReq;
import kr.kepco.edu.admin.response.Page;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface MealMapper {
    int insertMealList(MealReq dto);

    int selectMealListCnt(@Param("param") MealReq req);

    List<MealDTO> selectMealList(@Param("param") MealReq req, @Param("page") Page<MealDTO> page);

    MealDTO selectMealDetail(MealReq req);

    Integer deleteMeal(MealReq req);

    int updateMeal(MealReq req);

    int existsYearWeek(MealReq req);
}
