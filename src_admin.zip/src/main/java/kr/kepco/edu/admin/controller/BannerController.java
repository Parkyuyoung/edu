package kr.kepco.edu.admin.controller;


import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import kr.kepco.edu.admin.dto.BannerDTO;
import kr.kepco.edu.admin.request.BannerReq;
import kr.kepco.edu.admin.response.ApiListResponse;
import kr.kepco.edu.admin.response.ApiResponse;
import kr.kepco.edu.admin.response.Page;
import kr.kepco.edu.admin.service.BannerService;
import kr.kepco.edu.admin.service.CustomUserDetails;
import kr.kepco.edu.admin.service.FileService;
import kr.kepco.edu.admin.service.JojicService;
import kr.kepco.edu.admin.util.CommonUtil;
import kr.kepco.edu.admin.validation.ErrorCode;
import kr.kepco.edu.admin.validation.RequestGroup;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;


@Tag(name = "05. 배너 관리", description = "배너 관리 게시판")
@RestController
@Slf4j
@RequestMapping("${base.url}/banner")
public class BannerController {

    @Autowired
    BannerService bannerService;

    @Autowired
    FileService fileService;

    @Autowired
    JojicService jojicService;


    @Value("${file.upload.path}")
    private String uploadRoot;

    @Operation(
            summary = "배너 조회",
            description = "게시된 배너 조회",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            schema = @Schema(implementation = BannerReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "배너목록 조회",
                                            value = "{ \"postYn\": \"Y\"}"
                                    )
                            }
                    )
            )
    )
    @PostMapping(value = "/getBannerPostYnList")
    public ApiListResponse<BannerDTO> getBannerPostYnList(@AuthenticationPrincipal CustomUserDetails user, @RequestBody @JsonView(RequestGroup.Search.class) BannerReq bannerReq) {
        List<BannerDTO> bannerDTOs = bannerService.getBannerPostYnList(bannerReq);

        if(CommonUtil.isValid(bannerDTOs)) {
            return ApiListResponse.ok(HttpStatus.OK,bannerDTOs,"OK");
        } else {
            return ApiListResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }
    }

    @Operation(
            summary = "배너 목록 조회",
            description = "배너 목록 조회",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            schema = @Schema(implementation = BannerReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "전체 조회",
                                            value = "{ \"currentPage\": \"1\",\"pageSize\": \"10\"}"
                                    ),
                                    @ExampleObject(
                                            name = "배너 제목 조회",
                                            value = "{ \"currentPage\": \"1\",\"pageSize\": \"10\",\"bannerTtlNm\": \"25년\"}"
                                    ),
                                    @ExampleObject(
                                            name = "작성자 조회",
                                            value = "{ \"currentPage\": \"1\",\"pageSize\": \"10\",\"searchEmpName\": \"정인택\"}"
                                    )
                            }
                    )
            )
    )
    @PostMapping(value = "/getBannerList")
    public ApiResponse<Page<BannerDTO>> getBannerList(@AuthenticationPrincipal CustomUserDetails user, @RequestBody @JsonView(RequestGroup.Search.class) BannerReq bannerReq) {

        if (CommonUtil.isValid(bannerReq.getSearchEmpName())){
            List<String> empNoList = jojicService.getSeachEmpList(bannerReq.getSearchEmpName());
            if(!CommonUtil.isValid(empNoList)) return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
            bannerReq.setSearchEmpNo(empNoList);
        }

        Page<BannerDTO> page = new Page<>(bannerReq.getCurrentPage(),bannerReq.getPageSize(), bannerService.getBannerListCnt(bannerReq));

        List<BannerDTO> bannerDTOS = bannerService.getBannerList(bannerReq,page);

        page.setContent(bannerDTOS);

        if(CommonUtil.isValid(page.getContent())) {
            return ApiResponse.ok(HttpStatus.OK,page,"OK.");
        } else {
            return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }
    }

    @Operation(
            summary = "배너 등록",
            description = "배너 이미지  + 데이터 저장",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "MediaType.MULTIPART_FORM_DATA_VALUE",
                            schema = @Schema(implementation = BannerReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "배너 저장 (postYn 게시여부)",
                                            value = "{ \"bannerTtlNm\": \"2025년 교육배너\", " +
                                                    " \"bannerTxtCtt\": \"교육!!!!!\", \"sortOrd\": \" 1\", \"postYn\": \" n\"}"
                                    )
                            }
                    )
            )
    )
    @Transactional
    @PostMapping(value = "/insertBanner",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse<String> insertBanner(@AuthenticationPrincipal CustomUserDetails user,  @RequestPart("bannerReq") String bannerReqJson , @RequestPart(value = "mFile" , required = false) MultipartFile mFile , @RequestPart(value = "tFile" ,required = false) MultipartFile tFile) throws JsonProcessingException {

        BannerReq bannerReq = new ObjectMapper().readValue(bannerReqJson, BannerReq.class);

        if(!CommonUtil.isValid(bannerReq.getBnrTitlNm()) || !CommonUtil.isValid(bannerReq.getBnrCtt())) {
            return ApiResponse.fail(ErrorCode.REQ_MISSING_PARAM);
        }

        bannerReq.setFrstRegrEmpno(user.getUsername());
        bannerReq.setLstChgrEmpno(user.getUsername());

        if (bannerService.insert(bannerReq,mFile,tFile)) {
            return ApiResponse.ok(HttpStatus.OK,"등록에 성공하였습니다.","OK");
        } else {
            return ApiResponse.fail(ErrorCode.INSERT_INTERNAL);
        }
    }

    @Operation(
            summary = "배너 상세조회",
            description = "배너 상세조회",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            schema = @Schema(implementation = BannerReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "상세 조회",
                                            value = "{ \"bannerSerno\": \"BN00001\"}"
                                    )
                            }
                    )
            )
    )
    @PostMapping(value = "/getBannerDetail")
    public ApiResponse<BannerDTO> getBannerDetail(@AuthenticationPrincipal CustomUserDetails user, @RequestBody @JsonView(RequestGroup.Detail.class) BannerReq bannerReq) {

        if (!CommonUtil.isValid(bannerReq.getBnrSerNo())){
            return ApiResponse.fail(ErrorCode.REQ_MISSING_PARAM);
        }

        BannerDTO bannerDTOS = bannerService.getBannerDetail(bannerReq);

        if(CommonUtil.isValid(bannerDTOS)) {
            return ApiResponse.ok(HttpStatus.OK,bannerDTOS,"OK.");
        } else {
            return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }
    }


    @Operation(
            summary = "배너 수정",
            description = "배너 수정",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            schema = @Schema(implementation = BannerReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "배너 수정",
                                            value = "{ \"bannerSerno\": \"BN00001\",\"bannerTtlNm\": \"2025년 교육배너\", " +
                                                    " \"bannerTxtCtt\": \"교육!!!!!\", \"sortOrd\": \" 1\", \"postYn\": \" Y\"}"
                                    )
                            }
                    )
            )
    )
    @Transactional
    @PostMapping(value = "/modifyBanner",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse<String> modifyBanner(
            @AuthenticationPrincipal CustomUserDetails user,
            @RequestPart("bannerReq") String bannerReqJson,       // ← String으로 변경 (insert와 동일)
            @RequestPart(value = "mFile", required = false) MultipartFile mFile,
            @RequestPart(value = "tFile", required = false) MultipartFile tFile
        ) throws JsonProcessingException {

        BannerReq bannerReq = new ObjectMapper().readValue(bannerReqJson, BannerReq.class);

        if(!CommonUtil.isValid(bannerReq.getBnrSerNo()) || !CommonUtil.isValid(bannerReq.getBnrCtt())) {
            return ApiResponse.fail(ErrorCode.REQ_MISSING_PARAM);
        }

        bannerReq.setLstChgrEmpno(user.getUsername());

        if (bannerService.modify(bannerReq,mFile,tFile)){
            return ApiResponse.ok(HttpStatus.OK,"수정에 성공하였습니다.","OK");
        } else {
            return ApiResponse.fail(ErrorCode.INSERT_INTERNAL);
        }
    }

    @Operation(
            summary = "배너 삭제",
            description = "배너 삭제",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            schema = @Schema(implementation = BannerReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "배너 삭제",
                                            value = "{ \"bannerSerno\": \"BN00001\"}"
                                    )
                            }
                    )
            )
    )
    @PostMapping(value = "/deleteBanner")
    public ApiResponse<String > deleteBanner(@AuthenticationPrincipal CustomUserDetails user, @RequestBody @JsonView(RequestGroup.Detail.class) BannerReq bannerReq) {

        if (!CommonUtil.isValid(bannerReq.getBnrSerNo())){
            return ApiResponse.fail(ErrorCode.REQ_MISSING_PARAM);
        }
        bannerReq.setLstChgrEmpno(user.getUsername());

        if(bannerService.deleteBanner(bannerReq)) {
            return ApiResponse.ok(HttpStatus.OK,"정상적으로 삭제 되었습니다.","OK");
        } else {
            return ApiResponse.fail(ErrorCode.DELETE_INTERNAL);
        }
    }

    @Operation(
            summary = "배너 게시여부 수정",
            description = "배너 게시여부 수정",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            schema = @Schema(implementation = BannerReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "게시여부 수정",
                                            value = "{ \"bannerSerno\": \"BN00001\",\"postYn\": \"Y\"}"
                                    )
                            }
                    )
            )
    )
    @PostMapping(value = "/modifyPostYn")
    public ApiResponse<String > modifyPostYn(@AuthenticationPrincipal CustomUserDetails user, @RequestBody @JsonView(RequestGroup.Update.class) BannerReq bannerReq) {

        if (!CommonUtil.isValid(bannerReq.getBnrSerNo())){
            return ApiResponse.fail(ErrorCode.REQ_MISSING_PARAM);
        }

        bannerReq.setLstChgrEmpno(user.getUsername());
        int i = bannerService.modifyPostYn(bannerReq);

        if(i >  0 ) {
            return ApiResponse.ok(HttpStatus.OK,null,"수정이 정상적으로 처리되었습니다.");
        } else {
            return ApiResponse.fail(ErrorCode.DELETE_INTERNAL);
        }
    }

    @PostMapping("/getPostnCnt")
    public ApiResponse<Integer> getPostnCnt(@AuthenticationPrincipal CustomUserDetails user) {
        return ApiResponse.ok(HttpStatus.OK, bannerService.getPostnCnt(), "OK");
    }
}
