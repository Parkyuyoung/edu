package kr.kepco.edu.admin.util;

import java.util.regex.Pattern;

final class XssSanitizer {
    private XssSanitizer() {}

    // 스크립트 패턴 (대소문자/개행 무시)
    private static final Pattern SCRIPT_PATTERN =
            Pattern.compile("(?is)<\\s*script[^>]*>.*?<\\s*/\\s*script\\s*>");

    // 위험 태그 (닫는 태그 형태만 처리)
    private static final Pattern DANGEROUS_TAGS =
            Pattern.compile("(?is)<\\s*(script|iframe|embed|object|applet|link|style|img|meta|base)[^>]*>.*?<\\s*/\\s*\\1\\s*>");

    /**
     * 입력값에서 XSS 공격 요소 제거 + 특수문자 치환 (심플 버전)
     */
    public static String removeXSS(String value) {
        if (value == null) return null;

        // 위험 태그 반복 제거 (깨기/중첩 대응)
        while (SCRIPT_PATTERN.matcher(value).find()) {
            value = SCRIPT_PATTERN.matcher(value).replaceAll("");
        }
        while (DANGEROUS_TAGS.matcher(value).find()) {
            value = DANGEROUS_TAGS.matcher(value).replaceAll("");
        }

        // 특수문자 치환 (이 순서 유지 권장: & 먼저)
        value = value.replace("&", "&amp;");
        value = value.replace("<", "&lt;");
        value = value.replace(">", "&gt;");
        value = value.replace("(", "&#40;");
        value = value.replace(")", "&#41;");
        value = value.replace("'", "&#39;");
        value = value.replace("\"", "&quot;");

        return value;
    }

    /**
     * DB에서 불러올 때 다시 원래 텍스트로 디코딩 (표시용)
     */
    public static String restoreXSS(String value) {
        if (value == null) return null;

        // 복원 시엔 역순에 가깝게 처리
        value = value.replace("&lt;", "<");
        value = value.replace("&gt;", ">");
        value = value.replace("&quot;", "\"");
        value = value.replace("&#39;", "'");
        value = value.replace("&#40;", "(");
        value = value.replace("&#41;", ")");
        value = value.replace("&amp;", "&");

        return value;
    }
}
