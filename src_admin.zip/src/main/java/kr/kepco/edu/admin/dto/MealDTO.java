package kr.kepco.edu.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "교육행정 주간 식단표 DTO")
public class MealDTO {
    @Schema(description = "행번호(서버 계산, 응답 전용)", example = "1")
    private int rnum;

    @Schema(description = "주간식단 일련번호 (PK)", example = "WEEK20250101")
    private String wklyMealplSerno;

    @Schema(description = "최초등록일시", example = "2025-01-01 09:00:00")
    private String frstRegDt;

    @Schema(description = "최초등록자사번", example = "EMP001")
    private String frstRegrEmpno;

    @Schema(description = "최종변경일시", example = "2025-01-03 13:30:00")
    private String lstChgDt;

    @Schema(description = "최종변경자사번", example = "EMP002")
    private String lstChgrEmpno;

    @Schema(description = "최초등록자이름", example = "EMP00123")
    private String frstRegrEmpnm;

    @Schema(description = "최종등록자 이름", example = "홍길동")
    private String lastRegrEmpnm;

    @Schema(description = "년도", example = "2025")
    private String wklyMealplYy;

    @Schema(description = "주차", example = "02")
    private String wklyMealplWkcnt;

    @Schema(description = "주간 식단 제목", example = "2025년 2주차 주간 식단표")
    private String wklyMealplTitlNm;

    @Schema(description = "사용여부", example = "Y", defaultValue = "Y")
    private String delYn = "N";

    @Schema(description = "파일주소", example = "/files/meal/...")
    private String fileUrl = "Y";

    @Schema(description = "이미지 URL", example = "/images/banner/mob_banner01.png")
    private String mealBannerImgUrl;

    @Schema(description = "이미지 이름", example = "/images/banner/mob_banner01.png")
    private String mealImageFileNm;

}
