package kr.kepco.edu.admin.controller;

import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import kr.kepco.edu.admin.dto.GuideDTO;
import kr.kepco.edu.admin.request.GuideReq;
import kr.kepco.edu.admin.response.ApiListResponse;
import kr.kepco.edu.admin.response.ApiResponse;
import kr.kepco.edu.admin.response.Page;
import kr.kepco.edu.admin.service.CustomUserDetails;
import kr.kepco.edu.admin.service.GuideService;
import kr.kepco.edu.admin.util.CommonUtil;
import kr.kepco.edu.admin.validation.ErrorCode;
import kr.kepco.edu.admin.validation.RequestGroup;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "03.입교안내", description = "입교안내 게시판")
@RestController
@RequestMapping("${base.url}/guide")
public class GuideController {

    @Autowired
    GuideService gideService;

    @Operation(
        summary = "안내리스트",
        description = "안내리스트 조회",
        requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                required = true,
                content = @Content(
                        mediaType = "application/json",
                        schema = @Schema(implementation = GuideReq.class),
                        examples = {
                                @ExampleObject(
                                        name = "요청번호",
                                        value = "{ \"measGuideTpCd\": \"GUIDE00001\"}"
                                ),
                                @ExampleObject(
                                        name = " 전체조회",
                                        value = "{}"
                                )
                        }
                )
        )
    )
    @PostMapping(value = "/getGuideList" , consumes = "application/json", produces = "application/json")
    public ApiResponse<Page<GuideDTO>> getGuideList(@AuthenticationPrincipal CustomUserDetails user, @RequestBody @JsonView(RequestGroup.Search.class) GuideReq req) {

        Page<GuideDTO> page =  new Page<>(req.getCurrentPage(), req.getPageSize(), gideService.selectGuideListCount(req));
        page.setContent(gideService.getGuideList(page,req));

        if (!CommonUtil.isValid(page.getContent()) && page.getContent().isEmpty()) {
            return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }

        return ApiResponse.ok(HttpStatus.OK, page, "OK");
    }

    @PostMapping(value = "/getGuideDetail" , consumes = "application/json", produces = "application/json")
    public ApiResponse<GuideDTO> getGuideDetail(@AuthenticationPrincipal CustomUserDetails user, @RequestBody @JsonView(RequestGroup.Detail.class) GuideReq req) {

        GuideDTO guideDTO =  gideService.getGuideDetail(req);

        if (!CommonUtil.isValid(guideDTO)) {
            return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }

        return ApiResponse.ok(HttpStatus.OK, guideDTO, "OK");
    }

    @PostMapping("/deleteGuideDetail")
    public ApiResponse<String> deleteGuideDetail(@AuthenticationPrincipal CustomUserDetails user, @JsonView(RequestGroup.Detail.class) @RequestBody GuideReq dto) {
        dto.setLstChgrEmpno(user.getUsername());
        if (gideService.deleteGuideDetail(dto)) {
            return ApiResponse.ok(HttpStatus.OK, "정상 삭제되었습니다.", "OK");
        }
        return ApiResponse.fail(ErrorCode.DELETE_INTERNAL);
    }

    @PostMapping("/getGuideMasterList")
    public ApiListResponse<GuideDTO> getGuideMasterList(@AuthenticationPrincipal CustomUserDetails user, @RequestBody GuideReq dto) {
        return ApiListResponse.ok(HttpStatus.OK, gideService.getGuideMasterList(dto), "OK");
    }

    @PostMapping("/getMasterPstnCnt")
    public ApiResponse<Integer> getMasterPstnCnt(@AuthenticationPrincipal CustomUserDetails user, @RequestBody GuideReq dto) {
        return ApiResponse.ok(HttpStatus.OK, gideService.getGuideMasterPstnCnt(dto), "OK");
    }


    @PostMapping("/insertGuideMaster")
    public ApiResponse<String> insertGuideMaster(@AuthenticationPrincipal CustomUserDetails user, @RequestBody GuideReq dto) {
        dto.setFrstRegrEmpno(user.getUsername());

        if (gideService.insertGuideMaster(dto)) {
            return ApiResponse.ok(HttpStatus.OK, "정상 등록되었습니다.", "OK");
        }

        return ApiResponse.fail(ErrorCode.INSERT_INTERNAL);
    }

    @PostMapping("/guideSave")
    public ApiResponse<String> guideSave(@AuthenticationPrincipal CustomUserDetails user, @RequestBody GuideReq dto) {

        dto.setFrstRegrEmpno(user.getUsername());

        if (gideService.insert(dto)) {
            return ApiResponse.ok(HttpStatus.OK, "정상 등록되었습니다.", "OK");
        }

        return ApiResponse.fail(ErrorCode.INSERT_INTERNAL);
    }

    @PostMapping("/guideModify")
    public ApiResponse<String> guideModify(@AuthenticationPrincipal CustomUserDetails user, @RequestBody GuideReq dto) {

        dto.setLstChgrEmpno(user.getUsername());

        if (gideService.modify(dto)) {
            return ApiResponse.ok(HttpStatus.OK, "정상 수정되었습니다.", "OK");
        }

        return ApiResponse.fail(ErrorCode.UPDATE_INTERNAL);
    }

    @PostMapping("/deleteGuideMaster")
    public ApiResponse<String> deleteGuideMaster(@AuthenticationPrincipal CustomUserDetails user, @RequestBody GuideReq dto) {
        dto.setLstChgrEmpno(user.getUsername());
        if (gideService.deleteGuideList(dto)) {
            return ApiResponse.ok(HttpStatus.OK, "정상 삭제되었습니다.", "OK");
        }
        return ApiResponse.fail(ErrorCode.DELETE_INTERNAL);
    }
}
