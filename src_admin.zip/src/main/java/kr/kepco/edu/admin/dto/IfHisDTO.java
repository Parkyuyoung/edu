package kr.kepco.edu.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Schema(name = "IfHisDTO", description = "연계이력 DTO")
public class IfHisDTO {

    @Schema(description = "행번호(서버 계산, 응답 전용)", example = "1")
    private int rnum;

    @Schema(description = "이력ID(순번)", example = "공지사항 제목입니다.")
    private String hstSerno;

    @Schema(description = "등록일시", example = "2025-06-13T13:16:57")
    private LocalDateTime frstRegDt;

    @Schema(description = "최종 변경일시", example = "2025-06-13T13:16:57")
    private LocalDateTime lstChgDt;

    @Schema(description = "등록자 사번", example = "11112223")
    private String frstRegrEmpno;

    @Schema(description = "최종 수정자 사번", example = "11112223")
    private String lstChgrEmpno;

    @Schema(description = "최초등록자이름", example = "EMP00123")
    private String frstRegrEmpnm;

    @Schema(description = "최종등록자 이름", example = "홍길동")
    private String lastRegrEmpnm;

    @Schema(description = "연계코드", example = "EduClient#getMbnPlanDetail")
    private String measConSnrcCd;

    @Schema(description = "연계 상태코드", example = "FAIL_404")
    private String measConStsCd;

    @Schema(description = "대상 서비스 코드/이름", example = "service-edu")
    private String conTgtNm;

    @Schema(description = "호출자 ID/사번", example = "11112223")
    private String aplrEmpno;

    @Schema(description = "연계결과 사유", example = "어떤 이유로 안됩니다.")
    private String conRsltCtt;

    @Schema(description = "메뉴 한글명", example = "교육계획 게시판 상세")
    private String menuNm;
}
