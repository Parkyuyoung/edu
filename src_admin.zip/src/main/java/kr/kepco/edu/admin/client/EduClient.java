package kr.kepco.edu.admin.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@FeignClient(name = "service-edu", path = "/api/edu", fallback = EduClientFallback.class)
public interface EduClient {
    @GetMapping("/courses")
    java.util.List<String> getCourses();
}