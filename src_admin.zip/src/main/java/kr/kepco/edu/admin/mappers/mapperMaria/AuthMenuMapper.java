package kr.kepco.edu.admin.mappers.mapperMaria;

import kr.kepco.edu.admin.dto.AuthMenuDTO;
import kr.kepco.edu.admin.dto.EduAuthDTO;
import kr.kepco.edu.admin.dto.MenuFilterDTO;
import kr.kepco.edu.admin.request.AuthMenuReq;
import kr.kepco.edu.admin.request.EduAuthReq;
import kr.kepco.edu.admin.request.MenuFilterReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface AuthMenuMapper {
    // 상위 메뉴 목록 (권한에 따라 필터)
    List<MenuFilterDTO> selectParentMenuList();

    // 하위 메뉴 목록 (상위 + 권한)
    List<MenuFilterDTO> selectChildMenuList(@Param("param") MenuFilterReq req);

    List<AuthMenuDTO> selectAuthMenuList(@Param("param") AuthMenuReq req);

    // 다건 한번에 변경 1) 해당 권한코드를 이 parentMenuId 하위 모든 메뉴에서 제거
    int clearAuthFromMenus(@Param("param") AuthMenuReq req);

    // 다건 한번에 변경 2) 체크된 메뉴들(menuIds)에 권한코드 추가
    int addAuthToMenus(@Param("param") AuthMenuReq req);

    int addAuthToMenu(@Param("param") AuthMenuReq req);

    int removeAuthFromMenu(@Param("param") AuthMenuReq req);

    int selectMenuExists(@Param("menuId") String menuId);

    int selectMenuIdsExistCount(@Param("menuIds") List<String> menuIds);

    int selectParentMenuExists(@Param("parentMenuId") String parentMenuId);

    List<MenuFilterDTO> selectMenuAuthList();

    List<EduAuthDTO> selectAuthList();

    int insertAuth(EduAuthReq eduAuthReq);
}
