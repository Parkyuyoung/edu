package kr.kepco.edu.admin.request;


import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.media.Schema;
import kr.kepco.edu.admin.validation.RequestGroup;
import lombok.Data;

import java.util.List;

@Data
@Schema(name = "EduUserReq", description = "권한별 사용자 관리 요청 DTO")
public class EduUserReq extends BaseRequest  {
    @Schema(description = "시작일자", example = "2025-10-12")
    @JsonView(RequestGroup.Search.class)
    private String startDate;

    @Schema(description = "종료일자", example = "2025-10-31")
    @JsonView(RequestGroup.Search.class)
    private String endDate;

    @Schema(description = "검색타입", example = "nm/no")
    @JsonView(RequestGroup.Search.class)
    private String srchType;

    @Schema(description = "검색값(사번)", example = "11112223")
    @JsonView(RequestGroup.Search.class)
    private String srchEmpNo;

    @Schema(description = "검색값(사번)", example = "11112223")
    @JsonView(RequestGroup.Search.class)
    private List<String> srchEmpNos;

    @Schema(description = "검색값(이름)", example = "11112223")
    @JsonView(RequestGroup.Search.class)
    private String srchEmpNm;

    @Schema(description = "권한코드", example = "SYS")
    @JsonView(RequestGroup.Search.class)
    private String srchAuthCd;

    @Schema(description = "사용자사번", example = "11111111")
    @JsonView({RequestGroup.Insert.class, RequestGroup.Update.class})
    private String userId;

    @Schema(description = "권한코드", example = "SYS")
    @JsonView({RequestGroup.Insert.class, RequestGroup.Update.class})
    private String edamsAuthCd;

    @Schema(description = "등록자사번", example = "24100171")
    @JsonView(RequestGroup.Insert.class)
    private String frstRegrEmpno;

    @Schema(description = "수정자사번", example = "24100171")
    @JsonView(RequestGroup.Insert.class)
    private String lstChgrEmpno;

    @Schema(description = "소속부서", example = "SW 기획실")
    @JsonView(RequestGroup.Insert.class)
    private String userDeptNm;


}
