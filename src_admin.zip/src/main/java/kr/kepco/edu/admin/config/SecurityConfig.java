package kr.kepco.edu.admin.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import kr.kepco.edu.admin.filter.jwt.JwtTokenFilter;
import kr.kepco.edu.admin.response.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import javax.servlet.http.HttpServletResponse;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.List;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtTokenFilter jwtTokenFilter;
    private final ObjectMapper om; // ✅ 스프링 빈 주입 (new로 만들지 않음)

    private static final String[] SWAGGER_WHITELIST = {
            "/v3/api-docs/**",
            "/swagger-ui/**",
            "/swagger-ui.html"
    };

    private static final String[] PUBLIC_APIS = {
            "/api/admin/auth/**",
            "/files/**/**",
    };

    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
        .cors().and()
        .csrf().disable()

        .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
        .exceptionHandling(ex -> ex
                .authenticationEntryPoint((req, res, authEx) -> {
                    int status = HttpServletResponse.SC_UNAUTHORIZED; // 401
                    ApiResponse<Void> body = ApiResponse.<Void>builder()
                            .success(false)
                            .status(status)
                            .message("인증이 필요합니다. (토큰 없음/무효/만료)")
                            .timestamp(Instant.now().toEpochMilli())
                            .data(null)
                            .build();
                    res.setStatus(status);
                    res.setCharacterEncoding(StandardCharsets.UTF_8.name());
                    res.setContentType(MediaType.APPLICATION_JSON_VALUE + ";charset=UTF-8");
                    om.writeValue(res.getOutputStream(), body);
                })
                .accessDeniedHandler((req, res, accessDeniedEx) -> {
                    int status = HttpServletResponse.SC_FORBIDDEN; // 403
                    ApiResponse<Void> body = ApiResponse.<Void>builder()
                            .success(false)
                            .status(status)
                            .message("접근 권한이 없습니다.")
                            .timestamp(Instant.now().toEpochMilli())
                            .data(null)
                            .build();

                    res.setStatus(status);
                    res.setCharacterEncoding(StandardCharsets.UTF_8.name());
                    res.setContentType(MediaType.APPLICATION_JSON_VALUE + ";charset=UTF-8");
                    om.writeValue(res.getOutputStream(), body);
                })
        )

        // 인가 규칙
        .authorizeHttpRequests(auth -> auth
                // CORS preflight
                .antMatchers(HttpMethod.OPTIONS, "/**").permitAll()

                // 공개
                .antMatchers(SWAGGER_WHITELIST).permitAll()
                .antMatchers(PUBLIC_APIS).permitAll()

                // 권한 레벨별 접근 (JWT의 권한을 "1", "2"로 넣었다고 가정)
                .antMatchers("/api/users/level1/**").hasAuthority("1")
                .antMatchers("/api/users/level2/**").hasAuthority("2")

                // 나머지는 인증 필요
                .anyRequest().authenticated()
        )

        // 폼/베이직 비활성화
        .httpBasic().disable()
        .formLogin().disable()

        // JWT 필터
        .addFilterBefore(jwtTokenFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    // CORS 정책
    @Bean
    CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration cfg = new CorsConfiguration();
        cfg.setAllowedOriginPatterns(List.of("*")); // 필요 시 도메인 고정 권장
        cfg.setAllowedMethods(List.of("GET","POST","PUT","PATCH","DELETE","OPTIONS"));
        cfg.setAllowedHeaders(List.of("Authorization","Content-Type","X-Requested-With"));
        cfg.setExposedHeaders(List.of("Authorization"));
        cfg.setAllowCredentials(false); // 세션/쿠키 안 쓰면 false
        UrlBasedCorsConfigurationSource src = new UrlBasedCorsConfigurationSource();
        src.registerCorsConfiguration("/**", cfg);
        return src;
    }
}
