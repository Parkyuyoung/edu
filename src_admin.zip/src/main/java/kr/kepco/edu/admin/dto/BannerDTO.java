package kr.kepco.edu.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Schema(name = "BannerDTO", description = "배너 관리 DTO")
public class BannerDTO {

    @Schema(description = "순번", example = "1")
    private String rnum;

    @Schema(description = "배너 일련번호", example = "BNR00001")
    private String bnrSerNo;

    @Schema(description = "최초등록일시", example = "2025-10-20T14:30:00")
    private LocalDateTime frstRegDt;

    @Schema(description = "최초등록자사번", example = "EMP00123")
    private String frstRegrEmpno;

    @Schema(description = "최종변경일시", example = "2025-10-20T15:45:00")
    private LocalDateTime lstChgDt;

    @Schema(description = "최종변경자사번", example = "EMP00456")
    private String lstChgrEmpno;

    @Schema(description = "배너 제목명", example = "한전 교육행정 서비스 오픈 안내")
    private String bnrTitlNm;

    @Schema(description = "배너 본문 내용", example = "모바일 교육행정 서비스가 새롭게 오픈되었습니다.")
    private String bnrCtt;

    @Schema(description = "모바일용 배너 이미지 URL", example = "/images/banner/mob_banner01.png")
    private String mobBannerImgUrl;

    @Schema(description = "태블릿용 배너 이미지 URL", example = "/images/banner/tab_banner01.png")
    private String tabBannerImgUrl;

    @Schema(description = "정렬 순서", example = "1")
    private String scrSortSeqo;

    @Schema(description = "게시 여부(Y/N)", example = "Y")
    private String pstnYn;

    @Schema(description = "삭제 여부(Y/N)", example = "N")
    private String delYn;

    @Schema(description = "작성자 이름", example = "홍길동")
    private String frstRegrEmpnm;

    @Schema(description = "모바일용 배너 이미지 URL", example = "/images/banner/mob_banner01.png")
    private String mobImageFileNm;

    @Schema(description = "태블릿용 배너 이미지 URL", example = "/images/banner/tab_banner01.png")
    private String tabImageFileNm;

}
