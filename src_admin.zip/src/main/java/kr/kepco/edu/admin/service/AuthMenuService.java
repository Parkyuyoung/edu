package kr.kepco.edu.admin.service;

import kr.kepco.edu.admin.dto.AuthMenuDTO;
import kr.kepco.edu.admin.dto.EduAuthDTO;
import kr.kepco.edu.admin.dto.MenuFilterDTO;
import kr.kepco.edu.admin.mappers.mapperMaria.AuthMenuMapper;
import kr.kepco.edu.admin.request.AuthMenuReq;
import kr.kepco.edu.admin.request.EduAuthReq;
import kr.kepco.edu.admin.request.MenuFilterReq;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AuthMenuService {
    @Autowired
    AuthMenuMapper authMenuMapper;

    public List<MenuFilterDTO> getParentMenuList() {
        return authMenuMapper.selectParentMenuList();
    }

    public List<MenuFilterDTO> getChildMenuList(MenuFilterReq req) {
        return authMenuMapper.selectChildMenuList(req);
    }

    public List<AuthMenuDTO> getAuthMenuList(AuthMenuReq req) {
        return authMenuMapper.selectAuthMenuList(req);
    }

    @Transactional
    public void saveAuthMenus(AuthMenuReq req) {
        // 1) 먼저 해당 parentMenuId 하위 메뉴에서 이 권한코드를 싹 제거
        authMenuMapper.clearAuthFromMenus(req);

        // 2) 체크된 메뉴들에 다시 권한코드 추가
        if (req.getMenuIds() != null && !req.getMenuIds().isEmpty()) {
            authMenuMapper.addAuthToMenus(req);
        }
    }

    @Transactional
    public void updateSingleMenu(AuthMenuReq req) {

        if ("Y".equalsIgnoreCase(req.getCheckYn())) {
            authMenuMapper.addAuthToMenu(req);     // 체크 → 권한 추가
        } else if ("N".equalsIgnoreCase(req.getCheckYn())) {
            authMenuMapper.removeAuthFromMenu(req); // 체크 해제 → 권한 삭제
        }
    }

    public int validateMenuExists(String menuId) {
        return authMenuMapper.selectMenuExists(menuId);
    }
    public int validateMenuIdsExist(List<String> menuIds) {
        return authMenuMapper.selectMenuIdsExistCount(menuIds);
    }

    public int validateParentMenuExists(String parentMenuId) {
        return authMenuMapper.selectParentMenuExists(parentMenuId);
    }


    public List<MenuFilterDTO> selectMenuAuthList() {
        return authMenuMapper.selectMenuAuthList();
    }

    public List<EduAuthDTO> selectAuthList() {
        return authMenuMapper.selectAuthList();
    }

    public boolean insertAuth(EduAuthReq eduAuthReq) {
        return authMenuMapper.insertAuth(eduAuthReq) > 0;
    }
}
