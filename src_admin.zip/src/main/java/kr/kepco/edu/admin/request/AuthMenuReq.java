package kr.kepco.edu.admin.request;

import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.media.Schema;
import kr.kepco.edu.admin.validation.RequestGroup;
import lombok.Data;

import java.util.List;

@Data
@Schema(name = "AuthMenuReq", description = "권한별 메뉴 관리 요청 DTO")
public class AuthMenuReq {

    public interface Req {
        interface UpdateAll {}
        interface UpdateOne {}
    }

    @Schema(description = "권한 코드", example = "SYS")
    @JsonView({RequestGroup.Search.class, RequestGroup.Update.class , Req.UpdateOne.class})
    private String edamsAuthCd;    // 선택된 권한 코드 (SYS, PLN ...)

    @Schema(description = "상위메뉴ID", example = "ADMIN")
    @JsonView({RequestGroup.Search.class, RequestGroup.Update.class, Req.UpdateOne.class})
    private String parentMenuId; // 선택된 상위 메뉴 (ADMIN, PROF ...)

    @Schema(description = "선택된 메뉴ID 리스트 (다건 리스트 변경)", example = "[\"ADMIN_100\", \"ADMIN_200\", \"ADMIN_700\"]")
    @JsonView(RequestGroup.Update.class)
    private List<String> menuIds;

    @Schema(description = "선택된 메뉴ID ", example = "ADMIN_100")
    @JsonView(Req.UpdateOne.class)
    private String menuId;

    @Schema(description = "체크여부", example = "Y")
    @JsonView(Req.UpdateOne.class)
    private String checkYn;

}