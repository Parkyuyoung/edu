package kr.kepco.edu.admin.request;

import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.media.Schema;
import kr.kepco.edu.admin.validation.RequestGroup;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Schema(name = "IfHisReq", description = "요청 DTO(그룹: Create/Update/Search). viewType으로 응답 형태 지정")
public class IfHisReq extends BaseRequest {

    @Schema(description = "이력ID(순번)", example = "공지사항 제목입니다.")
    private String hstSerno;

    @Schema(description = "등록일시", example = "2025-06-13T13:16:57")
    private LocalDateTime frstRegDt;

    @Schema(description = "최종 변경일시", example = "2025-06-13T13:16:57")
    private LocalDateTime lstChgDt;

    @Schema(description = "등록자 사번", example = "11112223")
    private String frstRegrEmpno;

    @Schema(description = "최종 수정자 사번", example = "11112223")
    private String lstChgrEmpno;

    @Schema(description = "연계코드", example = "EduClient#getMbnPlanDetail")
    private String measConSnrcCd;

    @Schema(description = "연계 상태코드", example = "FAIL_404")
    private String measConStsCd;

    @Schema(description = "대상 서비스 코드/이름", example = "service-edu")
    private String conTgtNm;

    @Schema(description = "호출자 ID/사번", example = "11112223")
    private String aplrEmpno;

    @Schema(description = "연계결과 사유", example = "어떤 이유로 안됩니다.")
    private String conRsltCtt;

    @Schema(description = "메뉴 한글명", example = "교육계획 게시판 상세")
    private String menuNm;

    @Schema(description = "시작일자", example = "2025-10-12")
    @JsonView(RequestGroup.Search.class)
    private String startDate;

    @Schema(description = "종료일자", example = "2025-10-31")
    @JsonView(RequestGroup.Search.class)
    private String endDate;

    @Schema(description = "검색타입", example = "nm/no")
    @JsonView(RequestGroup.Search.class)
    private String srchType;

    @Schema(description = "검색어", example = "nm/no")
    @JsonView(RequestGroup.Search.class)
    private String searchValue;
}
