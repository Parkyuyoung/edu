package kr.kepco.edu.admin.service;

import kr.kepco.edu.admin.dto.NoticeDTO;
import kr.kepco.edu.admin.mappers.mapperMaria.NoticeMapper;
import kr.kepco.edu.admin.request.NoticeReq;
import kr.kepco.edu.admin.response.Page;
import kr.kepco.edu.admin.util.EmpNameUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class NoticeService {
    @Autowired
    NoticeMapper noticeMapper;

    @Autowired
    EmpNameUtil empNameUtil;

    public int selectNoticeListCnt(NoticeReq param) {
        return noticeMapper.selectNoticeListCnt(param);
    }

    public List<NoticeDTO> selectNoticeList(NoticeReq param, Page<NoticeDTO> page) {
        List<NoticeDTO> list = noticeMapper.selectNoticeList(param, page);
        empNameUtil.enrichName(
                list,
                NoticeDTO::getFrstRegrEmpno,
                NoticeDTO::setFrstRegrEmpnm,
                " "
        );
        return list;
    }

    public NoticeDTO selectNoticeDetail(NoticeReq param) {
        NoticeDTO noticeDTO = noticeMapper.selectNoticeDetail(param);
        empNameUtil.enrichOne(
                noticeDTO,
                NoticeDTO::getFrstRegrEmpno,
                NoticeDTO::setFrstRegrEmpnm,
                " "
        );
        return noticeDTO;

    }

    public int getNoticePinnedCnt() {
        return noticeMapper.selectNoticePinnedCnt();
    }
    @Transactional
    public boolean insert(NoticeReq req) {
        int i = noticeMapper.insertNotice(req);
        if (req.getUpndFixYn().equals("Y")) {
            noticeMapper.updateSortOrder(req);
        }
        return i > 0;
    }
    @Transactional
    public boolean delete(NoticeReq req) {
        if (noticeMapper.deleteNotice(req) > 0) {
            noticeMapper.updateOrderSetting(req);
            return true;
        }
        return false;
    }

    @Transactional
    public boolean update(NoticeReq req) {
        int i = noticeMapper.updateNotice(req);

        if (req.getUpndFixYn().equals("Y")) {
            noticeMapper.updateSortOrder(req);
        }
        return  i > 0;
    }
}
