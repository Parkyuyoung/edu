package kr.kepco.edu.admin.controller;


import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import kr.kepco.edu.admin.dto.AccessLogDTO;
import kr.kepco.edu.admin.dto.SelectOptionDTO;
import kr.kepco.edu.admin.request.AccessLogReq;
import kr.kepco.edu.admin.request.AccessLogStatReq;
import kr.kepco.edu.admin.response.ApiListResponse;
import kr.kepco.edu.admin.response.ApiResponse;
import kr.kepco.edu.admin.response.Page;
import kr.kepco.edu.admin.service.AccessLogService;
import kr.kepco.edu.admin.service.CustomUserDetails;
import kr.kepco.edu.admin.service.JojicService;
import kr.kepco.edu.admin.util.CommonUtil;
import kr.kepco.edu.admin.validation.ErrorCode;
import kr.kepco.edu.admin.validation.RequestGroup;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Tag(name = "06. 시스템 접속 이력", description = "시스템 접속 이력 관리 ")
@RestController
@Slf4j
@RequestMapping("${base.url}/accessLog")
public class AccessLogController {
    @Autowired
    AccessLogService accessLogService;

    @Autowired
    JojicService jojicService;

    @Operation(
            summary = "시스템 접속 이력 조회",
            description = "시스템 접속 이력 조회",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            schema = @Schema(implementation = AccessLogReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "사번 검색",
                                            value = "{\n" +
                                                    "  \"currentPage\": 1,\n" +
                                                    "  \"pageSize\": 10,\n" +
                                                    "  \"srchType\": \"no\",\n" +
                                                    "  \"srchEmpNo\": \"11112223\",\n" +
                                                    "  \"startDate\": \"2025-01-01\",\n" +
                                                    "  \"endDate\": \"2025-01-31\",\n" +
                                                    "  \"menuNm\": \"접속이력\"\n" +
                                                    "}"
                                    ),
                                    @ExampleObject(
                                            name = "이름 검색",
                                            value = "{\n" +
                                                    "  \"currentPage\": 1,\n" +
                                                    "  \"pageSize\": 10,\n" +
                                                    "  \"srchType\": \"nm\",\n" +
                                                    "  \"srchEmpNm\": [\"홍길동\", \"김철수\"],\n" +
                                                    "  \"startDate\": \"2025-01-01\",\n" +
                                                    "  \"endDate\": \"2025-01-31\",\n" +
                                                    "  \"menuNm\": \"접속이력\"\n" +
                                                    "}"
                                    ),
                                    @ExampleObject(
                                            name = "날짜 + 메뉴명 검색",
                                            value = "{\n" +
                                                    "  \"currentPage\": 1,\n" +
                                                    "  \"pageSize\": 20,\n" +
                                                    "  \"srchType\": \"no\",\n" +
                                                    "  \"srchEmpNo\": \"\",\n" +
                                                    "  \"startDate\": \"2025-03-01\",\n" +
                                                    "  \"endDate\": \"2025-03-31\",\n" +
                                                    "  \"menuNm\": \"교육관리\"\n" +
                                                    "}"
                                    )
                            }
                    )
            )
    )
    @PostMapping(value = "/list")
    public ApiResponse<Page<AccessLogDTO>> getAccessLogList (@AuthenticationPrincipal CustomUserDetails user, @RequestBody @JsonView(RequestGroup.Search.class) AccessLogReq accessLogReq) {

        if (CommonUtil.isValid(accessLogReq.getSrchEmpNm()) && accessLogReq.getSrchType().equals("nm") ){
            List<String> empNos = jojicService.getSeachEmpList(accessLogReq.getSrchEmpNm());
            if(!CommonUtil.isValid(empNos)) return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
            accessLogReq.setSrchEmpNos(empNos);
        }
        Page<AccessLogDTO> page = new Page<>(accessLogReq.getCurrentPage(),accessLogReq.getPageSize(), accessLogService.getAccessLogListCnt(accessLogReq));

        List<AccessLogDTO> accessLogDTOS = accessLogService.getAccessLogList(accessLogReq,page);

        page.setContent(accessLogDTOS);

        if(CommonUtil.isValid(page.getContent())) {
            return ApiResponse.ok(HttpStatus.OK,page,"OK.");
        } else {
            return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }
    }

    @Operation(
            summary = "시스템 접속 이력 조회",
            description = "시스템 접속 이력 조회",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            schema = @Schema(implementation = AccessLogReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "사번 검색",
                                            value = "{\n" +
                                                    "  \"currentPage\": 1,\n" +
                                                    "  \"pageSize\": 10,\n" +
                                                    "  \"srchType\": \"no\",\n" +
                                                    "  \"srchEmpNo\": \"11112223\",\n" +
                                                    "  \"startDate\": \"2025-01-01\",\n" +
                                                    "  \"endDate\": \"2025-01-31\",\n" +
                                                    "  \"menuNm\": \"접속이력\"\n" +
                                                    "}"
                                    ),
                                    @ExampleObject(
                                            name = "이름 검색",
                                            value = "{\n" +
                                                    "  \"currentPage\": 1,\n" +
                                                    "  \"pageSize\": 10,\n" +
                                                    "  \"srchType\": \"nm\",\n" +
                                                    "  \"srchEmpNm\": [\"홍길동\", \"김철수\"],\n" +
                                                    "  \"startDate\": \"2025-01-01\",\n" +
                                                    "  \"endDate\": \"2025-01-31\",\n" +
                                                    "  \"menuNm\": \"접속이력\"\n" +
                                                    "}"
                                    ),
                                    @ExampleObject(
                                            name = "날짜 + 메뉴명 검색",
                                            value = "{\n" +
                                                    "  \"currentPage\": 1,\n" +
                                                    "  \"pageSize\": 20,\n" +
                                                    "  \"srchType\": \"no\",\n" +
                                                    "  \"srchEmpNo\": \"\",\n" +
                                                    "  \"startDate\": \"2025-03-01\",\n" +
                                                    "  \"endDate\": \"2025-03-31\",\n" +
                                                    "  \"menuNm\": \"교육관리\"\n" +
                                                    "}"
                                    )
                            }
                    )
            )
    )
    @PostMapping(value = "/getMenuList")
    public ApiListResponse<SelectOptionDTO> getMenuList (@AuthenticationPrincipal CustomUserDetails user) {

        List<SelectOptionDTO> menuList = accessLogService.selectMenuList();

        if(CommonUtil.isValid(menuList)) {
            return ApiListResponse.ok(HttpStatus.OK,menuList,"OK");
        } else {
            return ApiListResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }
    }
    @Operation(
            summary = "모바일 교육행정 메뉴별 접속 통계 조회",
            description = "기간(기간타입/시작일/종료일) 및 메뉴ID로 모바일 교육행정 메뉴별 접속 통계를 조회한다.",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            schema = @Schema(implementation = AccessLogStatReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "기간타입 조회(최근 1개월)",
                                            value = "{\n" +
                                                    "  \"periodType\": \"1month\"\n" +
                                                    "}"
                                    ),
                                    @ExampleObject(
                                            name = "날짜 범위 조회",
                                            value = "{\n" +
                                                    "  \"periodType\": \"1month\",\n" +
                                                    "}"
                                    ),
                                    @ExampleObject(
                                            name = "날짜 + 특정 메뉴ID 조회",
                                            value = "{\n" +
                                                    "  \"startDate\": \"2025-03-01\",\n" +
                                                    "  \"endDate\": \"2025-03-31\",\n" +
                                                    "  \"menuId\": \"MAIN\"\n" +
                                                    "}"
                                    )
                            }
                    )
            )
    )
    @PostMapping(value = "/getAccessLogStatByMenus")
    public ApiListResponse<Map<String, Object>> getAccessLogStatByMenus(
            @AuthenticationPrincipal CustomUserDetails user,
            @RequestBody @JsonView(RequestGroup.Search.class) AccessLogStatReq req
    ) {
        if (CommonUtil.isValid(req.getPeriodType())) { //periodType 값이 있으면 startDate, endDate null 로 세팅
            req.setStartDate(null);
            req.setEndDate(null);
        }

        // Service가 Map을 받도록 되어있다면 req -> Map 변환
        Map<String, Object> param = new HashMap<>();
        param.put("periodType", req.getPeriodType());
        param.put("startDate", req.getStartDate());
        param.put("endDate", req.getEndDate());
        param.put("menuId", req.getMenuId());

        List<Map<String, Object>> list = accessLogService.selectAccessLogStatByMenus(param);

        if (CommonUtil.isValid(list)) {
            return ApiListResponse.ok(HttpStatus.OK, list, "OK");
        } else {
            return ApiListResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }
    }


}
