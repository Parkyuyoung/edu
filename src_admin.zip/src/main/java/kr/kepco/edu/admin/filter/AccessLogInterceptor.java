package kr.kepco.edu.admin.filter;

import kr.kepco.edu.admin.config.MenuCache;
import kr.kepco.edu.admin.service.AccessLogService;
import kr.kepco.edu.admin.service.CustomUserDetails;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
@RequiredArgsConstructor
@Slf4j
public class AccessLogInterceptor implements HandlerInterceptor {

    private final MenuCache menuCache;              // 캐시: 요청URL -> MENU_ID
    private final AccessLogService accessLogService; // 비동기 INSERT (MyBatis)

    @Override
    public void afterCompletion(HttpServletRequest req, HttpServletResponse res, Object handler, Exception ex) {
        final String path = req.getRequestURI();

        if (isExcluded(path)) return;                 // 예외 URL은 스킵
        
        final String mngrId = resolveUserId();        // 토큰(인증) 필수

        System.out.println("path >>>>>>>>>>  " + path);

        if (mngrId == null || mngrId.isBlank() || "anonymousUser".equalsIgnoreCase(mngrId)) return;


        final String menuId = menuCache.resolveMenuId(path); // 메뉴 매핑 필수

        System.out.println("menuId >>>>>>>>>>  " + menuId);
        if (menuId == null) return;

        accessLogService.accessLog(mngrId,menuId);    // 비동기 DB INSERT
    }

    private boolean isExcluded(String path) {
        return path.equals("/api/user/auth/login") ||path.startsWith("/error")
                || path.startsWith("/swagger-ui") || path.startsWith("/v3/api-docs")
                || path.startsWith("/favicon") || path.startsWith("/css")
                || path.startsWith("/js") || path.startsWith("/images");
    }

    private String resolveUserId() {
        // SecurityContext가 비어있으면 null
        var context = SecurityContextHolder.getContext();
        if (context == null) return null;

        var auth = context.getAuthentication();
        if (auth == null || !auth.isAuthenticated()) return null;

        // 익명 사용자(비로그인) 처리
        Object principal = auth.getPrincipal();
        if (principal == null || "anonymousUser".equalsIgnoreCase(principal.toString())) {
            return null;
        }

        // 1️⃣ CustomUserDetails 타입이면 사번(empNo) 꺼내기
        if (principal instanceof CustomUserDetails) {
            CustomUserDetails user = (CustomUserDetails) principal;
            if (user.getUser() != null && user.getUser().getUserId() != null) {
                return user.getUser().getUserId(); // 사번 반환
            }
            // 혹시 내부 필드명이 다르면 user.getUsername() 으로 대체
            return user.getUsername();
        }

        // 2️⃣ JWT 기반일 경우 (Authentication.getName() 이 서브젝트)
        return auth.getName();
    }

}
