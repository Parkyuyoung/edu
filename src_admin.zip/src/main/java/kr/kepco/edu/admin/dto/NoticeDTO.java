package kr.kepco.edu.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Schema(name = "NoticeDto", description = "공지사항 DTO")
public class NoticeDTO {

    @Schema(description = "행번호(서버 계산, 응답 전용)", example = "1")
    private int rnum;

    @Schema(description = "게시글 번호(PK)", example = "12345")
    private String ntiMttrSerno;

    @Schema(description = "제목", example = "공지사항 제목입니다.")
    private String ntiMttrTitlNm;

    @Schema(description = "상세내용", example = "공지사항 상세내용입니다.")
    private String ntiMttrCtt;

    @Schema(description = "등록자 사번", example = "11112223")
    private String frstRegrEmpno;

    @Schema(description = "최종 수정자 사번", example = "11112223")
    private String lstChgrEmpno;

    @Schema(description = "등록일시", example = "2025-06-13T13:16:57")
    private LocalDateTime frstRegDt;

    @Schema(description = "최종 변경일시", example = "2025-06-13T13:16:57")
    private LocalDateTime lstChgDt;

    @Schema(description = "상단고정 여부", example = "N")
    private String upndFixYn;

    @Schema(description = "상단고정 정렬", example = "null")
    private String upndFixSeqno;

    @Schema(description = "사용여부", example = "Y")
    private String delYn;

    @Schema(description = "작성자 이름", example = "홍길동")
    private String frstRegrEmpnm;
}
