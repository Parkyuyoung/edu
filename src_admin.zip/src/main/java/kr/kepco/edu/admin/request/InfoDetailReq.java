package kr.kepco.edu.admin.request;

import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.media.Schema;
import kr.kepco.edu.admin.validation.RequestGroup;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Schema(name = "InfoDetailReq", description = "요청 DTO(그룹: Create/Update/Search). viewType으로 응답 형태 지정")
public class InfoDetailReq extends BaseRequest {
    @Schema(description = "안내 정보 detail 일련번호", example = "1")
    @JsonView(RequestGroup.Search.class)
    private String dtlsInfoSerno;

    @Schema(description = "최초등록자사번", example = "EMP00123")
    private String frstRegrEmpno;

    @Schema(description = "최종변경자사번", example = "EMP00456")
    private String lstChgrEmpno;

    @Schema(description = "정보 마스터 일련번호", example = "1")
    @JsonView(RequestGroup.Search.class)
    private String infoSerno;

    @Schema(description = "제목", example = "1층")
    private String dtlsInfoTitlNm;

    @Schema(description = "상세", example = "어디에 있습니다.")
    private String dtlsInfoCtt;

    @Schema(description = "정렬순서", example = "1")
    private String scrSortSeqo;

    @Schema(description = "마스터 종류", example = "1")
    private String measInfoClCd;

    @Schema(description = "삭제여부(Y/N)", example = "Y")
    private String DelYn;

    @Schema(description = "검색어", example = "nm/no")
    @JsonView(RequestGroup.Search.class)
    private String searchValue;

}
