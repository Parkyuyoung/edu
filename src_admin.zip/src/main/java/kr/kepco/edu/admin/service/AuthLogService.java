package kr.kepco.edu.admin.service;

import kr.kepco.edu.admin.dto.AuthLogDTO;
import kr.kepco.edu.admin.mappers.mapperMaria.AuthLogMapper;
import kr.kepco.edu.admin.request.AuthLogReq;
import kr.kepco.edu.admin.response.Page;
import kr.kepco.edu.admin.util.EmpNameUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuthLogService {
    @Autowired
    AuthLogMapper authLogMapper;

    @Autowired
    EmpNameUtil empNameUtil;

    public List<AuthLogDTO> getAuthLogList (AuthLogReq authLogReq, Page<AuthLogDTO> page) {
        List<AuthLogDTO> list = authLogMapper.selectAuthLogList(authLogReq,page);

        empNameUtil.enrichUserInfo2(
                list,
                AuthLogDTO::getUserId,
                AuthLogDTO::setUserNm,
                AuthLogDTO::setUserDeptNm,
                AuthLogDTO::setUserLevelNm,
                AuthLogDTO::setUserTitle
        );

        empNameUtil.enrichName(
                list,
                AuthLogDTO::getLstChgrEmpno,
                AuthLogDTO::setLstChgrEmpnm
        );
        return list;
    }

    public int getAuthogListCnt (AuthLogReq authLogReq) {
        return authLogMapper.selectAuthLogListCnt(authLogReq);
    }
}
