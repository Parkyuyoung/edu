package kr.kepco.edu.admin.controller;

import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import kr.kepco.edu.admin.validation.ErrorCode;
import kr.kepco.edu.admin.validation.RequestGroup;
import kr.kepco.edu.admin.dto.TempCardDTO;
import kr.kepco.edu.admin.request.TempCardReq;
import kr.kepco.edu.admin.response.ApiResponse;
import kr.kepco.edu.admin.response.Page;
import kr.kepco.edu.admin.service.CustomUserDetails;
import kr.kepco.edu.admin.service.TempCardService;
import kr.kepco.edu.admin.util.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@Tag(name = "04.임시사원증", description = "임시사원증 관련 처리")
@RestController
@RequestMapping("${base.url}/tempCard")
public class TempCardController {

    @Autowired
    TempCardService tempCardService;

    @Operation(
            summary = "임시사원증 목록",
            description = "임시사원증 목록 조회",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = TempCardReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "전체 검색",
                                            value = "{ \"currentPage\": \"1\" , \"pageSize\": \"10\" }"
                                    ),
                                    @ExampleObject(
                                            name = "대상자 이름 검색",
                                            value = "{ \"targetNm\": \"홍길동\" , \"currentPage\": \"1\" , \"pageSize\": \"10\" }"
                                    ),
                                    @ExampleObject(
                                            name = "결재상태 별 검색",
                                            value = "{ \"apprvSttsCd\": \"2\" ,  \"currentPage\": \"1\" , \"pageSize\": \"10\" }"
                                    ),
                                    @ExampleObject(
                                            name = "교육과정(교육일련번호) 별 검색",
                                            value = "{ \"eduSerno\": \"111111\" ,  \"currentPage\": \"1\" , \"pageSize\": \"10\" }"
                                    ),
                                    @ExampleObject(
                                            name = "교육과정(교육이름) 별 검색",
                                            value = "{ \"eduNm\": \"실전 SQL 입문\" ,  \"currentPage\": \"1\" , \"pageSize\": \"10\" }"
                                    )
                            }
                    )
            )
    )
    @PostMapping(value = "/getTempCardList" , consumes = "application/json", produces = "application/json")
    public ApiResponse<Page<TempCardDTO>> getTempCardList(@AuthenticationPrincipal CustomUserDetails user, @RequestBody @JsonView(RequestGroup.Search.class) TempCardReq req) {

        Page<TempCardDTO> page = new Page<>(req.getCurrentPage(),req.getPageSize(), tempCardService.selectTempCardListCnt(req));
        page.setContent(tempCardService.selectTempCardList(req,page));

        if (CommonUtil.isValid(page.getContent())) {
            return ApiResponse.ok(HttpStatus.OK, page, "OK");
        } else {
            return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }
    }

    @Operation(
            summary = "임시사원증 상세 조회",
            description = "임시사원증 상세 조회",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = TempCardReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "임시사원증 상세 조회",
                                            value = "{ \"tempCardApplySerno\": \"1\" }"
                                    ),
                            }
                    )
            )
    )
    @PostMapping(value = "/getTempCardDetail" , consumes = "application/json", produces = "application/json")
    public ApiResponse<TempCardDTO> getTempCardDetail(@AuthenticationPrincipal CustomUserDetails user, @RequestBody @JsonView(RequestGroup.Detail.class) TempCardReq req) {

        if(!CommonUtil.isValid(req.getTmpEidAplSerno())) {
            return ApiResponse.fail(ErrorCode.REQ_MISSING_PARAM);
        }

        TempCardDTO tempCardDTO = tempCardService.selectTempCardDetail(req);

        if(CommonUtil.isValid(tempCardDTO)){
            return ApiResponse.ok(HttpStatus.OK, tempCardDTO, "OK");
        } else {
            return ApiResponse.fail(ErrorCode.VAL_VALUE_EMPTY);
        }
    }
}
