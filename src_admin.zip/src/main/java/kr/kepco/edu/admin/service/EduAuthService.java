package kr.kepco.edu.admin.service;

import kr.kepco.edu.admin.dto.EduAuthDTO;
import kr.kepco.edu.admin.mappers.mapperMaria.EduAuthMapper;
import kr.kepco.edu.admin.request.EduAuthReq;
import kr.kepco.edu.admin.response.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class EduAuthService {

    @Autowired
    EduAuthMapper eduAuthMapper;

    public int getEduAuthListCnt(EduAuthReq eduAuthReq) {
        return eduAuthMapper.selectEduAuthListCnt(eduAuthReq);
    }

    public List<EduAuthDTO> getEduAuthList(EduAuthReq eduAuthReq, Page<EduAuthDTO> page) {
        return eduAuthMapper.selectEduAuthList(eduAuthReq, page);
    }

    public boolean isDupAuthCode(EduAuthReq req) {
        return eduAuthMapper.selectEduAuthCdDupCnt(req) > 0;
    }

    public boolean isDupAuthName(EduAuthReq req) {
        return eduAuthMapper.selectEduAuthNmDupCnt(req) > 0;
    }

    /**
     * 권한 등록
     */
    @Transactional
    public int insertEduAuth(EduAuthReq eduAuthReq) {
        return eduAuthMapper.insertEduAuth(eduAuthReq);
    }

    /**
     * 권한 수정
     */
    @Transactional
    public int updateEduAuth(EduAuthReq eduAuthReq) {
        return eduAuthMapper.updateEduAuth(eduAuthReq);
    }

    /**
     * 권한 삭제 (EDU_AUTH, EDU_USER 둘 다 DEL_YN = 'Y')
     */
    @Transactional
    public int deleteEduAuth(EduAuthReq eduAuthReq) {
        // 권한 사용자들 먼저 논리삭제
        eduAuthMapper.deleteEduAuthUsers(eduAuthReq);
        // 권한 논리삭제
        return eduAuthMapper.deleteEduAuth(eduAuthReq);
    }

    public List<EduAuthDTO> getAuthFilter() {
        return eduAuthMapper.selectAuthFilter();
    }
}
