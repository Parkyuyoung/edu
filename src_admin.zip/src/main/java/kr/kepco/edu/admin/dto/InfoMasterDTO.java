package kr.kepco.edu.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Schema(name = "InfoMasterDTO", description = "정보 그룹 DTO")
public class InfoMasterDTO {
    @Schema(description = "안내 정보 일련번호", example = "1")
    private String infoSerno;

    @Schema(description = "최초등록일시", example = "2025-10-20T14:30:00")
    private LocalDateTime frstRegDt;

    @Schema(description = "최초등록자사번", example = "EMP00123")
    private String frstRegrEmpno;

    @Schema(description = "최종변경일시", example = "2025-10-20T15:45:00")
    private LocalDateTime lstChgDt;

    @Schema(description = "최종변경자사번", example = "EMP00456")
    private String lstChgrEmpno;

    @Schema(description = "정보구분", example = "FACILITY")
    private String measInfoClCd;

    @Schema(description = "그룹명", example = "건물배치도")
    private String grpTitlNm;

    @Schema(description = "정렬순서", example = "1")
    private String scrSortSeqo;
}
