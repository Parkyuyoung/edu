package kr.kepco.edu.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Schema(name = "AccessLogDTO", description = "접근 로그 DTO (시스템연계이력 + 통계)")
public class AccessLogDTO {
    @Schema(description = "순번", example = "1")
    private String rnum;

    @Schema(description = "로그 일련번호", example = "BNR00001")
    private String logSerno;

    @Schema(description = "최초등록일시", example = "2025-10-20T14:30:00")
    private LocalDateTime frstRegDt;

    @Schema(description = "최초등록자사번", example = "EMP00123")
    private String frstRegrEmpno;

    @Schema(description = "최종변경일시", example = "2025-10-20T15:45:00")
    private LocalDateTime lstChgDt;

    @Schema(description = "최종변경자사번", example = "EMP00456")
    private String lstChgrEmpno;

    @Schema(description = "메뉴ID", example = "EHRD201")
    private String menuId;

    @Schema(description = "메뉴명", example = "시스템이력관리")
    private String menuNm;

    @Schema(description = "이름", example = "홍길동")
    private String userNm;

    @Schema(description = "직급", example = "3직급")
    private String userLevelNm;

    @Schema(description = "부서명", example = "ICT운영처")
    private String userDeptNm;

    @Schema(description = "직급타이틀", example = "모바일담당")
    private String userTitle;
}
