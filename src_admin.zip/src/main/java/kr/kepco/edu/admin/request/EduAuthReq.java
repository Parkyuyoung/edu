package kr.kepco.edu.admin.request;

import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.media.Schema;
import kr.kepco.edu.admin.validation.RequestGroup;
import lombok.Data;

@Data
@Schema(name = "EduAuthReq", description = "권한 관리 요청 DTO")
public class EduAuthReq extends BaseRequest {
    @Schema(description = "권한코드", example = "SYS")
    @JsonView(RequestGroup.Search.class)
    private String srchEdamsAuthCd;

    @Schema(description = "권한명", example = "사용자(교수)")
    @JsonView(RequestGroup.Search.class)
    private String srchAuthNm;

    @Schema(description = "권한코드", example = "SYS")
    @JsonView({RequestGroup.Insert.class, RequestGroup.Update.class})
    private String edamsAuthCd;

    @Schema(description = "등록자사번", example = "24100171")
    @JsonView(RequestGroup.Insert.class)
    private String frstRegrEmpno;

    @Schema(description = "수정자사번", example = "24100171")
    @JsonView(RequestGroup.Insert.class)
    private String lstChgrEmpno;

    @Schema(description = "권한명", example = "사용자(교수)")
    @JsonView({RequestGroup.Insert.class, RequestGroup.Update.class})
    private String eduAuthNm;

}
