package kr.kepco.edu.admin.request;

import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.media.Schema;
import kr.kepco.edu.admin.validation.RequestGroup;
import lombok.Data;

@Data
@Schema(name = "MenuFilterReq", description = "메뉴 필터 요청 DTO")
public class MenuFilterReq  extends BaseRequest{

        @Schema(description = "상위메뉴ID", example = "ADMIN")
        @JsonView(RequestGroup.Search.class)
        private String parentMenuId;

}
