package kr.kepco.edu.admin.config.db;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;

@Configuration
@MapperScan(basePackages = {"kr.kepco.edu.admin.mappers.mapperMaria"},sqlSessionTemplateRef = "mariaSessionTemplate")
public class MariaDataSourceConfig {

    @Bean(name="mariaDataSource")
    @ConfigurationProperties(prefix="spring.datasource.maria")
    @Primary
    public DataSource dbDataSource() {
    	return DataSourceBuilder.create().build();
	}

    @Bean(name="mariaSessionFactory")
    @Primary
    public SqlSessionFactory xwSqlSessionFactory(@Qualifier("mariaDataSource") DataSource dataSource) throws Exception {
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();

        bean.setDataSource(dataSource);

        bean.setConfigLocation(new DefaultResourceLoader().getResource("classpath:mybatis-config.xml"));

        bean.setMapperLocations(new PathMatchingResourcePatternResolver().getResources("classpath:mappers/mappersMaria/**/*.xml"));

        return bean.getObject();
    }

    @Bean(name = "mariaTransactionManager")
    @Primary
    public DataSourceTransactionManager xwTransactionManager(@Qualifier("mariaDataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }

    @Bean(name = "mariaSessionTemplate")
    @Primary
    public SqlSessionTemplate xwSqlSessionTemplate(@Qualifier("mariaSessionFactory") SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }

}