package kr.kepco.edu.admin.filter.jwt;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import kr.kepco.edu.admin.dto.UserDTO;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class JwtTokenProvider {

    @Value("${jwt.secret}")
    private String secretKey;   // 32바이트 이상 권장
    @Value("${jwt.access-token-validity-ms}")
    private long validityInMilliseconds;     // 만료(분)
    private final ObjectMapper objectMapper = new ObjectMapper();

    // JWT 생성 메서드
    public String createToken(UserDTO user) {
        Claims claims = Jwts.claims().setSubject(user.getUserId());

        claims.put("roles", user.getRoles().stream().collect(Collectors.toList()));
        claims.put("menuIds", user.getMenuIds());
        System.out.println(">>> " + user.getRoles().stream().collect(Collectors.toList()));
        try {
            claims.put("user", objectMapper.writeValueAsString(user));
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Failed to serialize user DTO", e);
        }

        Date now = new Date();
        Date validity = new Date(now.getTime() + validityInMilliseconds);

        return Jwts.builder()
                .setClaims(claims)
                .setIssuedAt(now)
                .setExpiration(validity)
                .signWith(SignatureAlgorithm.HS256, secretKey)
                .compact();
    }

    // JWT에서 사용자 이름 추출
    public String getUsername(String token) {
        return Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token).getBody().getSubject();
    }

    // JWT에서 역할 정보 추출
    public Set<String> getRoles(String token) {
        Claims claims = Jwts.parser()
                .setSigningKey(secretKey)
                .parseClaimsJws(token)
                .getBody();

        // 클레임에서 roles 정보를 추출하고 Set으로 변환
        List<String> roles = claims.get("roles", List.class);
        return roles.stream().collect(Collectors.toSet());
    }

    public UserDTO getUserDto(String token) {
        Claims claims = Jwts.parser()
                .setSigningKey(secretKey)
                .parseClaimsJws(token)
                .getBody();

        // "user" 클레임에서 JSON 문자열을 가져와 UserDto로 변환
        String userJson = claims.get("user", String.class);

        try {
            return objectMapper.readValue(userJson, UserDTO.class);
        } catch (IOException e) {
            throw new RuntimeException("Failed to deserialize user DTO", e);
        }
    }

    // JWT 유효성 검사
    public boolean validateToken(String token) {
        try {
            Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public String getJti(String token) {
        return parse(token).getBody().getId();
    }

    public Jws<Claims> parse(String token) {
        return Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token);
    }

    public boolean isExpired(String token) {
        try { return parse(token).getBody().getExpiration().before(new Date()); }
        catch (Exception e) { return true; }
    }
}