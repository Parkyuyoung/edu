package kr.kepco.edu.admin.config;

import kr.kepco.edu.admin.dto.MenuDTO;
import kr.kepco.edu.admin.mappers.mapperMaria.MenuMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

@Component
@EnableScheduling
public class MenuCache {

    @Autowired
    MenuMapper menuMapper;

    private final AtomicReference<List<MenuDTO>> cached = new AtomicReference<>(Collections.emptyList());

    @PostConstruct
    public void init() {
        refresh();
    }

    @Scheduled(fixedDelay = 300_000L)
    public void refresh() {
        List<MenuDTO> list = menuMapper.selectAllActiveMenus();
        if (list == null) list = Collections.emptyList();

        final List<MenuDTO> sorted = list.stream()
                .filter(m -> m != null && m.getMenuPath() != null && !m.getMenuPath().trim().isEmpty())
                .map(m -> new MenuDTO(m.getMenuId(), normalize(m.getMenuPath())))
                .sorted((a, b) -> Integer.compare(b.getMenuPath().length(), a.getMenuPath().length()))
                .collect(Collectors.toList());

        cached.set(sorted); // 원자적 스왑
    }

    public String resolveMenuId(String requestPath) {
        requestPath = requestPath.replaceFirst("^/api/admin/", "/");
        final String path = normalize(requestPath);

        final List<MenuDTO> list = cached.get();

        // 정확 일치
        for (MenuDTO e : list) {
            if (path.equals(e.getMenuPath())) {
                return e.getMenuId();
            }
        }
        // 최장 접두사 매칭
        for (MenuDTO e : list) {
            if (path.startsWith(e.getMenuPath())) {
                return e.getMenuId();
            }
        }
        return null;
    }

    private String normalize(String p) {
        if (p == null) return "/";
        String x = p.trim();
        if (!x.startsWith("/")) x = "/" + x;
        if (x.length() > 1 && x.endsWith("/")) x = x.substring(0, x.length() - 1);
        return x;
    }
}
