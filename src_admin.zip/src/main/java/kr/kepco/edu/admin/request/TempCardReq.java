package kr.kepco.edu.admin.request;

import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.media.Schema;
import kr.kepco.edu.admin.validation.RequestGroup;
import lombok.*;

import javax.validation.constraints.Size;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Schema(name = "TempCardReq", description = "요청 DTO(그룹: Create/Update/Search). viewType으로 응답 형태 지정")
public class TempCardReq extends BaseRequest {
    @Schema(description = "행번호(서버 계산, 응답 전용)", example = "1")
    private int rnum;

    @Size(max=20)
    @JsonView({ RequestGroup.Search.class, RequestGroup.Detail.class, RequestGroup.Update.class })
    @Schema(description = "임시사원증 신청 일련번호(PK)", example = "12345")
    private String tmpEidAplSerno;

    @Schema(description = "등록자 사번", example = "11112223")
    private String frstRegrEmpno;

    @Schema(description = "최종 수정자 사번", example = "11112223")
    private String lstChgrEmpno;

    @Schema(description = "등록일시", example = "2025-06-13T13:16:57")
    private LocalDateTime frstRegDt;

    @Schema(description = "최종 변경일시", example = "2025-06-13T13:16:57")
    private LocalDateTime lstChgDt;

    @JsonView({ RequestGroup.Search.class })
    @Schema(description = "신청 일시", example = "2025-06-13T13:16:57")
    private LocalDateTime aplDt;

    @Schema(description = "신청자(요청자) 사번", example = "11112223")
    private String aplrEmpno;

    @Schema(description = "신청자 이름", example = "홍길동")
    private String aplrNm;

    @Schema(description = "신청자 소속 부서명", example = "어느 소속 어느 부서")
    private String aplrDeptNm;

    @Size(max=20)
    @Schema(description = "대상자(발급 대상) 사번", example = "11112223")
    private String tgtrEmpno;

    @Size(max=50)
    @JsonView({ RequestGroup.Search.class })
    @Schema(description = "대상자 이름", example = "홍길동")
    private String tgtrNm;

    @Size(max=100)
    @Schema(description = "대상자 소속 부서명", example = "어느 소속 어느 부서")
    private String tgtrDeptNm;

    @Size(max=500)
    @Schema(description = "신청 사유", example = "이러이러해서 신청합니다.")
    private String aplRsnCtt;

    @JsonView({ RequestGroup.Search.class })
    @Schema(description = "승인 상태 코드", example = "1")
    private String measAprStsCd;

    @Schema(description = "승인자 사번", example = "11112223")
    private String aprrEmpno;

    @Schema(description = "승인 일시", example = "2025-06-13T13:16:57")
    private LocalDateTime aprDt;

    @Size(max=500)
    @Schema(description = "반려 사유", example = "이래이래서 안됩니다.")
    private String snbkRsnCtt;

    @Size(max=1)
    @Schema(description = "삭제 여부", example = "N")
    private String delYn;

    @Size(max=20)
    @JsonView({ RequestGroup.Search.class })
    @Schema(description = "교육 일련번호", example = "교육 일련번호")
    private String edamsCrcmCd;

    @Size(max=100)
    @JsonView({ RequestGroup.Search.class })
    @Schema(description = "교육명", example = "교육")
    private String eduNm;
}
