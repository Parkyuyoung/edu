package kr.kepco.edu.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(name = "AuthMenuDTO", description = "권한별 메뉴 관리 DTO")
public class AuthMenuDTO {
    @Schema(description = "상위메뉴ID", example = "ADMIN")
    private String parentMenuId;
    @Schema(description = "메뉴ID", example = "ADMIN_100")
    private String menuId;
    @Schema(description = "메뉴명", example = "임시사원증 신청 관리")
    private String menuNm;
    @Schema(description = "권한코드", example = "SYS")
    private String eduAuthCd;
    @Schema(description = "상위메뉴명", example = "관리자")
    private String parentMenuNm;
    @Schema(description = "사용여부", example = "Y")
    private String useYn;  // 'Y' : 체크됨, 'N' : 체크 안됨
}