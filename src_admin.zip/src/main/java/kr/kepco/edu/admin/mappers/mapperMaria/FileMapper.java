package kr.kepco.edu.admin.mappers.mapperMaria;

import kr.kepco.edu.admin.dto.FileDTO;
import org.apache.ibatis.annotations.Param;

public interface FileMapper {

    int insertFile(FileDTO vo);
    int deleteFile(@Param("fileSerno") Long fileSerno,
                   @Param("empno") String empno);

    FileDTO selectFile(@Param("fileSerno") Long fileSerno);

    FileDTO selectMenuFile(String menuSerno, String type, String menu);
}
