package kr.kepco.edu.admin.service;

import kr.kepco.edu.admin.dto.EmpInfoDTO;
import kr.kepco.edu.admin.mappers.mapperOracle.JojicMapper;
import kr.kepco.edu.admin.response.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
public class JojicService {
    @Autowired
    JojicMapper jojicMapper;

    public List<String> getSeachEmpList(String searchEmpName) { return jojicMapper.getSeachEmpList(searchEmpName); }

    public List<EmpInfoDTO> getSeachEmpNmList(Set<String> empNos) {
        return jojicMapper.selectSeachEmpNmList(empNos);
    }

    public List<EmpInfoDTO> getSearchPhoneList(Set<String> empNos) { return jojicMapper.selectSearchPhoneList(empNos); }

    public List<EmpInfoDTO> getSearchEmpInfoList(Set<String> empNos) { return jojicMapper.selectSearchUserInfoList(empNos); }

    public int getSeachEmpListCnt(String empNm) {
        return jojicMapper.getSeachEmpListCnt(empNm);
    }
    public List<EmpInfoDTO> getSeachEmpList2(String empNm, Page<EmpInfoDTO> page) { return jojicMapper.getSeachEmpList2(empNm,page); }
}
