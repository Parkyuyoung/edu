package kr.kepco.edu.admin.controller;

import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import kr.kepco.edu.admin.dto.AuthMenuDTO;
import kr.kepco.edu.admin.dto.EduAuthDTO;
import kr.kepco.edu.admin.dto.MenuFilterDTO;
import kr.kepco.edu.admin.request.AuthMenuReq;
import kr.kepco.edu.admin.request.EduAuthReq;
import kr.kepco.edu.admin.request.MenuFilterReq;
import kr.kepco.edu.admin.response.ApiResponse;
import kr.kepco.edu.admin.service.AuthMenuService;
import kr.kepco.edu.admin.service.CustomUserDetails;
import kr.kepco.edu.admin.service.EduUserService;
import kr.kepco.edu.admin.util.CommonUtil;
import kr.kepco.edu.admin.validation.ErrorCode;
import kr.kepco.edu.admin.validation.RequestGroup;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Tag(name = "10. 권한별 메뉴 관리", description = "권한별 메뉴 관리")
@RestController
@RequestMapping("${base.url}/authMenu")
@RequiredArgsConstructor
public class AuthMenuController {
    @Autowired
    private AuthMenuService authMenuService;

    @Autowired
    private EduUserService eduUserService;

    @Operation(summary = "상위 메뉴 목록 조회", description = "선택된 권한에 해당하는 상위 메뉴 목록을 조회합니다.")
    @PostMapping("/parent")
    public ApiResponse<List<MenuFilterDTO>> getParentMenus(
    ) {
        List<MenuFilterDTO> list = authMenuService.getParentMenuList();
        if (CommonUtil.isValid(list)) {
            return ApiResponse.ok(HttpStatus.OK, list, "OK");
        } else {
            return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }
    }

    @Operation(summary = "하위 메뉴 목록 조회", description = "선택된 권한 + 상위 메뉴에 대한 하위 메뉴 목록을 조회합니다.",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
            required = true,
            content = @Content(
                    schema = @Schema(implementation = MenuFilterReq.class),
                    examples = {
                            @ExampleObject(
                                    name = "하위 메뉴 검색",
                                    value = "{\n" +
                                            "  \"parentMenuId\": \"ADMIN\"\n" +
                                            "}"
                            )}
            )
            )
    )
    @PostMapping("/child")
    public ApiResponse<List<MenuFilterDTO>> getChildMenus(
            @RequestBody MenuFilterReq req
    ) {
        if(req.getParentMenuId().isBlank()){
            return ApiResponse.fail(ErrorCode.REQ_MISSING_PARAM);
        }
        if (authMenuService.validateParentMenuExists(req.getParentMenuId()) == 0) {
            return ApiResponse.fail(ErrorCode.VAL_INVALID);
        }

        List<MenuFilterDTO> list = authMenuService.getChildMenuList(req);
        if (CommonUtil.isValid(list)) {
            return ApiResponse.ok(HttpStatus.OK, list, "OK");
        } else {
            return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }
    }

    @Operation(
            summary = "권한별 메뉴 목록 조회",
            description = "선택된 권한코드와 상위메뉴에 따른 메뉴 리스트와 사용여부를 조회합니다.",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            schema = @Schema(implementation = AuthMenuReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "권한별 메뉴 목록 조회",
                                            value = "{\n" +
                                                    "  \"edamsAuthCd\": \"SYS\",\n" +
                                                    "  \"parentMenuId\": \"ADMIN\"\n" +
                                                    "}"
                                    )
                            }
                    )
            )
    )
    @PostMapping("/list")
    public ApiResponse<List<AuthMenuDTO>> getAuthMenuList(@RequestBody @JsonView(RequestGroup.Search.class) AuthMenuReq req) {
//        if(req.getParentMenuId().isBlank() || req.getedamsAuthCd().isBlank()){
//            return ApiResponse.fail(ErrorCode.REQ_MISSING_PARAM);
//        }

        if(!eduUserService.isValidEduAuth(req.getEdamsAuthCd())){
            return ApiResponse.fail(ErrorCode.VAL_INVALID);
        }

//        if (authMenuService.validateParentMenuExists(req.getParentMenuId()) == 0) {
//            return ApiResponse.fail(ErrorCode.VAL_INVALID);
//        }

        List<AuthMenuDTO> list = authMenuService.getAuthMenuList(req);

        if (CommonUtil.isValid(list)) {
            return ApiResponse.ok(HttpStatus.OK, list, "OK");
        } else {
            return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }
    }

    @Operation(
            summary = "권한별 메뉴 저장",
            description = "선택된 권한과 상위메뉴에 대해 체크된 메뉴들을 저장합니다.",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            schema = @Schema(implementation = AuthMenuReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "권한별 메뉴 저장",
                                            value = "{\n" +
                                                    "  \"edamsAuthCd\": \"SYS\",\n" +
                                                    "  \"parentMenuId\": \"ADMIN\",\n" +
                                                    "  \"menuIds\": [\"ADMIN_100\", \"ADMIN_200\", \"ADMIN_700\"]\n" +
                                                    "}"
                                    )
                            }
                    )
            )
    )
    @PostMapping("/updateAll")
    public ApiResponse<String> saveAuthMenus(@RequestBody @JsonView(RequestGroup.Update.class) AuthMenuReq req) {
//        if(req.getParentMenuId().isBlank() || req.getedamsAuthCd().isBlank()){
//            return ApiResponse.fail(ErrorCode.REQ_MISSING_PARAM);
//        }
        if(!eduUserService.isValidEduAuth(req.getEdamsAuthCd())){
            return ApiResponse.fail(ErrorCode.VAL_INVALID);
        }
//        if (authMenuService.validateParentMenuExists(req.getParentMenuId()) == 0) {
//            return ApiResponse.fail(ErrorCode.VAL_INVALID);
//        }

        int existCount = authMenuService.validateMenuIdsExist(req.getMenuIds());

        if (existCount != req.getMenuIds().size()) {
            return ApiResponse.fail(ErrorCode.VAL_INVALID); //존재하지 않는 메뉴 포함
        }
        authMenuService.saveAuthMenus(req);

        return ApiResponse.ok(HttpStatus.OK, "저장되었습니다.", "저장되었습니다.");
    }

    @Operation(
            summary = "권한별 메뉴 단건 업데이트",
            description = "체크박스 변경 시 단일 메뉴의 권한 사용여부를 업데이트합니다.",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            schema = @Schema(implementation = AuthMenuReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "체크 (ON)",
                                            value = "{\n" +
                                                    "  \"edamsAuthCd\": \"SYS\",\n" +
                                                    "  \"menuId\": \"ADMIN_100\",\n" +
                                                    "  \"checkYn\": \"Y\"\n" +
                                                    "}"
                                    ),
                                    @ExampleObject(
                                            name = "체크 해제 (OFF)",
                                            value = "{\n" +
                                                    "  \"edamsAuthCd\": \"SYS\",\n" +
                                                    "  \"menuId\": \"ADMIN_100\",\n" +
                                                    "  \"checkYn\": \"N\"\n" +
                                                    "}"
                                    )
                            }
                    )
            )
    )
    @PostMapping("/updateOne")
    public ApiResponse<Void> updateOne(@RequestBody @JsonView(AuthMenuReq.Req.UpdateOne.class) AuthMenuReq req) {
        if(req.getMenuId().isBlank() || req.getEdamsAuthCd().isBlank() || req.getCheckYn().isBlank()){
            return ApiResponse.fail(ErrorCode.REQ_MISSING_PARAM);
        }
        if(!eduUserService.isValidEduAuth(req.getEdamsAuthCd())){
            return ApiResponse.fail(ErrorCode.VAL_INVALID);
        }

        if (!req.getCheckYn().equalsIgnoreCase("Y") &&
                !req.getCheckYn().equalsIgnoreCase("N")) {
            return ApiResponse.fail(ErrorCode.VAL_INVALID);
        }

        if (authMenuService.validateMenuExists(req.getMenuId()) == 0) {
            return ApiResponse.fail(ErrorCode.VAL_INVALID);
        }


        authMenuService.updateSingleMenu(req);

        return ApiResponse.ok(HttpStatus.OK, null, "변경되었습니다.");
    }


    @Operation(summary = "메뉴 목록 조회", description = "메뉴 목록 조회")
    @PostMapping("/getMenuList")
    public ApiResponse<List<MenuFilterDTO>> selectMenuAuthList(
    ) {
        List<MenuFilterDTO> list = authMenuService.selectMenuAuthList();
        if (CommonUtil.isValid(list)) {
            return ApiResponse.ok(HttpStatus.OK, list, "OK");
        } else {
            return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }
    }

    @Operation(summary = "권한 목록 조회", description = "권한 목록 조회")
    @PostMapping("/getAuthList")
    public ApiResponse<List<EduAuthDTO>> selectAuthList(
    ) {
        List<EduAuthDTO> list = authMenuService.selectAuthList();
        if (CommonUtil.isValid(list)) {
            return ApiResponse.ok(HttpStatus.OK, list, "OK");
        } else {
            return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }
    }

    @Operation(summary = "권한 등록", description = "권한 등록")
    @PostMapping("/insertAuth")
    public ApiResponse<String> insertAuth(@AuthenticationPrincipal CustomUserDetails user,  @RequestBody EduAuthReq eduAuthReq) {

        if(!CommonUtil.isValid(eduAuthReq.getEdamsAuthCd()) || !CommonUtil.isValid(eduAuthReq.getEduAuthNm()))  {
            return ApiResponse.fail(ErrorCode.REQ_MISSING_PARAM);
        }

        eduAuthReq.setFrstRegrEmpno(user.getUsername());
        eduAuthReq.setLstChgrEmpno(user.getUsername());

        if (authMenuService.insertAuth(eduAuthReq)) {
            return ApiResponse.ok(HttpStatus.OK, "정상 등록되었습니다.", "OK");
        } else {
            return ApiResponse.fail(ErrorCode.INSERT_INTERNAL);
        }
    }
}
