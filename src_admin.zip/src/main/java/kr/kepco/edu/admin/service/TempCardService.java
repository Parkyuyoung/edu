package kr.kepco.edu.admin.service;

import kr.kepco.edu.admin.dto.TempCardDTO;
import kr.kepco.edu.admin.mappers.mapperMaria.TempCardMapper;
import kr.kepco.edu.admin.request.TempCardReq;
import kr.kepco.edu.admin.response.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TempCardService {
    @Autowired
    TempCardMapper tempCardMapper;

    public long selectTempCardListCnt(TempCardReq req) { return tempCardMapper.selectTempCardListCnt(req); }

    public List<TempCardDTO> selectTempCardList(TempCardReq req, Page<TempCardDTO> page) { return tempCardMapper.selectTempCardList(req, page); }

    public TempCardDTO selectTempCardDetail(TempCardReq req) { return tempCardMapper.selectTempCardDetail(req); }

    public int insertTempCard(TempCardReq req) { return tempCardMapper.insertTempCard(req); }

    public Integer updateTempCard(TempCardReq req) { return tempCardMapper.updateTempCard(req); }

    public Integer deleteTempCard(TempCardReq req) { return tempCardMapper.deleteTempCard(req); }

    public Integer approveTempCard(TempCardReq req) { return tempCardMapper.approveTempCard(req); }


}
