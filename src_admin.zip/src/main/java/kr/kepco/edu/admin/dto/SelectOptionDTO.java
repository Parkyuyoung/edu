package kr.kepco.edu.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SelectOptionDTO {
    @Schema(description = "표시라벨", example = "[기본]AutoCAD호환 CADian기초 과정")
    private String label;

    @Schema(description = "값", example = "1669")
    private String value;
}