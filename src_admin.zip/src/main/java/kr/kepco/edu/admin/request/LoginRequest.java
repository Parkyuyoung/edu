package kr.kepco.edu.admin.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(name = "LoginRequest", description = "로그인 요청 바디")
public class LoginRequest {
    @Schema(description = "사번(사내 ID)", example = "11112223")
    private String empId;

    @Schema(description = "SSO 패스워드", example = "11112223")
    private String password;
}
