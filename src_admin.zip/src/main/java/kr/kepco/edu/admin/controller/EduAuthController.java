package kr.kepco.edu.admin.controller;

import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import kr.kepco.edu.admin.dto.EduAuthDTO;
import kr.kepco.edu.admin.request.EduAuthReq;
import kr.kepco.edu.admin.response.ApiResponse;
import kr.kepco.edu.admin.response.Page;
import kr.kepco.edu.admin.service.CustomUserDetails;
import kr.kepco.edu.admin.service.EduAuthService;
import kr.kepco.edu.admin.util.CommonUtil;
import kr.kepco.edu.admin.validation.ErrorCode;
import kr.kepco.edu.admin.validation.RequestGroup;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "07. 권한 관리", description = "EDU 권한 관리")
@RestController
@Slf4j
@RequestMapping("${base.url}/eduAuth")
public class EduAuthController {
    @Autowired
    private EduAuthService eduAuthService;

    @Operation(
            summary = "권한 목록 조회",
            description = "EDU 권한 목록을 조회합니다.",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            schema = @Schema(implementation = EduAuthReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "권한코드로 검색",
                                            value = "{\n" +
                                                    "  \"currentPage\": 1,\n" +
                                                    "  \"pageSize\": 10,\n" +
                                                    "  \"srchAuthCd\": \"SYS\"\n" +
                                                    "}"
                                    ),
                                    @ExampleObject(
                                            name = "권한명으로 검색",
                                            value = "{\n" +
                                                    "  \"currentPage\": 1,\n" +
                                                    "  \"pageSize\": 10,\n" +
                                                    "  \"srchAuthNm\": \"사용자\"\n" +
                                                    "}"
                                    )
                            }
                    )
            )
    )
    @PostMapping("/list")
    public ApiResponse<Page<EduAuthDTO>> getEduAuthList(
            @AuthenticationPrincipal CustomUserDetails user,
            @RequestBody @JsonView(RequestGroup.Search.class) EduAuthReq eduAuthReq
    ) {

        int totalCnt = eduAuthService.getEduAuthListCnt(eduAuthReq);
        Page<EduAuthDTO> page = new Page<>(eduAuthReq.getCurrentPage(), eduAuthReq.getPageSize(), totalCnt);

        List<EduAuthDTO> list = eduAuthService.getEduAuthList(eduAuthReq, page);
        page.setContent(list);

        if (CommonUtil.isValid(page.getContent())) {
            return ApiResponse.ok(HttpStatus.OK, page, "OK.");
        } else {
            return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }
    }

    @Operation(
            summary = "권한 등록",
            description = "새 EDU 권한을 등록합니다.",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            schema = @Schema(implementation = EduAuthReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "권한 등록 예시",
                                            value = "{\n" +
                                                    "  \"eduAuthCd\": \"SYS\",\n" +
                                                    "  \"eduAuthNm\": \"시스템관리자\"\n" +
                                                    "}"
                                    )
                            }
                    )
            )
    )
    @PostMapping("/insert")
    public ApiResponse<String> insertEduAuth(
            @AuthenticationPrincipal CustomUserDetails user,
            @RequestBody @JsonView(RequestGroup.Insert.class) EduAuthReq eduAuthReq
    ) {
        // 등록자/수정자 사번 세팅 (UserDetails에서 username을 사번으로 사용한다고 가정)
        if (user != null) {
            eduAuthReq.setFrstRegrEmpno(user.getUsername());
            eduAuthReq.setLstChgrEmpno(user.getUsername());
        }

        // 코드 중복 체크
        if (eduAuthService.isDupAuthCode(eduAuthReq)) {
            return ApiResponse.fail(ErrorCode.RES_DUPLICATED);
        }

        // 권한명 중복 체크
        if (eduAuthService.isDupAuthName(eduAuthReq)) {
            return ApiResponse.fail(ErrorCode.RES_DUPLICATED);
        }

        int result = eduAuthService.insertEduAuth(eduAuthReq);

        if (result > 0) {
            return ApiResponse.ok(HttpStatus.OK, "정상적으로 등록되었습니다.", "OK");
        } else {
            return ApiResponse.fail(ErrorCode.INSERT_INTERNAL);
        }
    }

    @Operation(
            summary = "권한 수정",
            description = "기존 EDU 권한 정보를 수정합니다.",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            schema = @Schema(implementation = EduAuthReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "권한 수정 예시",
                                            value = "{\n" +
                                                    "  \"eduAuthCd\": \"SYS\",\n" +
                                                    "  \"eduAuthNm\": \"시스템 관리자(수정)\"\n" +
                                                    "}"
                                    )
                            }
                    )
            )
    )
    @PostMapping("/update")
    public ApiResponse<Integer> updateEduAuth(
            @AuthenticationPrincipal CustomUserDetails user,
            @RequestBody @JsonView(RequestGroup.Update.class) EduAuthReq eduAuthReq
    ) {
        if (user != null) {
            eduAuthReq.setLstChgrEmpno(user.getUsername());
        }

        // 권한명 중복 체크 (자기 자신 제외는 XML에서 처리)
        if (eduAuthService.isDupAuthName(eduAuthReq)) {
            return ApiResponse.fail(ErrorCode.RES_DUPLICATED);
        }

        int result = eduAuthService.updateEduAuth(eduAuthReq);

        if (result > 0) {
            return ApiResponse.ok(HttpStatus.OK, result, "OK");
        } else {
            return ApiResponse.fail(ErrorCode.UPDATE_INTERNAL);
        }
    }

    @Operation(
            summary = "권한 삭제",
            description = "EDU 권한 및 해당 권한을 가진 사용자(EDU_USER)를 논리삭제합니다.",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            schema = @Schema(implementation = EduAuthReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "권한 삭제 예시",
                                            value = "{\n" +
                                                    "  \"eduAuthCd\": \"SYS\"\n" +
                                                    "}"
                                    )
                            }
                    )
            )
    )
    @PostMapping("/delete")
    public ApiResponse<String> deleteEduAuth(
            @AuthenticationPrincipal CustomUserDetails user,
            @RequestBody @JsonView(RequestGroup.Update.class) EduAuthReq eduAuthReq
    ) {
        if (user != null) {
            eduAuthReq.setLstChgrEmpno(user.getUsername());
        }

        int result = eduAuthService.deleteEduAuth(eduAuthReq);

        if (result > 0) {
            return ApiResponse.ok(HttpStatus.OK, "삭제가 완료되었습니다.", "삭제가 완료되었습니다.");
        } else {
            return ApiResponse.fail(ErrorCode.DELETE_INTERNAL);
        }
    }

    @Operation(
            summary = "권한 필터 조회",
            description = "DEL_YN = 'N' 상태의 권한코드 / 권한명을 리스트로 조회합니다."
    )
    @PostMapping("/filter")
    public ApiResponse<List<EduAuthDTO>> getAuthFilter() {

        List<EduAuthDTO> list = eduAuthService.getAuthFilter();

        if (CommonUtil.isValid(list)) {
            return ApiResponse.ok(HttpStatus.OK, list, "OK");
        } else {
            return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }
    }
}
