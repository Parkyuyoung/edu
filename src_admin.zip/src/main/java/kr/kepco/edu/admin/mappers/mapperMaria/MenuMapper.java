package kr.kepco.edu.admin.mappers.mapperMaria;

import kr.kepco.edu.admin.dto.MenuDTO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface MenuMapper {
    List<MenuDTO> selectAllActiveMenus();
}