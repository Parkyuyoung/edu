package kr.kepco.edu.admin.mappers.mapperMaria;

import kr.kepco.edu.admin.dto.BannerDTO;
import kr.kepco.edu.admin.request.BannerReq;
import kr.kepco.edu.admin.response.Page;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface BannerMapper {
    int selectBannerListCnt(@Param("param") BannerReq bannerReq);
    List<BannerDTO> selectBannerList(@Param("param") BannerReq bannerReq, @Param("page") Page<BannerDTO> page);
    List<BannerDTO> selectBannerPostYnList(BannerReq bannerReq);
    int insertBanner(BannerReq bannerReq);
    BannerDTO selectBannerDetail(BannerReq bannerReq);
    int modifyBanner(BannerReq bannerReq);

    int deleteBanner(BannerReq bannerReq);

    int modifyPostYn(BannerReq bannerReq);

    int selectPostnCnt();

    int updateSortOrder(BannerReq bannerReq);

    int updateOrderSetting(BannerReq bannerReq);
}
