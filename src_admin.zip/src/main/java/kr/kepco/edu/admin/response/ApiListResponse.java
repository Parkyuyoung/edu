package kr.kepco.edu.admin.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;

import kr.kepco.edu.admin.validation.ErrorCode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

import java.util.List;

@Getter @Builder
@AllArgsConstructor @NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiListResponse<T> {
    private boolean success;        // 처리 성공 여부
    private int status;             // HTTP status code (예: 200, 400)
    private String message;         // 메시지(옵션)
    private long timestamp;         // 응답 시각 (epoch millis)
    private List<T> data; // 리스트 데이터 (페이징 없음)
    @Schema(description = "에러 코드 (실패 시)", example = "EDU-400-COMMON-MISSING_PARAM")
    private String code;
    // 성공(리스트 데이터) - 기본 200
    public static <T> ApiListResponse<T> ok(List<T> data) {
        return ok(HttpStatus.OK, data, null);
    }

    // 성공(상태/메시지 지정)
    public static <T> ApiListResponse<T> ok(HttpStatus status, List<T> data, String message) {
        return ApiListResponse.<T>builder()
                .success(true)
                .status(status.value())
                .message(message)
                .timestamp(System.currentTimeMillis())
                .data(data)
                .build();
    }

    // 실패
    public static ApiListResponse<Void> fail(HttpStatus status, String message) {
        return ApiListResponse.<Void>builder()
                .success(false)
                .status(status.value())
                .message(message)
                .timestamp(System.currentTimeMillis())
                .build();
    }


    // --- 실패: ErrorCode 기반 (추천) ---
    public static <T> ApiListResponse<T> fail(ErrorCode errorCode) {
        return ApiListResponse.<T>builder()
                .success(false)
                .status(errorCode.getStatus().value())
                .message(errorCode.getMessage())
                .code(errorCode.getCode())
                .timestamp(System.currentTimeMillis())
                .build();
    }

}
