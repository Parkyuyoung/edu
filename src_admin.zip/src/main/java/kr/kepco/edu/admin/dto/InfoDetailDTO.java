package kr.kepco.edu.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Schema(name = "InfoDetailDTO", description = "정보 상세 DTO")
public class InfoDetailDTO {

    @Schema(description = "순번", example = "1")
    private String rnum;

    @Schema(description = "안내 정보 detail 일련번호", example = "1")
    private String dtlsInfoSerno;

    @Schema(description = "최초등록일시", example = "2025-10-20T14:30:00")
    private LocalDateTime frstRegDt;

    @Schema(description = "최초등록자사번", example = "EMP00123")
    private String frstRegrEmpno;

    @Schema(description = "최종변경일시", example = "2025-10-20T15:45:00")
    private LocalDateTime lstChgDt;

    @Schema(description = "최종변경자사번", example = "EMP00456")
    private String lstChgrEmpno;

    @Schema(description = "정보 마스터 일련번호", example = "1")
    private String infoSerno;

    @Schema(description = "제목", example = "1층")
    private String dtlsInfoTitlNm;

    @Schema(description = "상세", example = "어디에 있습니다.")
    private String dtlsInfoCtt;

    @Schema(description = "최초등록자이름", example = "EMP00123")
    private String frstRegrEmpnm;

    @Schema(description = "최종등록자 이름", example = "홍길동")
    private String lastRegrEmpnm;

    @Schema(description = "분류", example = "어디에 있습니다.")
    private String measInfoClCd;

    @Schema(description = "분류", example = "어디에 있습니다.")
    private String grpTitlNm;

    @Schema(description = "정렬순서", example = "1")
    private String scrSortSeqo;

    @Schema(description = "삭제여부(Y/N)", example = "Y")
    private String delYn;

    @Schema(description = "파일주소", example = "/files/meal/...")
    private String fileUrl = "Y";

    @Schema(description = "이미지 URL", example = "/images/banner/mob_banner01.png")
    private String infoImgUrl;

    @Schema(description = "이미지 이름", example = "/images/banner/mob_banner01.png")
    private String infoImageFileNm;

}
