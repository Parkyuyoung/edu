package kr.kepco.edu.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Schema(name = "TempCardDTO", description = "임시사원증 DTO")
public class TempCardDTO {

    @Schema(description = "행번호(서버 계산, 응답 전용)", example = "1")
    private int rnum;

    @Schema(description = "임시사원증 신청 일련번호(PK)", example = "12345")
    private Long tmpEidAplSerno;

    @Schema(description = "등록자 사번", example = "11112223")
    private String frstRegrEmpno;

    @Schema(description = "최종 수정자 사번", example = "11112223")
    private String lstChgrEmpno;

    @Schema(description = "등록일시", example = "2025-06-13T13:16:57")
    private LocalDateTime frstRegDt;

    @Schema(description = "최종 변경일시", example = "2025-06-13T13:16:57")
    private LocalDateTime lstChgDt;

    @Schema(description = "신청 일시", example = "2025-06-13T13:16:57")
    private LocalDateTime aplDt;

    @Schema(description = "신청자(요청자) 사번", example = "11112223")
    private String aplrEmpno;

    @Schema(description = "신청자 이름", example = "홍길동")
    private String aplrNm;

    @Schema(description = "신청자 소속 부서명", example = "어느 소속 어느 부서")
    private String aplrDeptNm;

    @Schema(description = "대상자(발금 대상) 사번", example = "11112223")
    private String tgtrEmpno;

    @Schema(description = "대상자 이름", example = "홍길동")
    private String tgtrNm;

    @Schema(description = "대상자 소속 부서명", example = "어느 소속 어느 부서")
    private String tgtrDeptNm;

    @Schema(description = "신청 사유", example = "이러이러해서 신청합니다.")
    private String aplRsnCtt;

    @Schema(description = "승인 상태 코드", example = "1")
    private String measAprStsCd;

    @Schema(description = "승인자 사번", example = "11112223")
    private String aprrEmpno;

    @Schema(description = "승인 일시", example = "2025-06-13T13:16:57")
    private LocalDateTime aprDt;

    @Schema(description = "반려 사유", example = "이래이래서 안됩니다.")
    private String snbkRsnCtt;

    @Schema(description = "삭제 여부", example = "N")
    private String delYn;

    @Schema(description = "교육 일련번호", example = "교육 일련번호")
    private String edamsCrcmCd;

    @Schema(description = "교육명", example = "교육")
    private String eduNm;

    @Schema(description = "교육 기수", example = "1")
    private String crcmDgr;
}

