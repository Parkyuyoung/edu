package kr.kepco.edu.admin.client;

import org.springframework.stereotype.Component;

@Component
public class EduClientFallback implements EduClient {
    public java.util.List<String> getCourses() {
        return java.util.Collections.singletonList("admin service unavailable");
    }
}