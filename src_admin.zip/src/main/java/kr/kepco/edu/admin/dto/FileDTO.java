package kr.kepco.edu.admin.dto;

// kr.kepco.edu.users.model.FileMng.java

import lombok.Data;

@Data
public class FileDTO {
    private String fileSerno;

    private String frstRegrEmpno;
    private String lstChgrEmpno;

    private String menuSerno;
    private String type;

    private String filePthNm;
    private String filePthCtt;
    private String orgsFileNm;
    private String savFileNm;
    private String fextNm;
    private String upldFileMimeTpNm;
    private Long fileSizeCpct;

    private Integer sortSeqo;
    private String delYn;
}

