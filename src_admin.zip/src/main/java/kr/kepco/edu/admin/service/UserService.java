package kr.kepco.edu.admin.service;


import kr.kepco.edu.admin.dto.EduUserDTO;
import kr.kepco.edu.admin.dto.UserDTO;
import kr.kepco.edu.admin.mappers.mapperMaria.MariaUserMapper;
import kr.kepco.edu.admin.mappers.mapperOracle.UserMapper;
import kr.kepco.edu.admin.request.AuthLogReq;
import kr.kepco.edu.admin.request.LoginRequest;
import kr.kepco.edu.admin.util.EmpNameUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService implements UserDetailsService {

    @Autowired
    UserMapper userRepository;

    @Autowired
    MariaUserMapper mariaUserMapper;

    @Autowired
    EmpNameUtil empNameUtil;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        throw new UsernameNotFoundException("Use loadUserByUsernameAndCompanyId instead.");
    }

    public UserDetails loadUserByUsernameAndCompanyId(String username) {
        UserDTO user = mariaUserMapper.loginUser(username);
        if (user == null) {
            throw new UsernameNotFoundException("User not found");
        }
        return new CustomUserDetails(user);
    }

    public UserDTO loginUser(String username) throws UsernameNotFoundException {

        UserDTO userDTO =  mariaUserMapper.loginUser(username);
        empNameUtil.enrichNameOne(
                userDTO,
                UserDTO::getUserId,
                UserDTO::setUserNm
        );
        return userDTO;
    }

    public boolean chkPassword(LoginRequest req)  {
        return userRepository.chkPassword(req) > 0;
    }


    public UserDTO eduLogin(String username) {
        return mariaUserMapper.loginUser(username);
    }

    public List<String> selectMenuIds(String edamsAuthCd) {
        return mariaUserMapper.selectMenuIds(edamsAuthCd);
    }
}