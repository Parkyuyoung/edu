package kr.kepco.edu.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Schema(name = "GideDTO", description = "입교안내 DTO")
public class GuideDTO {

    @Schema(description = "순번", example = "1")
    private String rnum;

    @Schema(description = "교육행정 안내 일련번호", example = "1")
    private String guideMstSerno;

    @Schema(description = "최초등록일시", example = "2025-10-20T14:30:00")
    private LocalDateTime frstRegDt;

    @Schema(description = "최초등록자사번", example = "EMP00123")
    private String frstRegrEmpno;

    @Schema(description = "최초등록자이름", example = "EMP00123")
    private String frstRegrEmpnm;
    
    @Schema(description = "최종등록자 이름", example = "홍길동")
    private String lastRegrEmpnm;

    @Schema(description = "최종변경일시", example = "2025-10-20T15:45:00")
    private LocalDateTime lstChgDt;

    @Schema(description = "최종변경자사번", example = "EMP00456")
    private String lstChgrEmpno;

    @Schema(description = "안내유형코드", example = "GUIDE01")
    private String measGuideTpCd;

    @Schema(description = "정렬순서", example = "1")
    private String scrSortSeqo;

    @Schema(description = "게시여부(Y/N)", example = "Y")
    private String pstnYn;

    @Schema(description = "삭제여부(Y/N)", example = "Y")
    private String delYn;

    @Schema(description = "교육행정 안내 마스터(입교안내/시설안내 구분용)", example = "입교안내")
    private String guideTitlKrnNm;

    @Schema(description = "교육행정 안내 섹션 버전", example = "001")
    private String guideSctnVerNo;

    @Schema(description = "섹션 제목명", example = "입교 안내 절차")
    private String guideSctnTitlNm;

    @Schema(description = "섹션 본문 내용", example = "입교 절차는 3단계로 구성되어 있습니다...")
    private String guideSctnCtt;
}
