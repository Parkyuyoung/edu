package kr.kepco.edu.admin.controller;

import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import kr.kepco.edu.admin.dto.EduUserDTO;
import kr.kepco.edu.admin.dto.EmpInfoDTO;
import kr.kepco.edu.admin.request.AuthLogReq;
import kr.kepco.edu.admin.request.EduUserReq;
import kr.kepco.edu.admin.response.ApiResponse;
import kr.kepco.edu.admin.response.Page;
import kr.kepco.edu.admin.service.CustomUserDetails;
import kr.kepco.edu.admin.service.EduUserService;
import kr.kepco.edu.admin.service.JojicService;
import kr.kepco.edu.admin.util.CommonUtil;
import kr.kepco.edu.admin.validation.ErrorCode;
import kr.kepco.edu.admin.validation.RequestGroup;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Tag(name = "08. 권한별 사용자 관리", description = "권한별 사용자 관리")
@RestController
@Slf4j
@RequestMapping("${base.url}/eduUser")
public class EduUserController {
    @Autowired
    private EduUserService eduUserService;

    @Autowired
    JojicService jojicService;
    @Operation(
            summary = "권한별 사용자 관리 목록 조회",
            description = "권한별 사용자 관리 목록 조회",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            schema = @Schema(implementation = EduUserReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "사번 검색",
                                            value = "{\n" +
                                                    "  \"currentPage\": 1,\n" +
                                                    "  \"pageSize\": 10,\n" +
                                                    "  \"srchType\": \"no\",\n" +
                                                    "  \"srchEmpNo\": \"11112223\",\n" +
                                                    "  \"startDate\": \"2025-01-01\",\n" +
                                                    "  \"endDate\": \"2025-01-31\",\n" +
                                                    "  \"srchAuthCd\": \"SYS\"\n" +
                                                    "}"
                                    ),
                                    @ExampleObject(
                                            name = "이름 검색",
                                            value = "{\n" +
                                                    "  \"currentPage\": 1,\n" +
                                                    "  \"pageSize\": 10,\n" +
                                                    "  \"srchType\": \"nm\",\n" +
                                                    "  \"srchEmpNm\": [\"홍길동\", \"김철수\"],\n" +
                                                    "  \"startDate\": \"2025-01-01\",\n" +
                                                    "  \"endDate\": \"2025-01-31\",\n" +
                                                    "  \"srchAuthCd\": \"SYS\"\n" +
                                                    "}"
                                    ),
                                    @ExampleObject(
                                            name = "날짜 + 권한 검색",
                                            value = "{\n" +
                                                    "  \"currentPage\": 1,\n" +
                                                    "  \"pageSize\": 20,\n" +
                                                    "  \"srchType\": \"no\",\n" +
                                                    "  \"srchEmpNo\": \"\",\n" +
                                                    "  \"startDate\": \"2025-03-01\",\n" +
                                                    "  \"endDate\": \"2025-03-31\",\n" +
                                                    "  \"srchAuthCd\": \"SYS\"\n" +
                                                    "}"
                                    )
                            }
                    )
            )
    )
    @PostMapping(value = "/list")
    public ApiResponse<Page<EduUserDTO>> getEduUserList (@AuthenticationPrincipal CustomUserDetails user, @RequestBody @JsonView(RequestGroup.Search.class) EduUserReq eduUserReq) {

        if (CommonUtil.isValid(eduUserReq.getSrchEmpNm()) && eduUserReq.getSrchType().equals("nm") ){
            List<String> empNos = jojicService.getSeachEmpList(eduUserReq.getSrchEmpNm());
            if(!CommonUtil.isValid(empNos)) return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
            eduUserReq.setSrchEmpNos(empNos);
        }
        Page<EduUserDTO> page = new Page<>(eduUserReq.getCurrentPage(),eduUserReq.getPageSize(), eduUserService.geteduUserListCnt(eduUserReq));

        List<EduUserDTO> eduUserDTOS = eduUserService.getEduUserList(eduUserReq,page);

        page.setContent(eduUserDTOS);

        if(CommonUtil.isValid(page.getContent())) {
            return ApiResponse.ok(HttpStatus.OK,page,"OK");
        } else {
            return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }
    }

    @Operation(
            summary = "권한별 사용자 등록",
            description = "권한별 사용자 정보를 등록합니다.",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            schema = @Schema(implementation = EduUserReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "권한 사용자 등록 예시",
                                            value = "{\n" +
                                                    "  \"eduAuthCd\": \"SYS\",\n" +
                                                    "  \"empNo\": \"24100171\"\n" +
                                                    "}"
                                    )
                            }
                    )
            )
    )
    @PostMapping("/insert")
    public ApiResponse<String> insertEduUser(
            @AuthenticationPrincipal CustomUserDetails user,
            @RequestBody @JsonView(RequestGroup.Insert.class) EduUserReq eduUserReq
    ) {

        // 중복 체크 (권한 + 사용자 조합 등)
        if (eduUserService.isDupEduUser(eduUserReq)) {
            return ApiResponse.fail(ErrorCode.RES_DUPLICATED);
        }

        //존재하지 않는 권한 코드 입력 시
        if(!eduUserService.isValidEduAuth(eduUserReq.getEdamsAuthCd())){
            return ApiResponse.fail(ErrorCode.VAL_INVALID);
        }


         if (user != null) {
             eduUserReq.setFrstRegrEmpno(user.getUsername());
             eduUserReq.setLstChgrEmpno(user.getUsername());

             if(user.getUser().getUserDeptNm() != null) {
                 eduUserReq.setUserDeptNm(user.getUser().getUserDeptNm());
             } else {
                 eduUserReq.setUserDeptNm("임시");
             }
         }

        int result = eduUserService.insertEduUser(eduUserReq);

        // 권한 변경 이력을 남기고 싶다면, 여기에서 AuthLogReq 만들어서 insertAuthLog 호출
         if (result > 0) {
             AuthLogReq logReq = new AuthLogReq();
             logReq.setUserId(eduUserReq.getUserId()); // 예시
             logReq.setFrstRegrEmpno(eduUserReq.getFrstRegrEmpno());
             logReq.setLstChgrEmpno(eduUserReq.getLstChgrEmpno());
             logReq.setEdamsAuthCd(eduUserReq.getEdamsAuthCd());
             logReq.setLogCtt("1"); //1:부여, 2:말소, 3: 권한변경
             eduUserService.insertAuthLog(logReq);

             return ApiResponse.ok(HttpStatus.OK, "등록이 완료되었습니다.", "등록이 완료되었습니다.");
         } else {
            return ApiResponse.fail(ErrorCode.INSERT_INTERNAL);
        }
    }


    @Operation(
            summary = "권한별 사용자 수정",
            description = "권한별 사용자 정보를 수정합니다.",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            schema = @Schema(implementation = EduUserReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "권한 사용자 수정 예시",
                                            value = "{\n" +
                                                    "  \"eduAuthCd\": \"SYS\",\n" +
                                                    "  \"userId\": \"24100171\"\n" +
                                                    "}"
                                    )
                            }
                    )
            )
    )
    @PostMapping("/update")
    public ApiResponse<String> updateEduUser(
            @AuthenticationPrincipal CustomUserDetails user,
            @RequestBody @JsonView(RequestGroup.Update.class) EduUserReq eduUserReq
    ) {
        //존재하지 않는 권한 코드 입력 시
        if(!eduUserService.isValidEduAuth(eduUserReq.getEdamsAuthCd())){
            return ApiResponse.fail(ErrorCode.VAL_INVALID);
        }
        //존재하지 않는 관리자 사번 입력 시
        if(!eduUserService.isValidAdmin(eduUserReq.getUserId())){
            return ApiResponse.fail(ErrorCode.VAL_INVALID);
        }

         if (user != null) {
             eduUserReq.setLstChgrEmpno(user.getUsername());
         }

        int result = eduUserService.updateEduUser(eduUserReq);

         if (result > 0) {
             AuthLogReq logReq = new AuthLogReq();
             logReq.setUserId(eduUserReq.getUserId()); // 예시
             logReq.setFrstRegrEmpno(eduUserReq.getLstChgrEmpno());
             logReq.setLstChgrEmpno(eduUserReq.getLstChgrEmpno());
             logReq.setEdamsAuthCd(eduUserReq.getEdamsAuthCd());
             logReq.setLogCtt("3"); //1:부여, 2:말소, 3: 권한변경

             eduUserService.insertAuthLog(logReq);
             return ApiResponse.ok(HttpStatus.OK, "수정이 완료되었습니다.", "수정이 완료되었습니다.");
        } else {
            return ApiResponse.fail(ErrorCode.UPDATE_INTERNAL);
        }
    }

    @Operation(
            summary = "권한별 사용자 삭제",
            description = "권한별 사용자 정보를 삭제(논리삭제 또는 물리삭제)합니다.",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            schema = @Schema(implementation = EduUserReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "권한 사용자 삭제 예시",
                                            value = "{\n" +
                                                    "  \"userId\": \"24100171\" \n" +
                                                    "}"
                                    )
                            }
                    )
            )
    )
    @PostMapping("/delete")
    public ApiResponse<String> deleteEduUser(
            @AuthenticationPrincipal CustomUserDetails user,
            @RequestBody @JsonView(RequestGroup.Update.class) EduUserReq eduUserReq
    ) {
        //존재하지 않는 관리자 사번 입력 시
        if(!eduUserService.isValidAdmin(eduUserReq.getUserId())){
            return ApiResponse.fail(ErrorCode.VAL_INVALID);
        }

        if (user != null) {
            eduUserReq.setLstChgrEmpno(user.getUsername());
        }

        int result = eduUserService.deleteEduUser(eduUserReq);

         if (result > 0) {
             AuthLogReq logReq = new AuthLogReq();
             logReq.setUserId(eduUserReq.getUserId()); // 예시
             logReq.setFrstRegrEmpno(eduUserReq.getLstChgrEmpno());
             logReq.setLstChgrEmpno(eduUserReq.getLstChgrEmpno());
             logReq.setEdamsAuthCd(eduUserReq.getEdamsAuthCd());
             logReq.setLogCtt("2"); //1:부여, 2:말소, 3: 권한변경
             eduUserService.insertAuthLog(logReq);
         }

        if (result > 0) {
            return ApiResponse.ok(HttpStatus.OK, "삭제가 완료되었습니다.", "삭제가 완료되었습니다.");
        } else {
            return ApiResponse.fail(ErrorCode.DELETE_INTERNAL);
        }
    }


    @PostMapping(value = "/empSeach")
    public ApiResponse<Page<EmpInfoDTO>> getEmpSeach (@AuthenticationPrincipal CustomUserDetails user, @RequestBody EmpInfoDTO empInfoDTO) {

        Page<EmpInfoDTO> page = new Page<>(empInfoDTO.getCurrentPage(),empInfoDTO.getPageSize(), jojicService.getSeachEmpListCnt(empInfoDTO.getName()));

        List<EmpInfoDTO> eduUserDTOS = jojicService.getSeachEmpList2(empInfoDTO.getName(),page);

        page.setContent(eduUserDTOS);

        if(CommonUtil.isValid(page.getContent())) {
            return ApiResponse.ok(HttpStatus.OK,page,"OK");
        } else {
            return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }
    }



}
