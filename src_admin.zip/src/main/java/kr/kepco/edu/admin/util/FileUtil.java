package kr.kepco.edu.admin.util;

import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.util.UUID;

public final class FileUtil {
    private FileUtil() {}

    public static String save(MultipartFile file, Path rootDir, String category) throws IOException {
        if (file == null || file.isEmpty()) throw new IOException("empty file");

        // 이미지 여부 검증
        validateImage(file);
        
        LocalDate today = LocalDate.now();
        String safeCategory = (category == null || category.isBlank())
                ? ""
                : category.replaceAll("[^a-zA-Z0-9-_]", "_");

        Path dir = rootDir
                .resolve(safeCategory)
                .resolve(String.valueOf(today.getYear()))
                .resolve(String.format("%02d", today.getMonthValue()))
                .resolve(String.format("%02d", today.getDayOfMonth()));

        Files.createDirectories(dir);

        String original = StringUtils.cleanPath(
                file.getOriginalFilename() == null ? "upload" : file.getOriginalFilename()
        );

        String ext = "";
        int dot = original.lastIndexOf('.');
        if (dot > -1 && dot < original.length() - 1) {
            ext = original.substring(dot + 1).toLowerCase();
        }

        String filename = UUID.randomUUID() + (ext.isBlank() ? "" : "." + ext);
        Path target = dir.resolve(filename);

        // ✅ 핵심: InputStream을 try-with-resources로 확실히 닫아 임시파일 잠금 해제
        try (InputStream in = file.getInputStream()) {
            Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
        }

        String rel = rootDir.relativize(target).toString().replace("\\", "/");
        return "/files/" + rel;
    }

    public static boolean deleteByRelativePath(String relativePath, Path rootDir) throws IOException {
        if (relativePath == null || relativePath.isBlank()) return false;

        Path target = rootDir.resolve(relativePath).normalize();
        if (!target.startsWith(rootDir.normalize())) {
            throw new IOException("invalid path");
        }
        return Files.deleteIfExists(target);
    }

    public static boolean deleteByUrl(String url, Path rootDir) throws IOException {
        if (url == null || url.isBlank()) return false;
        String prefix = "/files/";
        if (!url.startsWith(prefix)) throw new IOException("invalid url");
        String relative = url.substring(prefix.length());
        return deleteByRelativePath(relative, rootDir);
    }

    /** 이미지 파일 여부 검증 */
    private static void validateImage(MultipartFile file) throws IOException {
        // --- 기본 정책 ---
        final long MAX_SIZE = 50L * 1024 * 1024; // 50MB 제한
        final int MAX_WIDTH = 10_000, MAX_HEIGHT = 10_000;
        final long MAX_PIXELS = 40_000_000L;

        // 1) 파일 크기 확인
        if (file.getSize() <= 0 || file.getSize() > MAX_SIZE)
            throw new IOException("invalid file size");

        // 2) MIME 타입 확인 (단순 image/* 체크)
        String mime = file.getContentType();
        if (mime == null || !mime.toLowerCase().startsWith("image/"))
            throw new IOException("not an image mime type");
        if (mime.contains("tiff") || mime.contains("ico"))
            throw new IOException("disallowed image type");

        // 3) 매직 넘버(시그니처)로 주요 포맷 식별
        byte[] header;
        try (InputStream is = file.getInputStream()) {
            header = is.readNBytes(16); // 앞부분만 간단히 읽음
        }

        //SVG
        String headerStr = new String(header, StandardCharsets.UTF_8).trim();
        boolean isSvg = headerStr.startsWith("<svg") || headerStr.startsWith("<?xml");

        boolean validSig =
                (header.length >= 3 && (header[0] & 0xFF) == 0xFF && (header[1] & 0xFF) == 0xD8) ||       // JPEG
                        (header.length >= 8 && header[0] == (byte)0x89 && header[1] == 'P' && header[2] == 'N') || // PNG
                        (header.length >= 6 && header[0]=='G' && header[1]=='I' && header[2]=='F') ||             // GIF
                        (header.length >= 12 && header[0]=='R' && header[1]=='I' && header[8]=='W') ||            // WEBP
                        (header.length >= 2 && header[0]=='B' && header[1]=='M') ||                                 // BMP
                        (new String(header, StandardCharsets.UTF_8).trim().startsWith("<svg")) ||                   // SVG (텍스트 시작)
                        (new String(header, StandardCharsets.UTF_8).trim().startsWith("<?xml"));                    // XML 기반 SVG
        if (!validSig) throw new IOException("unknown or invalid image signature");

        // 4) 실제 디코딩 가능한 이미지인지 확인 (SVG는 제외)
        if (!isSvg) {
            try (InputStream is = file.getInputStream()) {
                BufferedImage img = ImageIO.read(is);
                if (img == null) throw new IOException("failed to decode image");
                int w = img.getWidth(), h = img.getHeight();
                if (w <= 0 || h <= 0) throw new IOException("invalid image dimension");
                if (w > MAX_WIDTH || h > MAX_HEIGHT || (long) w * h > MAX_PIXELS)
                    throw new IOException("image too large");
            }
        } else {
            // SVG는 텍스트 기반이므로 간단한 구조 검증만 수행
            if (!headerStr.contains("<svg")) {
                throw new IOException("invalid svg file");
            }
        }
    }
}
