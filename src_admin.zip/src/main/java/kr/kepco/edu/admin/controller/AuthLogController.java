package kr.kepco.edu.admin.controller;

import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import kr.kepco.edu.admin.dto.AuthLogDTO;
import kr.kepco.edu.admin.request.AuthLogReq;
import kr.kepco.edu.admin.response.ApiResponse;
import kr.kepco.edu.admin.response.Page;
import kr.kepco.edu.admin.service.AuthLogService;
import kr.kepco.edu.admin.service.CustomUserDetails;
import kr.kepco.edu.admin.service.JojicService;
import kr.kepco.edu.admin.util.CommonUtil;
import kr.kepco.edu.admin.validation.ErrorCode;
import kr.kepco.edu.admin.validation.RequestGroup;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Tag(name = "09. 권한 이력 관리", description = "권한 이력 관리 ")
@RestController
@Slf4j
@RequestMapping("${base.url}/authLog")
public class AuthLogController {
    @Autowired
    AuthLogService authLogService;

    @Autowired
    JojicService jojicService;

    @Operation(
            summary = "권한 이력 조회",
            description = "권한 이력 조회",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            schema = @Schema(implementation = AuthLogReq.class),
                            examples = {
                                    @ExampleObject(
                                            name = "사번 검색",
                                            value = "{\n" +
                                                    "  \"currentPage\": 1,\n" +
                                                    "  \"pageSize\": 10,\n" +
                                                    "  \"srchType\": \"no\",\n" +
                                                    "  \"srchEmpNo\": \"11112223\",\n" +
                                                    "  \"startDate\": \"2025-01-01\",\n" +
                                                    "  \"endDate\": \"2025-01-31\",\n" +
                                                    "  \"menuNm\": \"접속이력\"\n" +
                                                    "}"
                                    ),
                                    @ExampleObject(
                                            name = "이름 검색",
                                            value = "{\n" +
                                                    "  \"currentPage\": 1,\n" +
                                                    "  \"pageSize\": 10,\n" +
                                                    "  \"srchType\": \"nm\",\n" +
                                                    "  \"srchEmpNm\": [\"홍길동\", \"김철수\"],\n" +
                                                    "  \"startDate\": \"2025-01-01\",\n" +
                                                    "  \"endDate\": \"2025-01-31\",\n" +
                                                    "  \"menuNm\": \"접속이력\"\n" +
                                                    "}"
                                    ),
                                    @ExampleObject(
                                            name = "날짜 + 메뉴명 검색",
                                            value = "{\n" +
                                                    "  \"currentPage\": 1,\n" +
                                                    "  \"pageSize\": 20,\n" +
                                                    "  \"srchType\": \"no\",\n" +
                                                    "  \"srchEmpNo\": \"\",\n" +
                                                    "  \"startDate\": \"2025-03-01\",\n" +
                                                    "  \"endDate\": \"2025-03-31\",\n" +
                                                    "  \"menuNm\": \"교육관리\"\n" +
                                                    "}"
                                    )
                            }
                    )
            )
    )
    @PostMapping(value = "/list")
    public ApiResponse<Page<AuthLogDTO>> getAuthLogList (@AuthenticationPrincipal CustomUserDetails user, @RequestBody @JsonView(RequestGroup.Search.class) AuthLogReq AuthLogReq) {

        if (CommonUtil.isValid(AuthLogReq.getSrchEmpNm()) && AuthLogReq.getSrchType().equals("nm") ){
            List<String> empNos = jojicService.getSeachEmpList(AuthLogReq.getSrchEmpNm());
            if(!CommonUtil.isValid(empNos)) return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
            AuthLogReq.setSrchEmpNos(empNos);
        }
        Page<AuthLogDTO> page = new Page<>(AuthLogReq.getCurrentPage(),AuthLogReq.getPageSize(), authLogService.getAuthogListCnt(AuthLogReq));

        List<AuthLogDTO> AuthLogDTOS = authLogService.getAuthLogList(AuthLogReq,page);
        AuthLogDTOS.forEach(dto -> {
            String code = dto.getLogCtt();
            if (code == null) return;

            switch (code) {
                case "1":
                    dto.setLogCtt("부여");
                    break;
                case "2":
                    dto.setLogCtt("말소");
                    break;
                case "3":
                    dto.setLogCtt("권한변경");
                    break;
                default:
                    dto.setLogCtt("");
            }
        });
        page.setContent(AuthLogDTOS);

        if(CommonUtil.isValid(page.getContent())) {
            return ApiResponse.ok(HttpStatus.OK,page,"OK.");
        } else {
            return ApiResponse.fail(ErrorCode.VAL_LIST_EMPTY);
        }
    }
}
