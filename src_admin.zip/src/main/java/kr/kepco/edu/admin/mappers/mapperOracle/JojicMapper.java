package kr.kepco.edu.admin.mappers.mapperOracle;

import kr.kepco.edu.admin.dto.EmpInfoDTO;
import kr.kepco.edu.admin.response.Page;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Set;

@Mapper
public interface JojicMapper {
     List<String> getSeachEmpList(String searchEmpName);

    List<EmpInfoDTO> selectSeachEmpNmList(Set<String> empNos);

    List<EmpInfoDTO> selectSearchPhoneList(Set<String> empNos);

    List<EmpInfoDTO> selectSearchUserInfoList(Set<String> empNos);

    int getSeachEmpListCnt(String empNm);

    List<EmpInfoDTO> getSeachEmpList2(@Param("empNm") String empNm, @Param("page") Page<EmpInfoDTO> page);
}

