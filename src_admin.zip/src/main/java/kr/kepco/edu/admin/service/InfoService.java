package kr.kepco.edu.admin.service;

import kr.kepco.edu.admin.dto.*;
import kr.kepco.edu.admin.mappers.mapperMaria.InfoMapper;
import kr.kepco.edu.admin.request.InfoDetailReq;
import kr.kepco.edu.admin.request.InfoMasterReq;
import kr.kepco.edu.admin.response.Page;
import kr.kepco.edu.admin.util.CommonUtil;
import kr.kepco.edu.admin.util.EmpNameUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
public class InfoService {

    @Autowired
    InfoMapper infoMapper;

    @Autowired
    EmpNameUtil empNameUtil;

    @Autowired
    FileService fileService;

    public int insertInfoMaster(InfoMasterReq req) { return infoMapper.insertInfoMaster(req); }

    @Transactional
    public boolean insertInfoDetail(InfoDetailReq dto, MultipartFile mFile) {

        int i = infoMapper.insertInfoDetail(dto);

        if(i > 0 && CommonUtil.isValid(dto.getDtlsInfoSerno())) {
            if (CommonUtil.isValid(mFile)) {
                fileService.register(
                        mFile,
                        "info",
                        dto.getDtlsInfoSerno(),
                        "M",
                        0,
                        "info",
                        dto.getFrstRegrEmpno()
                );
            }
        }
        if(i>0) {
            infoMapper.updateInfoMasterSortOrder(dto);
        }
        return i > 0;
    }

    @Transactional
    public boolean updateInfoDetail(InfoDetailReq req, MultipartFile mFile) {

        int i = infoMapper.updateInfoDetail(req);

        if (i > 0) {
            if (CommonUtil.isValid(mFile)) {
                fileService.deleteSearch(req.getDtlsInfoSerno(),req.getLstChgrEmpno(), "M","info",true);
                fileService.register(
                        mFile,
                        "info",
                        req.getDtlsInfoSerno(),
                        "M",
                        0,
                        "info",
                        req.getLstChgrEmpno()
                );
            }
        }
        return i > 0;

    }

    public int deleteInfoMaster(InfoMasterReq req) { return infoMapper.deleteInfoMaster(req); }

    public int deleteInfoDetail(InfoDetailReq req) { return infoMapper.deleteInfoDetail(req); }

    public int selectInfoListCntAll(InfoDetailReq req) { return infoMapper.selectInfoListCntAll(req); }

    public List<InfoDetailDTO> selectInfoListAll(InfoDetailReq req, Page<InfoDetailDTO> page) {

        List<InfoDetailDTO> infoDetailDTOS = infoMapper.selectInfoListAll(req, page);
        empNameUtil.enrichName(
                infoDetailDTOS,
                InfoDetailDTO::getFrstRegrEmpno,
                InfoDetailDTO::setFrstRegrEmpnm,
                " "
        );
        return infoDetailDTOS;
    }

    public InfoDetailDTO selectInfoDetailOne(InfoDetailReq req) {
        InfoDetailDTO infoDetailDTO = infoMapper.selectInfoDetailOne(req);

        empNameUtil.enrichOne(
                infoDetailDTO,
                InfoDetailDTO::getFrstRegrEmpno,
                InfoDetailDTO::setFrstRegrEmpnm,
                " "
        );

        return infoDetailDTO;
    }

    public List<InfoMasterDTO> getInfoMasterList(InfoMasterReq dto) { return infoMapper.selectInfoMasterList(dto);  }

    public Integer getInfoMasterPstnCnt(InfoMasterReq dto) { return infoMapper.selectInfoMasterPstnCnt(dto); }
}
