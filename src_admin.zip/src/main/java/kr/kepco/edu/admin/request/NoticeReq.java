package kr.kepco.edu.admin.request;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.media.Schema;
import kr.kepco.edu.admin.validation.RequestGroup;
import lombok.*;

import javax.validation.constraints.Size;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Schema(name = "NoticeReq", description = "요청 DTO(그룹: Create/Update/Search). viewType으로 응답 형태 지정")
public class NoticeReq extends BaseRequest {

    @Size(max=20)
    @Schema(description = "게시글 번호. Update 필수, Create/Search 금지", example = "12345")
    @JsonView({ RequestGroup.Detail.class })
    private String ntiMttrSerno;

    @Size(max=200)
    @Schema(description = "제목(검색 필터) · Create 필수", example = "공지사항 제목입니다아..")
    @JsonView({ RequestGroup.Search.class })
    private String ntiMttrTitlNm;

    @Size(max=4000)
    @Schema(description = "내용 · Create 필수", example = "공지사항 내용입니다아..")
    private String ntiMttrCtt;

    @Schema(description = "최초등록자 사번", example = "11112223")
    private String frstRegrEmpno;

    @Schema(description = "최종변경자 사번", example = "11112223")
    private String lstChgrEmpno;

    @Size(max=1)
    @Schema(description = "상단고정 여부", example = "N")
    private String upndFixYn;

    @Size(max=5)
    @Schema(description = "상단고정 정렬 여부", example = "null")
    private String upndFixSeqno;

    @Size(max=1)
    @Schema(description = "삭제여부", example = "N")
    private String delYn;

    @Size(max=10)
    @Schema(description = "검색 이름", example = "홍길동")
    @JsonView({ RequestGroup.Search.class })
    private String searchEmpName;

    @Schema(description = "사번 배열", example = "['112233','111111']")
    @JsonIgnore
    private List<String> searchEmpNo;

}
