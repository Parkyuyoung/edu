package kr.kepco.edu.admin.request;


import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.media.Schema;
import kr.kepco.edu.admin.validation.RequestGroup;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Schema(name = "AuthLogReq", description = "권한 이력 조회 요청 DTO")
public class AuthLogReq extends BaseRequest{
    @Schema(description = "시작일자", example = "2025-10-12")
    @JsonView(RequestGroup.Search.class)
    private String startDate;

    @Schema(description = "종료일자", example = "2025-10-31")
    @JsonView(RequestGroup.Search.class)
    private String endDate;

    @Schema(description = "검색타입", example = "nm/no")
    @JsonView(RequestGroup.Search.class)
    private String srchType;

    @Schema(description = "검색값(사번)", example = "11112223")
    @JsonView(RequestGroup.Search.class)
    private String srchEmpNo;

    @Schema(description = "검색값(사번)", example = "11112223")
    @JsonView(RequestGroup.Search.class)
    private List<String> srchEmpNos;

    @Schema(description = "검색값(이름)", example = "11112223")
    @JsonView(RequestGroup.Search.class)
    private String srchEmpNm;

    @Schema(description = "권한코드", example = "SYS")
    @JsonView(RequestGroup.Search.class)
    private String srchEdamsAuthCd;

    @Schema(description = "로그 일련번호", example = "BNR00001")
    @JsonView(RequestGroup.Insert.class)
    private String logSerno;

    @Schema(description = "최초등록일시", example = "2025-10-20T14:30:00")
    @JsonView(RequestGroup.Insert.class)
    private LocalDateTime frstRegDt;

    @Schema(description = "최초등록자사번", example = "EMP00123")
    @JsonView(RequestGroup.Insert.class)
    private String frstRegrEmpno;

    @Schema(description = "최종변경일시", example = "2025-10-20T15:45:00")
    @JsonView(RequestGroup.Insert.class)
    private LocalDateTime lstChgDt;

    @Schema(description = "최종변경자사번", example = "EMP00456")
    @JsonView(RequestGroup.Insert.class)
    private String lstChgrEmpno;

    @Schema(description = "최종변경자이름", example = "김철수")
    @JsonView(RequestGroup.Insert.class)
    private String lstChgrEmpnm;

    @Schema(description = "사번", example = "11111111")
    @JsonView(RequestGroup.Insert.class)
    private String userId;

    @Schema(description = "이름", example = "홍길동")
    @JsonView(RequestGroup.Insert.class)
    private String userNm;

    @Schema(description = "부서", example = "ICT운영처")
    @JsonView(RequestGroup.Insert.class)
    private String userDeptNm;

    @Schema(description = "권한코드", example = "sys")
    @JsonView(RequestGroup.Insert.class)
    private String edamsAuthCd;

    @Schema(description = "로그내용(변경사항)", example = "변경사항 (1:부여, 2:말소, 3: 권한변경) ")
    @JsonView(RequestGroup.Insert.class)
    private String logCtt;

}
