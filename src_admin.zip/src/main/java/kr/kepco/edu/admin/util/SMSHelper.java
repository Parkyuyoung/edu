package kr.kepco.edu.admin.util;

import java.io.*;
import java.net.Socket;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class SMSHelper {


    private String smsIp;
    private String smsPort;

    private String smsClassCode;

    private String smsPwd;

    public SMSHelper() {
        this.smsIp = "100.1.6.75";
        this.smsPort = "7904";
        this.smsClassCode = "E741T";
        this.smsPwd = "E741";
    }

    /**
     * @param smsIp
     * @param smsPort
     * @param smsClassCode
     * @param smsPwd
     */
    public SMSHelper(String smsIp, String smsPort, String smsClassCode,	String smsPwd) {
        this.smsIp = smsIp;
        this.smsPort = smsPort;
        this.smsClassCode = smsClassCode;
        this.smsPwd = smsPwd;
    }


    /**
     * SMS 발송
     * @param receiveNumber :: 수신 번호(여러건은 "|"을 구분자로 사용 - 01011112222|01033334444)
     * replyNumber :: 회신 번호(01055556666)
     * @param message :: SMS 내용(UTF-8)
     * empNo :: 사원번호(8자리)
     * @return :: 발송 결과
     */
    public String sendSMS(String receiveNumber, String message) {

        /**
         * SMS Server 전송 결과 반환값 ::
         *	 - 9999 : 성공(메시지 정상 처리)
         *	 - 1000 : SMS 프로세스 오류(SMS 데몬 프로세스 정지)
         *	 - 1001 : 전송 데이터형식 오류(전송 데이터형식이 규정에 맞지 않을 경우)
         *	 - 1002 : 서버간 전송시간 초과 오류(서버연결후 일정시간동안 데이터 송수신이 이루어지지 않을 경우)
         *	 - 1100 : 데이터베이스 접속 오류(데이터베이스에 접속이 안될 경우)
         *	 - 1101 : 데이터베이스 Query 오류
         *	 - 1200 : 사업소 서비스 오류(사업소코드가 잘못된 경우)
         */


        Map<String, String> params = new HashMap<String, String>();

        // 각 정보필드를 구분할 구분자
        String divChar	= "\0";

        // 고유키(시퀀스)[15+1(구분자)]
        String milliTime = String.valueOf(System.currentTimeMillis()); // 13 자리
        String rndXx = String.valueOf(getRndXX()); // 2 자리
        String smsKey = milliTime + rndXx + divChar;

        // 회신 번호[15+1(구분자)]
        String replyNumber = (String) this.getProps().get("smsReplyNumber");
        replyNumber = getNullToString(replyNumber);
        replyNumber = addSpaceChar(replyNumber, 15) + divChar;

        // SMS 메시지[80+1(구분자)]
        // 테스트용 메시지

        message = getNullToString(message);
        message = addSpaceChar(message, 80) + divChar;


        // 보내는 사람 사원번호[8+1(구분자)]
        String empNo = (String) this.getProps().get("smsEmpno");
        empNo = getNullToString(empNo);
        empNo = addSpaceChar(empNo, 8) + divChar;

        
        
        
        // 참조자수[5+1(구분자)]
        String refCnt = "00000" + divChar;

        // 수신 번호(구분자를 이용하여 배열로 변환)
        // 테스트용 수신번호
		receiveNumber = "01023030220|";
        String[] arrRecvNumber = receiveNumber.split("\\|");

        // SMS Server에 넘겨줄 최종정보
        String result = "FAIL";

        try
        {
            // SMS 서버에 socket 연결
            // START :: SMS Server로 데이터 전송
            //////////////////////////////////////////////////
            for(int i=0; i<arrRecvNumber.length; i++) {
                Socket socket = new Socket(this.smsIp, Integer.parseInt(this.smsPort));

                String smsInfo = null;
                result = "FAIL";

                // 수신 번호[15+1(구분자)]
                String phoneNumber = addSpaceChar(arrRecvNumber[i], 15) + divChar;

                // SMS Server에 넘겨줄 최종정보
                smsInfo = this.smsClassCode + divChar + this.smsPwd + divChar + smsKey + phoneNumber + replyNumber + message + empNo + refCnt;

                // SMS 발송
                OutputStream outStream = socket.getOutputStream();
                OutputStreamWriter outWriter = new OutputStreamWriter(outStream, "EUC-KR");
                BufferedWriter bw = new BufferedWriter(outWriter);
                PrintWriter pw = new PrintWriter(bw, true);
                if(smsInfo != null) {
                    pw.println(smsInfo);
                }

                // 결과 받기
                InputStream inStream = socket.getInputStream();

                String temp = null;
                String resultCode = null;
                byte[] bbufin = null;
                bbufin =  new byte[10];

                try{
                    inStream.read(bbufin, 0, 5);
                    temp =  new String(bbufin, "EUC-KR");
                }catch(IOException e){
                    e.printStackTrace();
                }

                if(temp != null) {
                    resultCode = temp.toString();
                } else {
                    resultCode = "defaultResultCode";
                }
                //result = "SUCCESS";

                if(resultCode.trim().equals("9999")) {
                    result = resultCode.trim();
                } else {
                    result = "FAIL";
                }


                inStream.close();
                outStream.close();

                socket.close();
            } // END :: SMS Server로 데이터 전송

        } catch(IOException ie) {
            result = "FAIL";
        }

        return result;

    }

    /**
     * 빈칸에 공백문자넣기 함수
     * @param inputWord :: 변환할 문장
     * @param maxChar :: 문장 최대길이
     * @return
     */
    public String addSpaceChar(String inputWord, int maxChar){
        String outputWord = "";
        String spaceWord = "";

        int inputWordSize;
        try
        {
            inputWordSize = inputWord.getBytes("EUC-KR").length;
            for(int i=0; i<maxChar-inputWordSize; i++) {
                spaceWord += "\0";
            }
            outputWord = inputWord + spaceWord;
        } catch (UnsupportedEncodingException e) {
            // TODO Auto-generated catch block
        }

        return outputWord;
    }


    /**
     * null 이나 빈문자 처리
     * @param string :: 변환할 문자
     * @return
     */
    public String getNullToString(String string){
        if(string == null || string.equals("") || string.equals(" ")) {
            string = "";
        }

        return string.trim();
    }
    public int getRndXX() {
        Random rnd = new Random();
        rnd.setSeed(new Date().getTime());
        int rndNo = (rnd.nextInt()%6) + 5;
        if(rndNo < 10) {
            rndNo = rndNo + 10;
        }
        return rndNo;
    }

    // Property 조회
    public Map<String, Object> getProps() {
        Map<String, Object> mRslt = new HashMap<String, Object>();

        mRslt.put("smsReplyNumber", "0615376");
        mRslt.put("smsEmpno", "24100171");

        return mRslt;
    }

}