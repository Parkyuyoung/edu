package kr.kepco.edu.admin.mappers.mapperMaria;

import kr.kepco.edu.admin.dto.UserDTO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface MariaUserMapper {
    UserDTO loginUser(String empNo);

    List<String> selectMenuIds(String edamsAuthCd);
}
