package kr.kepco.edu.admin;

import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
public class ApiController {
    @GetMapping("/health")
    public Map<String, Object> h() {
        return java.util.Map.of("service", "user-service", "status", "UP");
    }
}