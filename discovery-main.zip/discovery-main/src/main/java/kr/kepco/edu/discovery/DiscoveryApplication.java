package kr.kepco.edu.discovery;

import org.springframework.boot.*;
        import org.springframework.boot.autoconfigure.*;
        import org.springframework.cloud.netflix.eureka.server.*;

@EnableEurekaServer
@SpringBootApplication
public class DiscoveryApplication {
    public static void main(String[] args) {
        SpringApplication.run(DiscoveryApplication.class, args);
    }
}