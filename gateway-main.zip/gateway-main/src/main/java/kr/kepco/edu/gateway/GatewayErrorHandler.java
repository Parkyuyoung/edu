package kr.kepco.edu.gateway;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.web.reactive.error.ErrorWebExceptionHandler;
import org.springframework.core.annotation.Order;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.server.*;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

@Component
@Order(-2) // 기본 핸들러보다 앞서서 처리
public class GatewayErrorHandler implements ErrorWebExceptionHandler {
    private final ObjectMapper om = new ObjectMapper();

    @Override
    public Mono<Void> handle(ServerWebExchange exchange, Throwable ex) {
        HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
        String message = "시스템 오류가 발생했습니다. 관리자에게 문의하세요.";
        String code = "INTERNAL_SERVER_ERROR";

        System.out.println("ex >>> " + ex.getMessage());

        if (ex instanceof org.springframework.cloud.gateway.support.NotFoundException) {
            status = HttpStatus.NOT_FOUND;
            message = "요청하신 페이지를 찾을 수 없습니다.";
            code = "NOT_FOUND";
        } else if (ex instanceof ResponseStatusException) {
            ResponseStatusException rse = (ResponseStatusException) ex;
            HttpStatus s = rse.getStatus();
            if (s != null) {
                status = s;
                code = s.name();
                if (rse.getReason() != null) message = rse.getReason();
            }
        } else if (ex instanceof MethodNotAllowedException) {
            status = HttpStatus.METHOD_NOT_ALLOWED;
            message = "허용되지 않은 요청 방식입니다.";
            code = "METHOD_NOT_ALLOWED";
        } else if (ex instanceof org.springframework.security.access.AccessDeniedException) {
            status = HttpStatus.FORBIDDEN;
            message = "접근 권한이 없습니다.";
            code = "FORBIDDEN";
        } else if (ex instanceof ServerWebInputException) {
            status = HttpStatus.BAD_REQUEST;
            message = "요청 데이터가 유효하지 않습니다.";
            code = "BAD_REQUEST";
        } else {
            String name = ex.getClass().getSimpleName();
            if (name.contains("Timeout")) {
                status = HttpStatus.GATEWAY_TIMEOUT;
                message = "백엔드 응답이 지연되었습니다.";
                code = "GATEWAY_TIMEOUT";
            } else if (name.contains("Connect") || name.contains("IO")) {
                status = HttpStatus.BAD_GATEWAY;
                message = "백엔드 연결에 실패했습니다.";
                code = "BAD_GATEWAY";
            }
        }

        Map<String, Object> body = new HashMap<>();
        body.put("success", false);
        body.put("message", message);
        body.put("code", code);
        body.put("status", status.value());
        body.put("path", exchange.getRequest().getPath().value());
        body.put("method", exchange.getRequest().getMethodValue());

        byte[] json;
        try {
            json = om.writeValueAsBytes(body);
        } catch (Exception e) {
            json = "{\"success\":false}".getBytes(StandardCharsets.UTF_8);
        }

        var res = exchange.getResponse();
        res.setStatusCode(status);
        res.getHeaders().setContentType(MediaType.APPLICATION_JSON);
        return res.writeWith(Mono.just(res.bufferFactory().wrap(json)));
    }
}
