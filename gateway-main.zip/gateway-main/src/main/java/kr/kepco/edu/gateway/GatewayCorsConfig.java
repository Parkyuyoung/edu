package kr.kepco.edu.gateway;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.reactive.CorsWebFilter;
import org.springframework.web.cors.reactive.UrlBasedCorsConfigurationSource;
import org.springframework.web.cors.CorsConfiguration;

import java.util.Arrays;

@Configuration
public class GatewayCorsConfig {
    @Bean
    public CorsWebFilter corsWebFilter() {
        CorsConfiguration c = new CorsConfiguration();
        c.setAllowedOriginPatterns(Arrays.asList(
                "http://127.0.0.1:*",
                "http://localhost:*",
                "https://web.example.com",   // 운영 웹서버 도메인/주소로 교체
                "https://203.0.113.50"       // 운영 IP로 접근한다면
        ));
        c.setAllowedMethods(Arrays.asList("POST", "OPTIONS")); // API는 POST만, preflight 허용
        c.setAllowedHeaders(Arrays.asList("Authorization", "Content-Type", "*"));
        c.setAllowCredentials(false);     // JWT 헤더 방식이면 false 권장
        c.setMaxAge(3600L);               // preflight 캐시(초)


        UrlBasedCorsConfigurationSource src = new UrlBasedCorsConfigurationSource();
        src.registerCorsConfiguration("/**", c);
        return new CorsWebFilter(src);
    }
}
