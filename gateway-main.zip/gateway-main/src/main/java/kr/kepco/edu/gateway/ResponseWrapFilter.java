//package kr.kepco.edu.gateway;
//
//import com.fasterxml.jackson.databind.ObjectMapper;
//import org.reactivestreams.Publisher;
//import org.springframework.cloud.gateway.filter.GlobalFilter;
//import org.springframework.core.Ordered;
//import org.springframework.http.*;
//import org.springframework.http.server.reactive.*;
//import org.springframework.stereotype.Component;
//import org.springframework.web.server.ServerWebExchange;
//import reactor.core.publisher.Flux;
//import reactor.core.publisher.Mono;
//import org.springframework.core.io.buffer.DataBuffer;
//
//import java.util.HashMap;
//import java.util.Map;
//
//@Component
//public class ResponseWrapFilter implements GlobalFilter, Ordered {
//    private final ObjectMapper om = new ObjectMapper();
//
//    @Override
//    public Mono<Void> filter(ServerWebExchange exchange, org.springframework.cloud.gateway.filter.GatewayFilterChain chain) {
//        // 프리플라이트는 건드리지 않음 (CORS 응답 이미 커밋)
//        if ("OPTIONS".equalsIgnoreCase(exchange.getRequest().getMethodValue())) {
//            return chain.filter(exchange);
//        }
//
//        ServerHttpResponse original = exchange.getResponse();
//
//        ServerHttpResponseDecorator decorated = new ServerHttpResponseDecorator(original) {
//            @Override
//            public Mono<Void> writeWith(Publisher<? extends DataBuffer> body) {
//                // 이미 커밋된 응답은 손대지 않음
//                if (original.isCommitted()) {
//                    return super.writeWith(body);
//                }
//                HttpStatus status = getStatusCode() != null ? getStatusCode() : HttpStatus.OK;
//
//                if (status.is4xxClientError() || status.is5xxServerError()) {
//                    Map<String, Object> payload = new HashMap<>();
//                    payload.put("success", false);
//                    payload.put("message", status.is5xxServerError()
//                            ? "시스템 오류가 발생했습니다. 관리자에게 문의하세요."
//                            : "요청 처리가 실패했습니다.");
//                    payload.put("code", status.name());
//                    payload.put("status", status.value());
//                    payload.put("path", exchange.getRequest().getPath().value());
//                    payload.put("method", exchange.getRequest().getMethodValue());
//
//                    byte[] json;
//                    try {
//                        json = om.writeValueAsBytes(payload);
//                    } catch (Exception e) {
//                        json = new byte[0];
//                    }
//
//                    getHeaders().setContentType(MediaType.APPLICATION_JSON);
//                    // Content-Length는 설정하지 않음 (chunked로 안전)
//                    return super.writeWith(Mono.just(bufferFactory().wrap(json)));
//                }
//                return super.writeWith(body);
//            }
//
//            @Override
//            public Mono<Void> writeAndFlushWith(Publisher<? extends Publisher<? extends DataBuffer>> body) {
//                return writeWith(Flux.from(body).flatMapSequential(p -> p));
//            }
//        };
//
//        return chain.filter(exchange.mutate().response(decorated).build());
//    }
//
//    // 순서 중요: NettyWriteResponseFilter(-1) 바로 앞에서 동작하도록 -2
//    @Override
//    public int getOrder() {
//        return -2;
//    }
//}
