package kr.kepco.edu.gateway;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.*;
import org.springframework.web.reactive.function.server.*;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;

/**
 * 게이트웨이 공통 라우트
 * - gw-notmethod : POST/OPTIONS 외 메서드 → 405 JSON
 * - gw-notfound  : 어떤 라우트에도 매칭 안되면 → 404 JSON
 *
 * 주의: 기존 라우트와 함께 동작합니다.
 *  - notmethod는 order(-100)로 "먼저" 검사되어 GET/PUT/DELETE 등은 바로 405로 포워드
 *  - notfound는 order(9999)로 "마지막"에 매칭 실패를 404로 포워드
 */
@Configuration
public class GatewayCatchAllConfig {

    // POST/OPTIONS 외 모든 메서드를 한 번에 정의
    private static final String[] NOT_ALLOWED_METHODS = new String[] {
            "GET", "PUT", "DELETE", "PATCH", "HEAD", "TRACE"
    };

    @Bean
    public RouteLocator catchAllRoutes(RouteLocatorBuilder builder) {
        return builder.routes()
                // 1) 메서드 금지(POST/OPTIONS 외) → 405
                .route("gw-notmethod", r -> r
                        .order(-100) // 일반 라우트보다 먼저 검사
                        .method(NOT_ALLOWED_METHODS)
                        .and()
                        .path("/**")
                        .uri("forward:/__gw_notmethod"))

                // 2) 라우트 미스 전역 캐치올 → 404
                .route("gw-notfound", r -> r
                        .order(9999) // 맨 마지막
                        .predicate(p -> true)
                        .uri("forward:/__gw_notfound"))
                .build();
    }

    @Bean
    public RouterFunction<ServerResponse> errorEndpoints() {
        return RouterFunctions.route()
                // 405 응답 바디
                .GET("/__gw_notmethod", this::methodNotAllowed) // 만약 직접 접근 시에도 동일 바디
                .POST("/__gw_notmethod", this::methodNotAllowed)
                .route(RequestPredicates.path("/__gw_notmethod"), this::methodNotAllowed)

                // 404 응답 바디
                .GET("/__gw_notfound", this::notFound)
                .POST("/__gw_notfound", this::notFound)
                .route(RequestPredicates.path("/__gw_notfound"), this::notFound)
                .build();
    }

    private Mono<ServerResponse> methodNotAllowed(ServerRequest req) {
        Map<String, Object> body = new HashMap<>();
        body.put("success", false);
        body.put("message", "허용되지 않은 요청 방식입니다.");
        body.put("code", "METHOD_NOT_ALLOWED");
        body.put("status", 405);
        body.put("path", req.path());
        body.put("method", req.methodName());

        return ServerResponse.status(HttpStatus.METHOD_NOT_ALLOWED)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body);
    }

    private Mono<ServerResponse> notFound(ServerRequest req) {
        Map<String, Object> body = new HashMap<>();
        body.put("success", false);
        body.put("message", "요청하신 페이지를 찾을 수 없습니다.");
        body.put("code", "NOT_FOUND");
        body.put("status", 404);
        body.put("path", req.path());
        body.put("method", req.methodName());

        return ServerResponse.status(HttpStatus.NOT_FOUND)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body);
    }
}
