package kr.kepco.edu.gateway;

import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;

@SpringBootApplication
public class GatewayApplication {
    public static void main(String[] a) {
        SpringApplication.run(GatewayApplication.class, a);
    }
}