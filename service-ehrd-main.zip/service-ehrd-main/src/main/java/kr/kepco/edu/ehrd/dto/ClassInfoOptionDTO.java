package kr.kepco.edu.ehrd.dto;


import lombok.Data;

@Data
public class ClassInfoOptionDTO {

    /** 과정 코드 */
    private String eehrdsCorsCd;

    /** 전송순서 */
    private String trnsSeqo;

    /** 교육 과정명 */
    private String crcmNm;

    /** 교육 분류 코드 */
    private String eehrdsCrcmCgCd;

    /** 교육 분류명 */
    private String eehrdsCrcmCgNm;

    /** 주관 부서명 */
    private String hmngDeptNm;

    /** 사업 이벤트명 */
    private String bizEvntNm;

    /** 교육 신청 시작일 (YYYYMMDD) */
    private String eduAplStrtYmd;

    /** 교육 신청 종료일 (YYYYMMDD) */
    private String eduAplEndYmd;

    /** 교육 방법 코드 */
    private String eehrdsEduTpClCd;

    /** 교육 방법명 */
    private String eehrdsEduTpClNm;

    /** 담당자명(사용자 이름) */
    private String userEmpno;

    /** 교육 정원 */
    private Integer eduPrnoCnt;


}