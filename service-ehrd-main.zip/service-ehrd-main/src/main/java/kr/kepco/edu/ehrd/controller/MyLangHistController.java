package kr.kepco.edu.ehrd.controller;

import kr.kepco.edu.ehrd.dto.LangOptionDTO;
import kr.kepco.edu.ehrd.dto.LangHistOptionDTO;
import kr.kepco.edu.ehrd.dto.SelectOptionDTO;
import kr.kepco.edu.ehrd.req.CodeRequest;
import kr.kepco.edu.ehrd.req.MyLangHistRequest;
import kr.kepco.edu.ehrd.service.MyLangHistService;
import kr.kepco.edu.ehrd.util.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/ehrd/myLangHistory")
public class MyLangHistController {

    @Autowired
    MyLangHistService myLangHistService;

    @PostMapping("/getLangList")
    public List<LangOptionDTO> getLangList(@RequestBody(required = false) Map<String,Object> param) {
        return myLangHistService.selectLangList();
    }

    @PostMapping("/getComList")
    public List<LangOptionDTO> getComList(@RequestBody CodeRequest codeRequest) {
        return myLangHistService.selectComList(codeRequest);
    }

    @PostMapping("/getMyLangHistList")
    public Page<LangHistOptionDTO> getMyLangHistList(@RequestBody MyLangHistRequest req) {
        // 총 건수
        int totalCount = myLangHistService.selectMyLangHistListCnt(req);


        System.out.println("test >>> " + req.toString());
        // 페이징 객체 구성
        Page<LangHistOptionDTO> pageReq = new Page<>(req.getCurrentPage(), req.getPageSize(), totalCount);

        // 목록 조회
        List<LangHistOptionDTO> list = myLangHistService.selectMyLangHistList(req,pageReq);

        // 응답 페이지에 컨텐츠 세팅
        Page<LangHistOptionDTO> page = new Page<>(req.getCurrentPage(), req.getPageSize(), totalCount);

        page.setContent(list);

        return page;
    }
}
