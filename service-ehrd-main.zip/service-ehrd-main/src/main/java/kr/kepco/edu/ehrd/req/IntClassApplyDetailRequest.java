package kr.kepco.edu.ehrd.req;

import lombok.Data;

@Data
public class IntClassApplyDetailRequest {
    private String year;
    private String bizevntnm;
    private String seqno;
    private String crcmcd;

}