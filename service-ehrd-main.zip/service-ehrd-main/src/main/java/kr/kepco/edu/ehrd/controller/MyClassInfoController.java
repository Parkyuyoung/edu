package kr.kepco.edu.ehrd.controller;

import kr.kepco.edu.ehrd.dto.ClassDateOptionDTO;
import kr.kepco.edu.ehrd.dto.ClassInfoDetailDTO;
import kr.kepco.edu.ehrd.dto.ClassInfoOptionDTO;
import kr.kepco.edu.ehrd.req.ClassDateRequest;
import kr.kepco.edu.ehrd.req.MyClassInfoDetailRequest;
import kr.kepco.edu.ehrd.req.MyClassInfoRequest;
import kr.kepco.edu.ehrd.service.MyClassInfoService;
import kr.kepco.edu.ehrd.util.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/ehrd/myClassInfo")
public class MyClassInfoController {

    @Autowired
    MyClassInfoService myClassInfoService;

    @PostMapping("/getDateList")
    public List<ClassDateOptionDTO> getDateList(@RequestBody ClassDateRequest infoRequest) {
        return myClassInfoService.selectDateList(infoRequest);
    }

    @PostMapping("/getMyClassInfoList")
    public Page<ClassInfoOptionDTO> getMyClassInfoList(@RequestBody MyClassInfoRequest req) {
        // 총 건수
        int totalCount = myClassInfoService.selectMyClassInfoListCnt(req);

        // 페이징 객체 구성
        Page<ClassInfoOptionDTO> pageReq = new Page<>(req.getCurrentPage(), req.getPageSize(), totalCount);

        System.out.println("test >>> " + req.toString()+"//// pageReq >>> "+pageReq.toString());
        // 목록 조회
        List<ClassInfoOptionDTO> list = myClassInfoService.selectMyClassInfoList(req,pageReq);

        // 응답 페이지에 컨텐츠 세팅
        Page<ClassInfoOptionDTO> page = new Page<>(req.getCurrentPage(), req.getPageSize(), totalCount);

        page.setContent(list);

        return page;
    }

    @PostMapping("/getMyClassInfoDetail")
    public ClassInfoDetailDTO getMyClassInfoDetail(@RequestBody MyClassInfoDetailRequest infoDetailRequest) {
        return myClassInfoService.selectMyClassInfoDetail(infoDetailRequest);
    }
}
