package kr.kepco.edu.ehrd.dto;


import lombok.Data;

@Data
public class ClassDateOptionDTO {

    private String bizEvntNm;
    private String eehrdsObjAbrvCd;
    private String crcmNm;

}