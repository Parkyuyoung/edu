package kr.kepco.edu.ehrd.req;

import lombok.Data;

@Data
public class IntClassApplyRequest {
    private String year;
    private String month;
    private String crcmcd;
    private String pgnm;

    private int currentPage = 1;
    private int pageSize = 10;
}