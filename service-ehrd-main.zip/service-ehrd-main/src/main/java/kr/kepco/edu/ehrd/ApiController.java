package kr.kepco.edu.ehrd;

import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
public class ApiController {
    @GetMapping("/health")
    public Map<String, Object> h() {
        return java.util.Map.of("service", "ehrd-service", "status", "UP");
    }
}