package kr.kepco.edu.ehrd.req;

import lombok.Data;

@Data
public class MyClassInfoRequest extends BaseRequest {
    private String year;
    private String month;
    private String pgnm;
    private String abrvcd;
    private String empNo;

}