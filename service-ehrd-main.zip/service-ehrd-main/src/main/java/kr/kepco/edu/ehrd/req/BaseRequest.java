package kr.kepco.edu.ehrd.req;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaseRequest {

    private int currentPage = 1;

    private int pageSize = 5;

}