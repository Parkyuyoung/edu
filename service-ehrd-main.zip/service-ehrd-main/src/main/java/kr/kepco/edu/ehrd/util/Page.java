package kr.kepco.edu.ehrd.util;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Value;

import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor     // ★ 필수
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Page<T> {

    @Value("${page.pageSize}")
    private String limit;

    private List<T> content;       // 현재 페이지의 데이터
    private int currentPage = 1;       // 현재 페이지 번호 (1부터 시작)
    private int pageSize;          // 페이지 크기
    private long totalElements;    // 전체 레코드 수
    private int totalPages;        // 전체 페이지 수

    public Page(int currentPage, int pageSize, long totalElements) {
        this.currentPage = currentPage;
        this.pageSize = pageSize;
        this.totalElements = totalElements;
        this.totalPages = (int) Math.ceil((double) totalElements / pageSize);
    }
    
    public Page(int currentPage, int pageSize) {
        this.currentPage = currentPage;
        this.pageSize = pageSize;
    }

    public Page(Map<String,Object> param, long totalElements) {
        this.currentPage =  CommonUtil.isValid(param.get("currentPage")) ? Integer.parseInt(param.get("currentPage").toString()) : 1;
        this.pageSize = CommonUtil.isValid(param.get("pageSize")) ? Integer.parseInt(param.get("pageSize").toString()) : 5;
        this.totalElements = totalElements;
        this.totalPages = (int) Math.ceil((double) totalElements / pageSize);
    }
}