package kr.kepco.edu.ehrd.req;

import lombok.Data;

@Data
public class ClassDateRequest {
    private String year;
    private String month;

}