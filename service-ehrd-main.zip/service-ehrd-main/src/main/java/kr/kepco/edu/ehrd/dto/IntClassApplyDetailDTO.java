package kr.kepco.edu.ehrd.dto;


import lombok.Data;

@Data
public class IntClassApplyDetailDTO {

    private String crcmDetailNm;          // 과정명 (과정ID 포함)
    private String eehrdsCrcmCgCd;         // 교육분류 코드
    private String eehrdsCrcmCgNm;         // 교육분류명
    private String abltCgCtt;              // 역량분류
    private String hmngDeptNm;             // 주관부서명
    private String tchqPrfsrId;             // 담당교수ID
    private String tchqPrfsrNm;             // 담당교수명
    private String eduDdCnt;               // 교육일수
    private Integer eduPrnoCnt;             // 정원(교육인원)
    private String eehrdsCorsCd;            // 과정코드
    private String eduGoalCtt;              // 교육목표
    private String eduCtt;                  // 교육내용
    private String eduTgtCtt;               // 교육대상

    private String pseqNo;                  // 차수
    private String eduStatus;               // 상태
    private String eduYmd;                  // 교육기간
    private String eduAplYmd;               // 교육신청기간
    private String eduOflnYmd;              // 집합교육기간
    private String eehrdsEduTpClCd;          // 교육방법 코드
    private String eduOnlnYmd;              // 화상교육기간
    private String eehrdsEduTpClNm;          // 교육방법명
    private String eduStrtHmsNm;             // 교육시간(오전/오후/전일)
    private Integer eduPrnoTotalCnt;         // 전체신청 인원
    private String eduCheckCnt;              // 수강확정 인원
    private String bizTpId;                  // 비즈니스유형ID
    private String bizGrpId;                 // 비즈니스그룹ID
    private String bizEvntNm;                // 비즈니스이벤트명
    private String trnsSeqo;                 // 전송일련번호



}