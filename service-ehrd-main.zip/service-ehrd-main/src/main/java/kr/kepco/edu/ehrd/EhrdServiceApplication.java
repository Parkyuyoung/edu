package kr.kepco.edu.ehrd;

import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;

@SpringBootApplication
public class EhrdServiceApplication {
    public static void main(String[] a) {
        SpringApplication.run(EhrdServiceApplication.class, a);
    }
}