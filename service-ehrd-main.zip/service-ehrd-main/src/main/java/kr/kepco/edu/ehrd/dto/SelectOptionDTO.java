package kr.kepco.edu.ehrd.dto;


import lombok.Data;

@Data
public class SelectOptionDTO {
    private String label;
    private String value;
}