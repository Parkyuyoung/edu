package kr.kepco.edu.ehrd.dto;


import lombok.Data;

@Data
public class ClassInfoDetailDTO {

    private String eehrdsCorsCd;
    private Integer trnsSeqo;
    private String crcmNm;
    private String bizEvntNm;
    private String eehrdsEduTpClCd;        // 교육방법 코드
    private String eehrdsEduTpClNm;        // 교육방법명
    private String eduAplStrtYmd;          // 교육기간 시작일
    private String eduAplEndYmd;           // 교육기간 종료일
    private Integer eduDdCnt;              // 교육일수
    private String eduGoalCtt;             // 교육목표
    private String eduCtt;                 // 교육내용
    private String hmngDeptNm;             // 교육부서
    private String professor;              // 담당교수
    private String ldtgYn;                 // 합숙여부
    private String persnTabletUtilPsblYn;  // 개인태블릿 활용가능여부
    private String eehrdsEduStsCd;          // 승인코드
    private String eehrdsEduStsSignNm;      // 결재
    private String eehrdsEduStsApprovalNm; // 승인
    private String chgrNm;                 // 사용자 이름
    private String userEmpno;              // 사용자 사번
    private Integer eduPrnoCnt;             // 정원


}