package kr.kepco.edu.ehrd.req;

import lombok.Data;

@Data
public class MyClassInfoDetailRequest {
    private String abrvcd;
    private String empNo;
    private String seqno;
    private String bizevntnm;

}