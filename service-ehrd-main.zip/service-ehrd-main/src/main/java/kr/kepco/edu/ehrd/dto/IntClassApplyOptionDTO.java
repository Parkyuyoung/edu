package kr.kepco.edu.ehrd.dto;


import lombok.Data;

@Data
public class IntClassApplyOptionDTO {

    private String trnsSeqo;              // 과정차수 일련번호
    private String eehrdsCrcmCgCd;        // 교육분류 코드
    private String eehrdsCrcmCgNm;        // 교육분류명

    private String eehrdsCorsCd;          // 과정코드

    private String eehrdsEduTpClCd;       // 교육방법 코드
    private String eehrdsEduTpClNm;       // 교육방법명

    private String crcmNm;                // 과정명

    private String pseqNo;                // 차수 (예: 2025-1)

    private String tchgPrfsrId;           // 담당교수 ID
    private String tchgPrfsrNm;           // 담당교수명

    private String eduYmd;                // 교육기간 (YYYY.MM.DD~YYYY.MM.DD)
    private String eduStrtHmsNm;           // 교육시간 구분 (오전/오후/전일)

    private String eduAplYmd;              // 교육신청기간

    private String eduDdCnt;               // 교육일수 (n 일)

    private Integer eduPrnoCnt;            // 정원

    private String bizTpId;                // 비즈니스유형ID
    private String bizGrpId;               // 비즈니스그룹ID

    private String hmngDeptNm;             // 주관부서명
    private String bizEvntNm;              // 비즈니스이벤트명


}