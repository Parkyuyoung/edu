package kr.kepco.edu.ehrd.dto;


import lombok.Data;

@Data
public class LangHistOptionDTO {
    private String userEmpno;
    private String eduAplStrtYmd;
    private String eduAplEndYmd;
    private String eehrdsLangClCd;
    private String eehrdsComCd;
    private String eehrdsUppoComCd;
    private String comCdNm;
    private int lnglcScor;
    private int lngrcScor;
    private int sumScor;
    private String eehrdsLangAprvStsCd;
    private String eehrdsLangAprvStsNm;
}