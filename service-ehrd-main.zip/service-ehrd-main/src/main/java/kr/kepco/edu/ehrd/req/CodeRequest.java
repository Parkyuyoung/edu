package kr.kepco.edu.ehrd.req;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Data
public class CodeRequest {
    private String eehrdsLangClCd;
    private String eehrdsComCd;
}