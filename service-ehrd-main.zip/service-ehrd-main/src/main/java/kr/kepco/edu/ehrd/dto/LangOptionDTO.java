package kr.kepco.edu.ehrd.dto;


import lombok.Data;

@Data
public class LangOptionDTO {
    private String eehrdsLangClCd;
    private String eehrdsComCd;
    private String eehrdsUppoComCd;
    private String comCdNm;
}
