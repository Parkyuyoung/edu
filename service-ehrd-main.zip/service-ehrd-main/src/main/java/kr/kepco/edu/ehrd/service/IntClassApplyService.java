package kr.kepco.edu.ehrd.service;

import kr.kepco.edu.ehrd.dto.*;
import kr.kepco.edu.ehrd.mappers.mapperMaria.IntClassApplyMapper;
import kr.kepco.edu.ehrd.req.IntClassApplyDetailRequest;
import kr.kepco.edu.ehrd.req.IntClassApplyRequest;
import kr.kepco.edu.ehrd.util.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IntClassApplyService {

    @Autowired
    IntClassApplyMapper intClassApplyMapper;

    public List<SelectOptionDTO> selectCategoryList() {
        return intClassApplyMapper.selectCategoryList();
    }

    public int selectIntClassApplyListCnt(IntClassApplyRequest intClassApplyRequest) {
        return intClassApplyMapper.selectIntClassApplyListCnt(intClassApplyRequest);
    }

    public List<IntClassApplyOptionDTO> selectIntClassApplyList(IntClassApplyRequest intClassApplyRequest, Page<IntClassApplyOptionDTO> pageReq) {
        return intClassApplyMapper.selectIntClassApplyList(intClassApplyRequest,pageReq);
    }

    public IntClassApplyDetailDTO selectIntClassApplyDetail(IntClassApplyDetailRequest intClassApplyDetailRequest) {
        return intClassApplyMapper.selectIntClassApplyDetail(intClassApplyDetailRequest);
    }

}
