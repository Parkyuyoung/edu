package kr.kepco.edu.ehrd.mappers.mapperMaria;


import kr.kepco.edu.ehrd.dto.LangHistOptionDTO;
import kr.kepco.edu.ehrd.dto.LangOptionDTO;
import kr.kepco.edu.ehrd.req.CodeRequest;
import kr.kepco.edu.ehrd.req.MyLangHistRequest;
import kr.kepco.edu.ehrd.util.Page;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface MyLangHistMapper {
    List<LangOptionDTO> selectLangList();

    List<LangOptionDTO> selectComList(CodeRequest codeRequest);

    int selectMyLangHistListCnt(@Param("param") MyLangHistRequest myLangHistRequest);

    List<LangHistOptionDTO> selectMyLangHistList(@Param("param") MyLangHistRequest myLangHistRequest,@Param("page") Page<LangHistOptionDTO> pageReq);
}
