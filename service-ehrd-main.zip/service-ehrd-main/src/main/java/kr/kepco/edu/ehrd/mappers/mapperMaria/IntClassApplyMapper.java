package kr.kepco.edu.ehrd.mappers.mapperMaria;


import kr.kepco.edu.ehrd.dto.*;
import kr.kepco.edu.ehrd.req.IntClassApplyDetailRequest;
import kr.kepco.edu.ehrd.req.IntClassApplyRequest;
import kr.kepco.edu.ehrd.util.Page;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface IntClassApplyMapper {
    List<SelectOptionDTO> selectCategoryList();

    int selectIntClassApplyListCnt(@Param("param") IntClassApplyRequest intClassApplyRequest);

    List<IntClassApplyOptionDTO> selectIntClassApplyList(@Param("param") IntClassApplyRequest intClassApplyRequest, @Param("page") Page<IntClassApplyOptionDTO> pageReq);

    IntClassApplyDetailDTO selectIntClassApplyDetail(IntClassApplyDetailRequest intClassApplyDetailRequest);

}
