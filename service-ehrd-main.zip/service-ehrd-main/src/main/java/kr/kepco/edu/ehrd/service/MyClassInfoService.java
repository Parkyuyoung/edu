package kr.kepco.edu.ehrd.service;

import kr.kepco.edu.ehrd.dto.ClassDateOptionDTO;
import kr.kepco.edu.ehrd.dto.ClassInfoDetailDTO;
import kr.kepco.edu.ehrd.dto.ClassInfoOptionDTO;
import kr.kepco.edu.ehrd.mappers.mapperMaria.MyClassInfoMapper;
import kr.kepco.edu.ehrd.req.ClassDateRequest;
import kr.kepco.edu.ehrd.req.MyClassInfoDetailRequest;
import kr.kepco.edu.ehrd.req.MyClassInfoRequest;
import kr.kepco.edu.ehrd.util.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MyClassInfoService {

    @Autowired
    MyClassInfoMapper myClassInfoMapper;

    public List<ClassDateOptionDTO> selectDateList(ClassDateRequest infoRequest) {
        return myClassInfoMapper.selectDateList(infoRequest);
    }

    public int selectMyClassInfoListCnt(MyClassInfoRequest myClassInfoRequest) {
        return myClassInfoMapper.selectMyClassInfoListCnt(myClassInfoRequest);
    }

    public List<ClassInfoOptionDTO> selectMyClassInfoList(MyClassInfoRequest myClassInfoRequest, Page<ClassInfoOptionDTO> pageReq) {
        return myClassInfoMapper.selectMyClassInfoList(myClassInfoRequest,pageReq);
    }

    public ClassInfoDetailDTO selectMyClassInfoDetail(MyClassInfoDetailRequest infoDetailRequest) {
        return myClassInfoMapper.selectMyClassInfoDetail(infoDetailRequest);
    }

}
