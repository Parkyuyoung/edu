package kr.kepco.edu.ehrd.mappers.mapperMaria;


import kr.kepco.edu.ehrd.dto.ClassDateOptionDTO;
import kr.kepco.edu.ehrd.dto.ClassInfoDetailDTO;
import kr.kepco.edu.ehrd.dto.ClassInfoOptionDTO;
import kr.kepco.edu.ehrd.req.*;
import kr.kepco.edu.ehrd.util.Page;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface MyClassInfoMapper {
    List<ClassDateOptionDTO> selectDateList(ClassDateRequest infoRequest);

    int selectMyClassInfoListCnt(@Param("param") MyClassInfoRequest myClassInfoRequest);

    List<ClassInfoOptionDTO> selectMyClassInfoList(@Param("param") MyClassInfoRequest myClassInfoRequest, @Param("page") Page<ClassInfoOptionDTO> pageReq);

    ClassInfoDetailDTO selectMyClassInfoDetail(MyClassInfoDetailRequest infoDetailRequest);

}
