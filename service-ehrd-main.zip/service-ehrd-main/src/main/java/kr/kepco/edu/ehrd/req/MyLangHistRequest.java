package kr.kepco.edu.ehrd.req;

import lombok.Data;

@Data
public class MyLangHistRequest extends CodeRequest{
    private String empNo;
    private String year;

    private int currentPage = 1;
    private int pageSize = 5;

}