package kr.kepco.edu.ehrd.service;

import kr.kepco.edu.ehrd.dto.LangHistOptionDTO;
import kr.kepco.edu.ehrd.dto.LangOptionDTO;
import kr.kepco.edu.ehrd.mappers.mapperMaria.MyLangHistMapper;
import kr.kepco.edu.ehrd.req.CodeRequest;
import kr.kepco.edu.ehrd.req.MyLangHistRequest;
import kr.kepco.edu.ehrd.util.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MyLangHistService {

    @Autowired
    MyLangHistMapper myLangHistMapper;

    public List<LangOptionDTO> selectLangList() {
        return myLangHistMapper.selectLangList();
    }

    public List<LangOptionDTO> selectComList(CodeRequest codeRequest) {
        return myLangHistMapper.selectComList(codeRequest);
    }

    public int selectMyLangHistListCnt(MyLangHistRequest myLangHistRequest) {
        return myLangHistMapper.selectMyLangHistListCnt(myLangHistRequest);
    }

    public List<LangHistOptionDTO> selectMyLangHistList(MyLangHistRequest myLangHistRequest, Page<LangHistOptionDTO> pageReq) {
        return myLangHistMapper.selectMyLangHistList(myLangHistRequest,pageReq);
    }
}
