package kr.kepco.edu.ehrd.controller;

import kr.kepco.edu.ehrd.dto.*;
import kr.kepco.edu.ehrd.req.IntClassApplyDetailRequest;
import kr.kepco.edu.ehrd.req.IntClassApplyRequest;
import kr.kepco.edu.ehrd.service.IntClassApplyService;
import kr.kepco.edu.ehrd.util.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/ehrd/intClassApply")
public class IntClassApplyController {

    @Autowired
    IntClassApplyService intClassApplyService;

    @PostMapping("/getCategoryList")
    public List<SelectOptionDTO> getCategoryList(@RequestBody(required = false) Map<String,Object> param) {
        return intClassApplyService.selectCategoryList();
    }

    @PostMapping("/getIntClassApplyList")
    public Page<IntClassApplyOptionDTO> getIntClassApplyList(@RequestBody IntClassApplyRequest req) {
        // 총 건수
        int totalCount = intClassApplyService.selectIntClassApplyListCnt(req);

        // 페이징 객체 구성
        Page<IntClassApplyOptionDTO> pageReq = new Page<>(req.getCurrentPage(), req.getPageSize(), totalCount);

        // 목록 조회
        List<IntClassApplyOptionDTO> list = intClassApplyService.selectIntClassApplyList(req,pageReq);

        // 응답 페이지에 컨텐츠 세팅
        Page<IntClassApplyOptionDTO> page = new Page<>(req.getCurrentPage(), req.getPageSize(), totalCount);

        page.setContent(list);

        return page;
    }

    @PostMapping("/getIntClassApplyDetail")
    public IntClassApplyDetailDTO getIntClassApplyDetail(@RequestBody IntClassApplyDetailRequest intClassApplyDetailRequest) {
        return intClassApplyService.selectIntClassApplyDetail(intClassApplyDetailRequest);
    }
}
